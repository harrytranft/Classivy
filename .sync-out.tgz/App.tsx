
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ActiveBossRound, AdventureJournalEntry, BossContribution, BossEncounterFrequency, BossInstance, ClassBossState, EggKind, Student, Gender, HistoryItem, RankInfo, Skill, PokemonPet, PokemonReleaseEvent, LudoTileSpec, LuckyWheelReward, LuckyWheelRewardType, StudentEgg, AttendanceStatus } from './types';
import { 
  STORAGE_KEY, DEFAULT_RANKS_MALE, DEFAULT_RANKS_FEMALE, 
  RANKS_KEY_MALE, RANKS_KEY_FEMALE, DEFAULT_SKILLS, SKILLS_KEY,
  BOSS_STATES_KEY, BOSS_ENCOUNTER_FREQUENCY_KEY, DEFAULT_LUDO_TILES, PET_SKILLS_KEY, DEFAULT_LUCKY_WHEEL_REWARDS,
  LUCKY_WHEEL_REWARDS_KEY, WHEEL_SPIN_SOUND_KEY, WHEEL_FINISH_SOUND_KEY
} from './constants';
import { StudentCard } from './components/StudentCard';
import { LiquidDock } from './components/LiquidDock';
import { StatusDock } from './components/StatusDock';
import { StudentAvatar } from './components/StudentAvatar';
import { AttendanceCheckModal } from './components/AttendanceCheckModal';
import { HomeworkCheckModal } from './components/HomeworkCheckModal';
import { HomeworkStatus } from './components/HomeworkCheckModal';
import { PokemonMiniStatus } from './components/PokemonMiniStatus';
import { PokemonPassiveBadge } from './components/PokemonPassiveBadge';
import { PokemonReactionToast } from './components/PokemonReactionToast';
import { BossBattlePanel } from './components/BossBattlePanel';
import { BossDefeatedModal } from './components/BossDefeatedModal';
import { generateEdict } from './geminiService';
import { LIST_POKEMONS, LIST_PET_SKILLS as DEFAULT_PET_SKILLS, PetSkill, getRandomPokemon } from './pokemonData';
import { getPassiveDefinition, getPassiveIcon } from './pokemonPassives';
import { useAuth } from './AuthContext';
import { fetchUserSettings, upsertUserSettings } from './supabaseData';
import { applyGameEventToStudent, applyPetHpDeltaToStudent, GameEventSource, PokemonUiEvent } from './gameEvents';
import {
  createPokemonPetFromDexId,
  addPokemonXp,
  handlePokemonArtworkError,
  getPokemonArtworkUrl,
  getPokemonDisplayName,
  getPokemonNatureDefinition,
  getNextMasteryTarget,
  getNextEvolutionPreview,
  isSamePokemonPet,
  normalizePokemonPet,
  normalizeStudentPokemonData,
  totalXpForLevel,
  updatePetInCollection,
  xpNeededForNextLevel
} from './pokemonProgression';
import {
  BADGE_DEFINITIONS,
  addTrainerXp,
  applyBadgeRewards,
  getBadgeDefinition,
  getTrainerLevelPercent,
  getTrainerTitleDefinition,
  normalizeTrainerProgress,
  trainerXpNeededForNextLevel
} from './trainerProgression';
import {
  BOSS_ENCOUNTER_FREQUENCY_OPTIONS,
  BOSS_PARTY_SIZE,
  DEFAULT_BOSS_ENCOUNTER_FREQUENCY,
  createClassBossState,
  getBossEncounterFrequencyOption,
  getBossTopContributors,
  incrementBossEncounterCounter,
  isBossEncounterReady,
  normalizeBossStatesByClass,
  normalizeClassBossState,
  recalibrateBossEncounterFrequency,
  resolveBossFailure,
  resolveBossSuccess,
  selectBossParty
} from './bossSystem';
import { claimReadyExpedition, ensureActiveExpedition, markExpeditionReadyIfDue } from './expeditionSystem';


type Screen = 'plaza' | 'class' | 'profile' | 'settings';
type RandomMode = 'solo' | 'battle' | 'boss';

const isBossEncounterFrequency = (value: unknown): value is BossEncounterFrequency => {
  return value === 'frequent' || value === 'occasional' || value === 'rare';
};

const LUDO_FINISH_TILE = 49;

interface LuckyWheelResult {
  student: Student;
  reward: LuckyWheelReward;
  pokemon?: PokemonPet;
  skill?: PetSkill;
  hpDelta?: number;
  message: string;
}

interface LevelUpAnnouncement {
  title: string;
  events: PokemonUiEvent[];
}

interface BattleLudoTurn {
  studentId: string;
  role: 'winner' | 'loser' | 'draw' | 'boss';
}

type LudoReturnHint = 'solo' | 'battle' | 'boss' | null;

interface ClaimAllRewardSummary {
  studentId: string;
  studentName: string;
  expeditionMessage?: string;
  chestMessage?: string;
}

interface HatchAnnouncementItem {
  studentId: string;
  studentName: string;
  pet: PokemonPet;
}

interface GiftPokemonResult {
  student: Student;
  pet: PokemonPet;
  egg: StudentEgg;
  hadExistingEgg: boolean;
}

interface ShopReviewItem {
  studentId: string;
  studentName: string;
  pointBalance: number;
  egg?: Exclude<EggKind, 'legendary'>;
  skillIds: string[];
  itemLabels: string[];
  totalCost: number;
  canAfford: boolean;
}

interface TrainerWeather {
  temperature: number;
  weatherCode: number;
  isDay: boolean;
  updatedAt: number;
  label: string;
}

interface TrainerLocation {
  label: string;
  latitude: number;
  longitude: number;
}

const getLocalDateKey = (date = new Date()) => {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getLocalWeekKey = (date = new Date()) => {
  const start = new Date(date.getFullYear(), 0, 1);
  const dayOfYear = Math.floor((date.getTime() - start.getTime()) / 86400000) + 1;
  const week = Math.ceil((dayOfYear + start.getDay()) / 7);
  return `${date.getFullYear()}-W${String(week).padStart(2, '0')}`;
};

const DEFAULT_WHEEL_SPIN_SOUND_URL = 'https://actions.google.com/sounds/v1/transportation/airport_departure_chime.ogg';

const AuthLoginForm: React.FC<{ onSuccess?: () => void }> = ({ onSuccess }) => {
  const { loginWithEmail, signUpWithEmail } = useAuth();
  const [authTab, setAuthTab] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);

    if (!email.trim() || !password.trim()) {
      setErrorMsg("Vui lòng nhập đầy đủ Email và Mật khẩu.");
      return;
    }

    if (authTab === 'register' && !displayName.trim()) {
      setErrorMsg("Vui lòng nhập tên giáo viên.");
      return;
    }

    setSubmitting(true);
    try {
      if (authTab === 'login') {
        await loginWithEmail(email.trim(), password);
      } else {
        const result = await signUpWithEmail(email.trim(), password, displayName.trim());
        if (result.needsEmailConfirmation) {
          setAuthTab('login');
          setErrorMsg("Tài khoản đã được tạo. Vui lòng mở email xác nhận từ Supabase rồi quay lại đăng nhập.");
          return;
        }
      }
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setErrorMsg(err.message || "Có lỗi xảy ra, vui lòng thử lại.");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="w-full font-sans space-y-4">
      {/* Tabs */}
      <div className="flex bg-stone-100 p-1 rounded-2xl border border-stone-200">
        <button
          type="button"
          onClick={() => { setAuthTab('login'); setErrorMsg(null); }}
          className={`flex-1 py-2.5 text-xs font-black uppercase tracking-wider rounded-xl transition-all ${
            authTab === 'login'
              ? 'bg-red-800 text-white shadow-md'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          🔑 Đăng Nhập
        </button>
        <button
          type="button"
          onClick={() => { setAuthTab('register'); setErrorMsg(null); }}
          className={`flex-1 py-2.5 text-xs font-black uppercase tracking-wider rounded-xl transition-all ${
            authTab === 'register'
              ? 'bg-red-800 text-white shadow-md'
              : 'text-stone-600 hover:text-stone-900'
          }`}
        >
          📜 Tạo Tài Khoản
        </button>
      </div>

      {errorMsg && (
        <div className="bg-red-50 border border-red-200 text-red-800 p-3 rounded-2xl text-xs font-bold flex items-center gap-2 animate-in fade-in">
          <span>⚠️</span>
          <span>{errorMsg}</span>
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-3.5 text-left">
        {authTab === 'register' && (
          <div>
            <label className="block text-[10px] font-black uppercase tracking-wider text-stone-500 mb-1">
              Tên giáo viên
            </label>
            <input
              type="text"
              required
              value={displayName}
              onChange={e => setDisplayName(e.target.value)}
              placeholder="Ví dụ: Thầy/Cô Nguyễn"
              className="w-full border border-stone-300 p-3 rounded-xl text-xs font-bold outline-none focus:ring-2 ring-red-800/30"
            />
          </div>
        )}

        <div>
          <label className="block text-[10px] font-black uppercase tracking-wider text-stone-500 mb-1">
            Địa chỉ Email
          </label>
          <input
            type="email"
            required
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="syphu@trieudinh.vn"
            className="w-full border border-stone-300 p-3 rounded-xl text-xs font-bold outline-none focus:ring-2 ring-red-800/30"
          />
        </div>

        <div>
          <label className="block text-[10px] font-black uppercase tracking-wider text-stone-500 mb-1">
            Mật khẩu
          </label>
          <input
            type="password"
            required
            value={password}
            onChange={e => setPassword(e.target.value)}
            placeholder="••••••••"
            className="w-full border border-stone-300 p-3 rounded-xl text-xs font-bold outline-none focus:ring-2 ring-red-800/30"
          />
        </div>

        <button
          type="submit"
          disabled={submitting}
          className="w-full bg-gradient-to-r from-red-800 to-red-900 hover:from-red-700 hover:to-red-800 text-white font-extrabold py-3.5 rounded-xl shadow-lg hover:shadow-xl active:scale-95 transition-all text-xs uppercase tracking-wider border-b-4 border-red-950 disabled:opacity-50 flex items-center justify-center gap-2"
        >
          {submitting ? (
            <>
              <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              <span>Đang Xử Lý...</span>
            </>
          ) : authTab === 'login' ? (
            <span>Đăng nhập</span>
          ) : (
            <span>✨ Tạo Tài Khoản Mới</span>
          )}
        </button>
      </form>
    </div>
  );
};

interface SettingsSectionProps {
  id: string;
  title: string;
  icon: string;
  subtitle?: string;
  className?: string;
  collapsedSections: Record<string, boolean>;
  onToggle: (section: string) => void;
  children: React.ReactNode;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({
  id,
  title,
  icon,
  subtitle,
  className = 'bg-white p-10 rounded-[40px] border shadow-sm space-y-8',
  collapsedSections,
  onToggle,
  children
}) => {
  const isCollapsed = !!collapsedSections[id];
  return (
    <section className={className}>
      <div className="flex items-center justify-between gap-4 border-b pb-4">
        <div className="flex items-center gap-3 min-w-0">
          <span className="text-3xl shrink-0">{icon}</span>
          <div className="min-w-0">
            <h3 className="text-2xl font-royal text-red-800">{title}</h3>
            {subtitle && <p className="text-xs text-stone-500 font-bold mt-1">{subtitle}</p>}
          </div>
        </div>
        <button
          type="button"
          onClick={() => onToggle(id)}
          className={`shrink-0 w-16 h-8 rounded-full border-2 p-1 transition-all ${isCollapsed ? 'bg-stone-200 border-stone-300' : 'bg-red-800 border-red-900'}`}
          aria-label={isCollapsed ? `Hiện ${title}` : `Ẩn ${title}`}
          title={isCollapsed ? `Hiện ${title}` : `Ẩn ${title}`}
        >
          <span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${isCollapsed ? 'translate-x-0' : 'translate-x-8'}`} />
        </button>
      </div>
      {!isCollapsed && children}
    </section>
  );
};

const App: React.FC = () => {
  const [students, setStudents] = useState<Student[]>([]);
  const [ranksMale, setRanksMale] = useState<RankInfo[]>(DEFAULT_RANKS_MALE);
  const [ranksFemale, setRanksFemale] = useState<RankInfo[]>(DEFAULT_RANKS_FEMALE);
  const [skills, setSkills] = useState<Skill[]>(DEFAULT_SKILLS);
  const [petSkills, setPetSkills] = useState<PetSkill[]>(() => {
    const saved = localStorage.getItem(PET_SKILLS_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      } catch (err) {
        console.error("Error loading custom Pokemon skills:", err);
      }
    }
    return DEFAULT_PET_SKILLS;
  });
  
  const [currentScreen, setCurrentScreen] = useState<Screen>('class');
  const [selectedStudentIds, setSelectedStudentIds] = useState<string[]>([]);
  const [isMultiSelectMode, setIsMultiSelectMode] = useState(false);
  const [showSkillModal, setShowSkillModal] = useState(false);
  const [activeTab, setActiveTab] = useState<'positive' | 'negative'>('positive');
  const [feedbackSource, setFeedbackSource] = useState<GameEventSource>('manual');
  const [pokemonReactionEvents, setPokemonReactionEvents] = useState<PokemonUiEvent[]>([]);
  const [pokemonReactionTitle, setPokemonReactionTitle] = useState('Tiến triển Pokémon');
  const [levelUpAnnouncement, setLevelUpAnnouncement] = useState<LevelUpAnnouncement | null>(null);
  const pokemonReactionTimerRef = useRef<number | null>(null);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [sortType, setSortType] = useState<'name' | 'points-desc' | 'points-asc'>('points-desc');
  const [filterClass, setFilterClass] = useState<string>('Tất cả');
  const [hoveredStudentCardId, setHoveredStudentCardId] = useState<string | null>(null);

  // Manual points state
  const [manualPoints, setManualPoints] = useState<string>('');

  // Modals
  const [showRandomModal, setShowRandomModal] = useState(false);
  const [randomStudent, setRandomStudent] = useState<Student | null>(null);
  const [showAttendanceModal, setShowAttendanceModal] = useState(false);
  const [attendanceStatuses, setAttendanceStatuses] = useState<Record<string, AttendanceStatus>>({});
  const [showHomeworkModal, setShowHomeworkModal] = useState(false);
  const [homeworkStatuses, setHomeworkStatuses] = useState<Record<string, HomeworkStatus>>({});
  const [showShopModal, setShowShopModal] = useState(false);
  const [shopSelections, setShopSelections] = useState<Record<string, { egg?: Exclude<EggKind, 'legendary'>; skills: string[] }>>({});
  const [shopReview, setShopReview] = useState<ShopReviewItem[] | null>(null);
  const [selectedShopSkill, setSelectedShopSkill] = useState<PetSkill | null>(null);
  const [randomMode, setRandomMode] = useState<RandomMode>('solo');
  const [battleStudentA, setBattleStudentA] = useState<Student | null>(null);
  const [battleStudentB, setBattleStudentB] = useState<Student | null>(null);
  const [battleScoreA, setBattleScoreA] = useState<number>(0);
  const [battleScoreB, setBattleScoreB] = useState<number>(0);
  const [battleResultSummary, setBattleResultSummary] = useState<{
    studentA: Student;
    studentB: Student;
    winner: Student | null;
    scoreA: number;
    scoreB: number;
    diff: number;
    resultMsg: string;
    ludoTurns: BattleLudoTurn[];
  } | null>(null);
  const [uncalledMap, setUncalledMap] = useState<Record<string, string[]>>({}); // Fair round-robin random queue
  const [bossEncounterFrequency, setBossEncounterFrequency] = useState<BossEncounterFrequency>(() => {
    const saved = localStorage.getItem(BOSS_ENCOUNTER_FREQUENCY_KEY);
    return isBossEncounterFrequency(saved) ? saved : DEFAULT_BOSS_ENCOUNTER_FREQUENCY;
  });
  const [bossStatesByClass, setBossStatesByClass] = useState<Record<string, ClassBossState>>({});
  const [activeBossRound, setActiveBossRound] = useState<ActiveBossRound | null>(null);
  const [bossRoundResolving, setBossRoundResolving] = useState(false);
  const [bossRoundVisualResult, setBossRoundVisualResult] = useState<'success' | 'failure' | null>(null);
  const [bossDefeatedAnnouncement, setBossDefeatedAnnouncement] = useState<{
    boss: BossInstance;
    topContributors: BossContribution[];
  } | null>(null);

  // Lucky Wheel State
  const [showLuckyWheelModal, setShowLuckyWheelModal] = useState(false);
  const [isLuckyWheelSpinning, setIsLuckyWheelSpinning] = useState(false);
  const [luckyWheelRotation, setLuckyWheelRotation] = useState(0);
  const [luckyWheelResult, setLuckyWheelResult] = useState<LuckyWheelResult | null>(null);
  const [luckyWheelPendingResult, setLuckyWheelPendingResult] = useState<LuckyWheelResult | null>(null);
  const [luckyWheelCandidateIds, setLuckyWheelCandidateIds] = useState<string[]>([]);
  const [luckyWheelMode, setLuckyWheelMode] = useState<'normal' | 'ludo-finish'>('normal');
  const [luckyWheelRewards, setLuckyWheelRewards] = useState<LuckyWheelReward[]>(() => {
    const saved = localStorage.getItem(LUCKY_WHEEL_REWARDS_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      } catch (err) {
        console.error("Error loading custom lucky wheel rewards:", err);
      }
    }
    return DEFAULT_LUCKY_WHEEL_REWARDS;
  });
  const [luckyWheelDisplayRewards, setLuckyWheelDisplayRewards] = useState<LuckyWheelReward[]>(DEFAULT_LUCKY_WHEEL_REWARDS);
  const luckyWheelRef = useRef<HTMLDivElement | null>(null);
  const luckyWheelSpinAudioRef = useRef<HTMLAudioElement | null>(null);
  const luckyWheelSpinSynthRef = useRef<{ context: AudioContext; intervalId: number } | null>(null);

  // Cá Ngựa / Ludo Game State
  const [showLudoModal, setShowLudoModal] = useState(false);
  const [ludoPositions, setLudoPositions] = useState<Record<string, number>>({});
  const [ludoSteps, setLudoSteps] = useState<Record<string, number>>({});
  const [ludoMonsterStuck, setLudoMonsterStuck] = useState<Record<string, boolean>>({});
  const [ludoVisitedSpecialTiles, setLudoVisitedSpecialTiles] = useState<Record<number, boolean>>({});
  const [ludoActiveStudent, setLudoActiveStudent] = useState<Student | null>(null);
  const [ludoClassName, setLudoClassName] = useState<string>('');
  const [ludoDice, setLudoDice] = useState<number | null>(null);
  const [ludoRolling, setLudoRolling] = useState(false);
  const [ludoPopup, setLudoPopup] = useState<{ title: string; desc: string; icon: string } | null>(null);
  const [ludoLogs, setLudoLogs] = useState<string[]>([]);
  const [ludoBonusRolls, setLudoBonusRolls] = useState<Record<string, number>>({});
  const [battleLudoQueue, setBattleLudoQueue] = useState<BattleLudoTurn[]>([]);
  const [ludoEventPopup, setLudoEventPopup] = useState<{
    title: string;
    message: string;
    actor: Student;
    target?: Student;
    icon: string;
    type: 'kick' | 'special' | 'finish' | 'monster' | 'curse' | 'portal';
    tileIndex?: number;
  } | null>(null);
  const [ludoReturnHint, setLudoReturnHint] = useState<LudoReturnHint>(null);
  const [claimAllRewardSummary, setClaimAllRewardSummary] = useState<ClaimAllRewardSummary[] | null>(null);

  // Custom Ludo Special Tiles State
  const [customLudoTiles, setCustomLudoTiles] = useState<Record<number, LudoTileSpec>>(() => {
    const saved = localStorage.getItem('custom_ludo_tiles');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (err) {
        console.error("Error loading custom Ludo tiles:", err);
      }
    }
    return DEFAULT_LUDO_TILES;
  });

  // Custom Ludo Tiles Form State in Settings
  const [tileFormIndex, setTileFormIndex] = useState<number>(0);
  const [tileFormTitle, setTileFormTitle] = useState<string>('');
  const [tileFormDesc, setTileFormDesc] = useState<string>('');
  const [tileFormIcon, setTileFormIcon] = useState<string>('🚀');
  const [tileFormType, setTileFormType] = useState<'portal' | 'curse' | 'treasure' | 'monster' | 'restart'>('portal');
  const [tileFormValue, setTileFormValue] = useState<number>(3);
  const [editingTileIndex, setEditingTileIndex] = useState<number | null>(null);

  // Pokemon Fusion State
  const [selectedFusionPetDexIds, setSelectedFusionPetDexIds] = useState<number[]>([]);

  const [showGroupModal, setShowGroupModal] = useState(false);
  const [groupSize, setGroupSize] = useState(2);
  const [generatedGroups, setGeneratedGroups] = useState<Student[][]>([]);
  const [showTimerModal, setShowTimerModal] = useState(false);
  const [timerTime, setTimerTime] = useState(0); 
  const [timerRunning, setTimerRunning] = useState(false);
  const [customMinutes, setCustomMinutes] = useState<string>('');
  const timerRef = useRef<number | null>(null);

  // Edict handling
  const [edict, setEdict] = useState<string | null>(null);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [profileTab, setProfileTab] = useState<'info' | 'pet' | 'fusion'>('info');

  // Hatching State variables
  const [showHatchModal, setShowHatchModal] = useState(false);
  const [hatchSuccessMessage, setHatchSuccessMessage] = useState<string>('');
  const [hatchAnnouncementItems, setHatchAnnouncementItems] = useState<HatchAnnouncementItem[] | null>(null);
  const [pokemonReleaseEvent, setPokemonReleaseEvent] = useState<PokemonReleaseEvent | null>(null);
  const [pokemonReleaseQueue, setPokemonReleaseQueue] = useState<PokemonReleaseEvent[]>([]);
  const [showGiftPokemonModal, setShowGiftPokemonModal] = useState(false);
  const [giftStudentId, setGiftStudentId] = useState<string>('');
  const [giftPokemonResult, setGiftPokemonResult] = useState<GiftPokemonResult | null>(null);
  const [giftAnimationPhase, setGiftAnimationPhase] = useState<'select' | 'hatching' | 'revealed'>('select');
  const giftPokemonTimersRef = useRef<number[]>([]);

  // Audio settings
  const [posSoundUrl, setPosSoundUrl] = useState('https://actions.google.com/sounds/v1/foley/ting.ogg');
  const [negSoundUrl, setNegSoundUrl] = useState('https://actions.google.com/sounds/v1/alarms/beep_short.ogg');
  const [timerSoundUrl, setTimerSoundUrl] = useState('https://actions.google.com/sounds/v1/alarms/bugle_tune.ogg');
  const [wheelSpinSoundUrl, setWheelSpinSoundUrl] = useState('https://actions.google.com/sounds/v1/transportation/airport_departure_chime.ogg');
  const [wheelFinishSoundUrl, setWheelFinishSoundUrl] = useState('https://actions.google.com/sounds/v1/cartoon/concussive_hit_guitar_boing.ogg');

  // Cloud Sync properties
  const { user, profile, loginWithEmail, signUpWithEmail, signInWithGoogle, logout, updateUserProfile, loading: authLoading } = useAuth();
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedTime, setLastSyncedTime] = useState<number | null>(null);
  const [initialCloudLoadComplete, setInitialCloudLoadComplete] = useState(false);
  const [cloudLoadSuccess, setCloudLoadSuccess] = useState(false);

  // Reference to store last synced state snapshot for differential sync
  const lastSyncedSnapshotRef = useRef<string>('');

  // User Profile Modal State
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingDisplayName, setEditingDisplayName] = useState('');
  const [editingPhotoURL, setEditingPhotoURL] = useState('');
  const [profileSaving, setProfileSaving] = useState(false);
  const [confirmLogout, setConfirmLogout] = useState(false);
  const [settingsCollapsed, setSettingsCollapsed] = useState<Record<string, boolean>>({
    weather: true,
    sound: true,
    skills: true,
    petSkills: true,
    pokemonReset: true,
    ludo: true,
    luckyWheel: true,
    data: true
  });
  const [weatherLocationInput, setWeatherLocationInput] = useState(() => localStorage.getItem('trainer_weather_location_input') || 'Hanoi');
  const [trainerLocation, setTrainerLocation] = useState<TrainerLocation | null>(() => {
    const saved = localStorage.getItem('trainer_weather_location');
    if (!saved) return null;
    try {
      return JSON.parse(saved);
    } catch {
      return null;
    }
  });
  const [trainerWeather, setTrainerWeather] = useState<TrainerWeather | null>(null);
  const [weatherLoading, setWeatherLoading] = useState(false);
  const [weatherError, setWeatherError] = useState<string | null>(null);

  useEffect(() => {
    if (profile) {
      setEditingDisplayName(profile.displayName || '');
      setEditingPhotoURL(profile.photoURL || '');
    }
    if (!showUserModal) {
      setConfirmLogout(false);
    }
  }, [profile, showUserModal]);

  useEffect(() => {
    return () => {
      if (pokemonReactionTimerRef.current) {
        window.clearTimeout(pokemonReactionTimerRef.current);
      }
      giftPokemonTimersRef.current.forEach(timerId => window.clearTimeout(timerId));
    };
  }, []);

  const showPokemonReaction = (events: PokemonUiEvent[], title = 'Tiến triển Pokémon') => {
    if (events.length === 0) return;
    if (pokemonReactionTimerRef.current) {
      window.clearTimeout(pokemonReactionTimerRef.current);
    }
    setPokemonReactionTitle(title);
    setPokemonReactionEvents(events.slice(0, 4));
    const levelEvents = events.filter(event => event.type === 'level-up');
    if (levelEvents.length > 0) {
      setLevelUpAnnouncement({
        title,
        events: levelEvents.slice(0, 3)
      });
    }
  };

  const applyTrainerJourneyProgress = (
    student: Student,
    xpGain: number,
    timestamp: number,
    uiEvents: PokemonUiEvent[],
    reason?: string
  ): Student => {
    let nextStudent: Student = {
      ...student,
      trainerProgress: normalizeTrainerProgress(student),
      earnedBadges: student.earnedBadges || []
    };

    if (xpGain > 0) {
      const xpResult = addTrainerXp(nextStudent, xpGain);
      nextStudent = xpResult.student;
      uiEvents.push({
        type: 'streak',
        message: `${student.name}: Trainer +${xpGain} XP${reason ? ` (${reason})` : ''}`
      });
      if (xpResult.levelUps > 0) {
        uiEvents.push({
          type: 'level-up',
          message: `${student.name}: Trainer Lv.${nextStudent.trainerProgress?.level}`
        });
        nextStudent = appendAdventureJournal(nextStudent, {
          type: 'trainer-level',
          text: `${student.name} reached Trainer Lv.${nextStudent.trainerProgress?.level}.`
        }, timestamp);
      }
    }

    const badgeResult = applyBadgeRewards(nextStudent, timestamp);
    nextStudent = badgeResult.student;
    badgeResult.newBadges.forEach(badge => {
      const definition = getBadgeDefinition(badge.badgeId);
      uiEvents.push({
        type: 'mastery',
        message: `${student.name}: ${definition?.icon || '🏅'} ${definition?.name || 'Badge'}`
      });
      nextStudent = appendAdventureJournal(nextStudent, {
        type: 'badge-earned',
        text: `${student.name} earned ${definition?.name || 'a Gym Badge'}.`
      }, badge.earnedAt);
    });
    if (badgeResult.trainerLevelUps > 0) {
      uiEvents.push({
        type: 'level-up',
        message: `${student.name}: Trainer Lv.${nextStudent.trainerProgress?.level}`
      });
    }

    return {
      ...nextStudent,
      trainerProgress: normalizeTrainerProgress(nextStudent)
    };
  };

  const appendAdventureJournal = (
    student: Student,
    entry: Omit<AdventureJournalEntry, 'id' | 'timestamp'>,
    timestamp = Date.now()
  ): Student => ({
    ...student,
    adventureJournal: [
      {
        id: `${timestamp}${Math.random()}`,
        timestamp,
        ...entry
      },
      ...(student.adventureJournal || [])
    ].slice(0, 80)
  });

  const addWeeklyChestProgress = (student: Student, amount: number): Student => {
    if (amount <= 0) return student;
    const weekKey = getLocalWeekKey();
    const current = student.weeklyChest?.weekKey === weekKey
      ? student.weeklyChest
      : { weekKey, progress: 0, claimed: false };
    if (current.claimed) return { ...student, weeklyChest: current };
    return {
      ...student,
      weeklyChest: {
        ...current,
        progress: Math.min(100, current.progress + amount)
      }
    };
  };

  const claimWeeklyChest = (student: Student): { student: Student; message: string } => {
    const current = student.weeklyChest;
    if (!current || current.progress < 100 || current.claimed) {
      return { student, message: 'Weekly Chest chưa sẵn sàng.' };
    }

    let nextStudent = normalizeStudentPokemonData(student);
    if (nextStudent.pet) {
      const xpResult = addPokemonXp(nextStudent.pet, 25);
      const nextPet = {
        ...xpResult.pet,
        bond: Math.min(100, (xpResult.pet.bond || 0) + 4)
      };
      nextStudent = {
        ...nextStudent,
        pet: nextPet,
        pets: updatePetInCollection(nextStudent, nextPet)
      };
    }

    nextStudent = {
      ...nextStudent,
      weeklyChest: {
        ...current,
        claimed: true
      },
      eggFragments: {
        ...(nextStudent.eggFragments || {}),
        normal: (nextStudent.eggFragments?.normal || 0) + 5,
        special: (nextStudent.eggFragments?.special || 0) + 2
      }
    };

    return {
      student: nextStudent,
      message: `${student.name} mở Weekly Chest: Pokémon +25 XP, +4 Bond, +5 Normal Fragment, +2 Special Fragment`
    };
  };

  const craftEggFromFragments = (student: Student, kind: Exclude<EggKind, 'legendary'>): { student: Student; message: string } => {
    const current = student.eggFragments?.[kind] || 0;
    if (current < 10) return { student, message: `Cần 10 ${getEggLabel(kind)} fragments để craft.` };
    const nextStudent: Student = {
      ...student,
      eggFragments: {
        ...(student.eggFragments || {}),
        [kind]: current - 10
      },
      eggInventory: [createEgg(kind, 'reward'), ...(student.eggInventory || [])]
    };
    return {
      student: nextStudent,
      message: `${student.name} craft thành công ${getEggLabel(kind)} từ fragments.`
    };
  };

  // Sync state FROM Supabase on login (high priority)
  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      setInitialCloudLoadComplete(false);
      setCloudLoadSuccess(false);
      setLastSyncedTime(null);
      lastSyncedSnapshotRef.current = '';
      return;
    }

    const fetchCloudData = async () => {
      setIsSyncing(true);
      try {
        const cloudData = await fetchUserSettings(user.uid);

        if (cloudData) {
          const cloudStudents = Array.isArray(cloudData.students)
            ? cloudData.students.map(normalizeStudentPokemonData)
            : [];
          if (cloudData.students && Array.isArray(cloudData.students)) setStudents(cloudStudents);
          if (cloudData.ranksMale && Array.isArray(cloudData.ranksMale)) setRanksMale(cloudData.ranksMale);
          if (cloudData.ranksFemale && Array.isArray(cloudData.ranksFemale)) setRanksFemale(cloudData.ranksFemale);
          if (cloudData.skills && Array.isArray(cloudData.skills)) setSkills(cloudData.skills);
          if (cloudData.petSkills && Array.isArray(cloudData.petSkills) && cloudData.petSkills.length > 0) {
            setPetSkills(cloudData.petSkills);
            localStorage.setItem(PET_SKILLS_KEY, JSON.stringify(cloudData.petSkills));
          }
          if (cloudData.posSoundUrl) setPosSoundUrl(cloudData.posSoundUrl);
          if (cloudData.negSoundUrl) setNegSoundUrl(cloudData.negSoundUrl);
          if (cloudData.timerSoundUrl) setTimerSoundUrl(cloudData.timerSoundUrl);
          if (cloudData.wheelSpinSoundUrl) setWheelSpinSoundUrl(cloudData.wheelSpinSoundUrl);
          if (cloudData.wheelFinishSoundUrl) setWheelFinishSoundUrl(cloudData.wheelFinishSoundUrl);
          if (cloudData.customLudoTiles && typeof cloudData.customLudoTiles === 'object') {
            setCustomLudoTiles(cloudData.customLudoTiles);
            localStorage.setItem('custom_ludo_tiles', JSON.stringify(cloudData.customLudoTiles));
          }
          if (cloudData.luckyWheelRewards && Array.isArray(cloudData.luckyWheelRewards) && cloudData.luckyWheelRewards.length > 0) {
            setLuckyWheelRewards(cloudData.luckyWheelRewards);
            setLuckyWheelDisplayRewards(cloudData.luckyWheelRewards);
            localStorage.setItem(LUCKY_WHEEL_REWARDS_KEY, JSON.stringify(cloudData.luckyWheelRewards));
          }
          const cloudBossFrequency = isBossEncounterFrequency(cloudData.bossEncounterFrequency)
            ? cloudData.bossEncounterFrequency
            : DEFAULT_BOSS_ENCOUNTER_FREQUENCY;
          setBossEncounterFrequency(cloudBossFrequency);
          localStorage.setItem(BOSS_ENCOUNTER_FREQUENCY_KEY, cloudBossFrequency);
          const cloudBossStates = normalizeBossStatesByClass(cloudData.bossStatesByClass || {}, cloudBossFrequency);
          setBossStatesByClass(cloudBossStates);
          localStorage.setItem(BOSS_STATES_KEY, JSON.stringify(cloudBossStates));
          setLastSyncedTime(cloudData.updatedAt || Date.now());

          // Save snapshot ref to prevent immediate re-sync of unchanged data
          lastSyncedSnapshotRef.current = JSON.stringify({
            students: cloudStudents,
            ranksMale: cloudData.ranksMale || [],
            ranksFemale: cloudData.ranksFemale || [],
            skills: cloudData.skills || [],
            petSkills: cloudData.petSkills || DEFAULT_PET_SKILLS,
            posSoundUrl: cloudData.posSoundUrl || '',
            negSoundUrl: cloudData.negSoundUrl || '',
            timerSoundUrl: cloudData.timerSoundUrl || '',
            wheelSpinSoundUrl: cloudData.wheelSpinSoundUrl || '',
            wheelFinishSoundUrl: cloudData.wheelFinishSoundUrl || '',
            customLudoTiles: cloudData.customLudoTiles || {},
            luckyWheelRewards: cloudData.luckyWheelRewards || DEFAULT_LUCKY_WHEEL_REWARDS,
            bossStatesByClass: cloudBossStates,
            bossEncounterFrequency: cloudBossFrequency
          });

          // Also save a fallback local copy
          localStorage.setItem(STORAGE_KEY, JSON.stringify(cloudStudents));
          if (cloudData.ranksMale) localStorage.setItem(RANKS_KEY_MALE, JSON.stringify(cloudData.ranksMale));
          if (cloudData.ranksFemale) localStorage.setItem(RANKS_KEY_FEMALE, JSON.stringify(cloudData.ranksFemale));
          if (cloudData.skills) localStorage.setItem(SKILLS_KEY, JSON.stringify(cloudData.skills));
          if (cloudData.petSkills) localStorage.setItem(PET_SKILLS_KEY, JSON.stringify(cloudData.petSkills));
          if (cloudData.posSoundUrl) localStorage.setItem('imperial_sound_pos', cloudData.posSoundUrl);
          if (cloudData.negSoundUrl) localStorage.setItem('imperial_sound_neg', cloudData.negSoundUrl);
          if (cloudData.timerSoundUrl) localStorage.setItem('imperial_sound_tim', cloudData.timerSoundUrl);
          if (cloudData.wheelSpinSoundUrl) localStorage.setItem(WHEEL_SPIN_SOUND_KEY, cloudData.wheelSpinSoundUrl);
          if (cloudData.wheelFinishSoundUrl) localStorage.setItem(WHEEL_FINISH_SOUND_KEY, cloudData.wheelFinishSoundUrl);
        } else {
          // First time logging in: check if there's any local storage data to migrate
          const saved = localStorage.getItem(STORAGE_KEY);
          let localStudents: Student[] = [];
          if (saved) {
            try {
              localStudents = JSON.parse(saved).map(normalizeStudentPokemonData);
            } catch (err) {
              console.error(err);
            }
          }
          
          const savedMaleRanks = localStorage.getItem(RANKS_KEY_MALE);
          const localMaleRanks = savedMaleRanks ? JSON.parse(savedMaleRanks) : DEFAULT_RANKS_MALE;

          const savedFemaleRanks = localStorage.getItem(RANKS_KEY_FEMALE);
          const localFemaleRanks = savedFemaleRanks ? JSON.parse(savedFemaleRanks) : DEFAULT_RANKS_FEMALE;

          const savedSkills = localStorage.getItem(SKILLS_KEY);
          const localSkills = savedSkills ? JSON.parse(savedSkills) : DEFAULT_SKILLS;

          const savedPetSkills = localStorage.getItem(PET_SKILLS_KEY);
          const localPetSkills = savedPetSkills ? JSON.parse(savedPetSkills) : DEFAULT_PET_SKILLS;

          const savedLuckyWheelRewards = localStorage.getItem(LUCKY_WHEEL_REWARDS_KEY);
          const localLuckyWheelRewards = savedLuckyWheelRewards ? JSON.parse(savedLuckyWheelRewards) : DEFAULT_LUCKY_WHEEL_REWARDS;
          const savedBossFrequency = localStorage.getItem(BOSS_ENCOUNTER_FREQUENCY_KEY);
          const localBossFrequency = isBossEncounterFrequency(savedBossFrequency)
            ? savedBossFrequency
            : DEFAULT_BOSS_ENCOUNTER_FREQUENCY;
          const savedBossStates = localStorage.getItem(BOSS_STATES_KEY);
          const localBossStates = savedBossStates ? normalizeBossStatesByClass(JSON.parse(savedBossStates), localBossFrequency) : {};

          // Push local state to cloud to prevent data loss on onboarding
          const updatedAt = await upsertUserSettings(user.uid, {
            students: localStudents,
            ranksMale: localMaleRanks,
            ranksFemale: localFemaleRanks,
            skills: localSkills,
            petSkills: localPetSkills,
            posSoundUrl,
            negSoundUrl,
            timerSoundUrl,
            wheelSpinSoundUrl,
            wheelFinishSoundUrl,
            customLudoTiles,
            luckyWheelRewards: localLuckyWheelRewards,
            bossStatesByClass: localBossStates,
            bossEncounterFrequency: localBossFrequency
          });

          lastSyncedSnapshotRef.current = JSON.stringify({
            students: localStudents,
            ranksMale: localMaleRanks,
            ranksFemale: localFemaleRanks,
            skills: localSkills,
            petSkills: localPetSkills,
            posSoundUrl,
            negSoundUrl,
            timerSoundUrl,
            wheelSpinSoundUrl,
            wheelFinishSoundUrl,
            customLudoTiles,
            luckyWheelRewards: localLuckyWheelRewards,
            bossStatesByClass: localBossStates,
            bossEncounterFrequency: localBossFrequency
          });
          
          setStudents(localStudents);
          setRanksMale(localMaleRanks);
          setRanksFemale(localFemaleRanks);
          setSkills(localSkills);
          setPetSkills(localPetSkills);
          setLuckyWheelRewards(localLuckyWheelRewards);
          setLuckyWheelDisplayRewards(localLuckyWheelRewards);
          setBossEncounterFrequency(localBossFrequency);
          setBossStatesByClass(localBossStates);
          setLastSyncedTime(updatedAt);
        }
        setCloudLoadSuccess(true);
        setInitialCloudLoadComplete(true);
      } catch (err) {
        console.error("Error pulling database sync from Supabase:", err);
        setCloudLoadSuccess(false);
        setInitialCloudLoadComplete(false);
      } finally {
        setIsSyncing(false);
      }
    };

    fetchCloudData();
  }, [user, authLoading]);

  // Sync state TO Supabase whenever local data changes (except during initial load)
  useEffect(() => {
    if (!user || !initialCloudLoadComplete || !cloudLoadSuccess) return;

    const currentSnapshot = JSON.stringify({
      students,
      ranksMale,
      ranksFemale,
      skills,
      petSkills,
      posSoundUrl,
      negSoundUrl,
      timerSoundUrl,
      wheelSpinSoundUrl,
      wheelFinishSoundUrl,
      customLudoTiles,
      luckyWheelRewards,
      bossStatesByClass,
      bossEncounterFrequency
    });

    // DIFFERENTIAL INCREMENTAL SYNC CHECK:
    // Only perform auto-sync if current data is DIFFERENT from the last synced snapshot!
    // If nothing changed, we skip cloud writes completely to preserve existing data and save bandwidth.
    if (currentSnapshot === lastSyncedSnapshotRef.current) {
      return;
    }

    const timer = setTimeout(async () => {
      setIsSyncing(true);
      try {
        const updatedAt = await upsertUserSettings(user.uid, {
          students,
          ranksMale,
          ranksFemale,
          skills,
          petSkills,
          posSoundUrl,
          negSoundUrl,
          timerSoundUrl,
          wheelSpinSoundUrl,
          wheelFinishSoundUrl,
          customLudoTiles,
          luckyWheelRewards,
          bossStatesByClass,
          bossEncounterFrequency
        });

        lastSyncedSnapshotRef.current = currentSnapshot;
        setLastSyncedTime(updatedAt);
      } catch (err) {
        console.error("Auto-sync to cloud failed:", err);
      } finally {
        setIsSyncing(false);
      }
    }, 1500); // 1.5s debounce to group multiple rapid edits together

    return () => clearTimeout(timer);
  }, [students, ranksMale, ranksFemale, skills, petSkills, posSoundUrl, negSoundUrl, timerSoundUrl, wheelSpinSoundUrl, wheelFinishSoundUrl, customLudoTiles, luckyWheelRewards, bossStatesByClass, bossEncounterFrequency, user, initialCloudLoadComplete, cloudLoadSuccess]);

  // Sync Ludo position state maps whenever students array loads or changes
  useEffect(() => {
    if (students && students.length > 0) {
      const posMap: Record<string, number> = {};
      const stepsMap: Record<string, number> = {};
      const stuckMap: Record<string, boolean> = {};

      students.forEach(s => {
        posMap[s.id] = s.ludoTile || 0;
        stepsMap[s.id] = s.ludoSteps || 0;
        stuckMap[s.id] = !!s.ludoMonsterStuck;
      });

      setLudoPositions(posMap);
      setLudoSteps(stepsMap);
      setLudoMonsterStuck(stuckMap);
    }
  }, [students]);

  // Save customLudoTiles to local storage whenever updated
  useEffect(() => {
    localStorage.setItem('custom_ludo_tiles', JSON.stringify(customLudoTiles));
  }, [customLudoTiles]);

  useEffect(() => {
    localStorage.setItem(PET_SKILLS_KEY, JSON.stringify(petSkills));
  }, [petSkills]);

  // Persistence (Guest Mode)
  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        try {
          const parsed: Student[] = JSON.parse(saved);
          const migrated = parsed.map(s => {
            if (!s.egg && !s.pet) {
              const randomPokemon = getRandomPokemon();
              return {
                ...s,
                egg: {
                  progress: 0,
                  status: 'egg' as const,
                  assignedDexId: randomPokemon.dexId,
                  kind: 'normal' as const,
                  requiredProgress: 10
                }
              };
            }
            return s;
          }).map(normalizeStudentPokemonData);
          setStudents(migrated);
        } catch (err) {
          console.error("Failed to parse saved students", err);
        }
      } else {
        setStudents([]);
      }

      const savedMaleRanks = localStorage.getItem(RANKS_KEY_MALE);
      if (savedMaleRanks) setRanksMale(JSON.parse(savedMaleRanks));
      else setRanksMale(DEFAULT_RANKS_MALE);

      const savedFemaleRanks = localStorage.getItem(RANKS_KEY_FEMALE);
      if (savedFemaleRanks) setRanksFemale(JSON.parse(savedFemaleRanks));
      else setRanksFemale(DEFAULT_RANKS_FEMALE);

      const savedSkills = localStorage.getItem(SKILLS_KEY);
      if (savedSkills) setSkills(JSON.parse(savedSkills));
      else setSkills(DEFAULT_SKILLS);

      const savedPetSkills = localStorage.getItem(PET_SKILLS_KEY);
      if (savedPetSkills) setPetSkills(JSON.parse(savedPetSkills));
      else setPetSkills(DEFAULT_PET_SKILLS);
      
      const sPos = localStorage.getItem('imperial_sound_pos');
      const sNeg = localStorage.getItem('imperial_sound_neg');
      const sTim = localStorage.getItem('imperial_sound_tim');
      const sWheelSpin = localStorage.getItem(WHEEL_SPIN_SOUND_KEY);
      const sWheelFinish = localStorage.getItem(WHEEL_FINISH_SOUND_KEY);
      if (sPos) setPosSoundUrl(sPos);
      if (sNeg) setNegSoundUrl(sNeg);
      if (sTim) setTimerSoundUrl(sTim);
      if (sWheelSpin) setWheelSpinSoundUrl(sWheelSpin);
      if (sWheelFinish) setWheelFinishSoundUrl(sWheelFinish);

      const savedLuckyWheelRewards = localStorage.getItem(LUCKY_WHEEL_REWARDS_KEY);
      if (savedLuckyWheelRewards) {
        const parsedRewards = JSON.parse(savedLuckyWheelRewards);
        if (Array.isArray(parsedRewards) && parsedRewards.length > 0) {
          setLuckyWheelRewards(parsedRewards);
          setLuckyWheelDisplayRewards(parsedRewards);
        }
      } else {
        setLuckyWheelRewards(DEFAULT_LUCKY_WHEEL_REWARDS);
        setLuckyWheelDisplayRewards(DEFAULT_LUCKY_WHEEL_REWARDS);
      }

      const savedBossFrequency = localStorage.getItem(BOSS_ENCOUNTER_FREQUENCY_KEY);
      const localBossFrequency = isBossEncounterFrequency(savedBossFrequency)
        ? savedBossFrequency
        : DEFAULT_BOSS_ENCOUNTER_FREQUENCY;
      setBossEncounterFrequency(localBossFrequency);
      const savedBossStates = localStorage.getItem(BOSS_STATES_KEY);
      if (savedBossStates) {
        try {
          setBossStatesByClass(normalizeBossStatesByClass(JSON.parse(savedBossStates), localBossFrequency));
        } catch (err) {
          console.error("Failed to parse saved boss states", err);
          setBossStatesByClass({});
        }
      } else {
        setBossStatesByClass({});
      }
    }
  }, [authLoading, user]);

  useEffect(() => { 
    if (!user) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students)); 
    }
  }, [students, user]);

  useEffect(() => {
    if (!user) {
      localStorage.setItem(BOSS_STATES_KEY, JSON.stringify(bossStatesByClass));
    }
  }, [bossStatesByClass, user]);

  useEffect(() => {
    localStorage.setItem(BOSS_ENCOUNTER_FREQUENCY_KEY, bossEncounterFrequency);
  }, [bossEncounterFrequency]);

  useEffect(() => { 
    if (!user) {
      localStorage.setItem(RANKS_KEY_MALE, JSON.stringify(ranksMale)); 
    }
  }, [ranksMale, user]);

  useEffect(() => { 
    if (!user) {
      localStorage.setItem(RANKS_KEY_FEMALE, JSON.stringify(ranksFemale)); 
    }
  }, [ranksFemale, user]);

  useEffect(() => { 
    if (!user) {
      localStorage.setItem(SKILLS_KEY, JSON.stringify(skills)); 
    }
  }, [skills, user]);

  useEffect(() => {
    localStorage.setItem(LUCKY_WHEEL_REWARDS_KEY, JSON.stringify(luckyWheelRewards));
  }, [luckyWheelRewards]);

  useEffect(() => {
    const timestamp = Date.now();
    let changed = false;
    const updatedStudents = students.map(student => {
      const nextStudent = markExpeditionReadyIfDue(student, timestamp);
      if (nextStudent !== student) changed = true;
      return nextStudent;
    });
    if (changed) setStudents(updatedStudents);
  }, [students]);

  // Ranking Utility
  const getRank = (points: number, gender: Gender): RankInfo => {
    const list = gender === Gender.MALE ? ranksMale : ranksFemale;
    const sorted = [...list].sort((a, b) => b.minPoints - a.minPoints);
    return sorted.find(r => points >= r.minPoints) || list[0];
  };

  // Derived Data
  const classes = useMemo(() => ['Tất cả', ...Array.from(new Set(students.map(s => s.className)))], [students]);
  
  const currentClassStudents = useMemo(() => {
    let list = students.filter(s => filterClass === 'Tất cả' || s.className === filterClass);
    if (searchQuery) list = list.filter(s => s.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    if (sortType === 'name') list.sort((a, b) => a.name.localeCompare(b.name));
    else if (sortType === 'points-desc') list.sort((a, b) => b.points - a.points);
    else if (sortType === 'points-asc') list.sort((a, b) => a.points - b.points);
    return list;
  }, [students, filterClass, searchQuery, sortType]);

  const giftPokemonRoster = useMemo(
    () => students
      .filter(student => filterClass === 'Tất cả' || student.className === filterClass)
      .sort((a, b) => a.name.localeCompare(b.name)),
    [students, filterClass]
  );

  const presentStudents = useMemo(() => currentClassStudents.filter(s => !s.isAbsent), [currentClassStudents]);
  const homeworkLessonDateKey = getLocalDateKey();
  const editingPetEvolutionPreview = useMemo(() => getNextEvolutionPreview(editingStudent?.pet), [editingStudent?.pet]);
  const classOptions = useMemo(() => classes.filter(c => c !== 'Tất cả'), [classes]);
  const activeRandomClassName = filterClass !== 'Tất cả' ? filterClass : '';
  const currentBossFrequencyOption = useMemo(
    () => getBossEncounterFrequencyOption(bossEncounterFrequency),
    [bossEncounterFrequency]
  );
  const currentBossState = activeRandomClassName
    ? normalizeClassBossState(bossStatesByClass[activeRandomClassName], activeRandomClassName, bossEncounterFrequency)
    : null;
  const activeBossParty = activeBossRound
    ? activeBossRound.partyStudentIds
      .map(studentId => students.find(student => student.id === studentId))
      .filter(Boolean) as Student[]
    : [];
  const studentsById = useMemo(() => Object.fromEntries(students.map(student => [student.id, student])), [students]);
  const currentBossTopContributors = currentBossState
    ? getBossTopContributors(currentBossState).map(contribution => ({
      contribution,
      student: studentsById[contribution.studentId]
    }))
    : [];
  const luckyWheelBackground = useMemo(() => {
    const rewardsForWheel = luckyWheelDisplayRewards.length > 0 ? luckyWheelDisplayRewards : luckyWheelRewards;
    if (rewardsForWheel.length === 0) return '#facc15';
    const sliceSize = 100 / rewardsForWheel.length;
    return `conic-gradient(${rewardsForWheel.map((reward, idx) => `${reward.color} ${idx * sliceSize}% ${(idx + 1) * sliceSize}%`).join(', ')})`;
  }, [luckyWheelDisplayRewards, luckyWheelRewards]);

  useEffect(() => {
    if (!activeRandomClassName) return;
    setBossStatesByClass(prev => {
      if (prev[activeRandomClassName]) return prev;
      return {
        ...prev,
        [activeRandomClassName]: createClassBossState(activeRandomClassName, Date.now(), bossEncounterFrequency)
      };
    });
  }, [activeRandomClassName, bossEncounterFrequency]);

  const activeLudoClassName = ludoClassName || (filterClass !== 'Tất cả' ? filterClass : classOptions[0] || '');
  const ludoRaceStudents = useMemo(() => {
    if (!activeLudoClassName) return [];
    return students
      .filter(s => s.className === activeLudoClassName && !s.isAbsent)
      .sort((a, b) => a.name.localeCompare(b.name));
  }, [students, activeLudoClassName]);
  const effectiveLudoTiles = useMemo(
    () => ({ ...DEFAULT_LUDO_TILES, ...customLudoTiles }),
    [customLudoTiles]
  );
  const ludoSpecialTileCount = useMemo(
    () => Object.keys(effectiveLudoTiles).filter(tile => Number(tile) >= 0 && Number(tile) <= LUDO_FINISH_TILE).length,
    [effectiveLudoTiles]
  );

  useEffect(() => {
    if (ludoActiveStudent && ludoActiveStudent.className !== activeLudoClassName) {
      setLudoActiveStudent(null);
    }
  }, [activeLudoClassName, ludoActiveStudent]);

  const getWeatherMood = (weather?: TrainerWeather | null) => {
    if (!weather) return 'clear';
    if (!weather.isDay) return 'night';
    if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82, 95, 96, 99].includes(weather.weatherCode)) return 'rain';
    if ([71, 73, 75, 77, 85, 86].includes(weather.weatherCode)) return 'snow';
    if ([45, 48].includes(weather.weatherCode)) return 'fog';
    return 'sunny';
  };

  const getWeatherLabel = (code: number) => {
    if ([51, 53, 55, 56, 57, 61, 63, 65, 66, 67, 80, 81, 82].includes(code)) return 'Đang mưa';
    if ([95, 96, 99].includes(code)) return 'Có giông';
    if ([71, 73, 75, 77, 85, 86].includes(code)) return 'Có tuyết';
    if ([45, 48].includes(code)) return 'Có sương';
    if ([0, 1].includes(code)) return 'Trời quang';
    if ([2, 3].includes(code)) return 'Nhiều mây';
    return 'Thời tiết hiện tại';
  };

  const fetchWeatherForLocation = async (location: TrainerLocation) => {
    setWeatherLoading(true);
    setWeatherError(null);
    try {
      const weatherResponse = await fetch(`https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,weather_code,is_day&timezone=auto`);
      if (!weatherResponse.ok) throw new Error('Không tải được dữ liệu thời tiết.');
      const weatherJson = await weatherResponse.json();
      const current = weatherJson.current;
      const weather: TrainerWeather = {
        temperature: Math.round(current?.temperature_2m ?? 0),
        weatherCode: Number(current?.weather_code ?? 0),
        isDay: Number(current?.is_day ?? 1) === 1,
        updatedAt: Date.now(),
        label: getWeatherLabel(Number(current?.weather_code ?? 0))
      };
      setTrainerWeather(weather);
      setTrainerLocation(location);
      localStorage.setItem('trainer_weather_location', JSON.stringify(location));
      localStorage.setItem('trainer_weather_location_input', location.label);
      setWeatherLocationInput(location.label);
    } catch (err: any) {
      setWeatherError(err?.message || 'Không tải được dữ liệu thời tiết.');
    } finally {
      setWeatherLoading(false);
    }
  };

  const refreshWeatherByAddress = async () => {
    const query = weatherLocationInput.trim();
    if (!query) {
      setWeatherError('Hãy nhập địa chỉ hoặc thành phố.');
      return;
    }
    setWeatherLoading(true);
    setWeatherError(null);
    try {
      const geoResponse = await fetch(`https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=1&language=vi&format=json`);
      if (!geoResponse.ok) throw new Error('Không tìm thấy vị trí.');
      const geoJson = await geoResponse.json();
      const result = geoJson.results?.[0];
      if (!result) throw new Error('Không tìm thấy vị trí phù hợp.');
      await fetchWeatherForLocation({
        label: [result.name, result.admin1, result.country].filter(Boolean).join(', '),
        latitude: result.latitude,
        longitude: result.longitude
      });
    } catch (err: any) {
      setWeatherError(err?.message || 'Không tìm thấy vị trí phù hợp.');
      setWeatherLoading(false);
    }
  };

  const refreshWeatherByBrowserLocation = () => {
    if (!navigator.geolocation) {
      setWeatherError('Trình duyệt chưa hỗ trợ tự xác định vị trí.');
      return;
    }
    setWeatherLoading(true);
    setWeatherError(null);
    navigator.geolocation.getCurrentPosition(
      position => {
        fetchWeatherForLocation({
          label: 'Vị trí hiện tại',
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        });
      },
      () => {
        setWeatherError('Không lấy được vị trí tự động. Bạn có thể nhập địa chỉ thủ công.');
        setWeatherLoading(false);
      },
      { enableHighAccuracy: false, timeout: 10000 }
    );
  };

  useEffect(() => {
    if (trainerLocation) {
      fetchWeatherForLocation(trainerLocation);
    } else if (weatherLocationInput.trim()) {
      refreshWeatherByAddress();
    }
  }, []);

  // Actions
  const openLudoForClass = (className?: string, activeStudent?: Student | null, returnHint: LudoReturnHint = null) => {
    const nextClass = className || (filterClass !== 'Tất cả' ? filterClass : classOptions[0] || '');
    if (!nextClass) {
      alert("Chưa có lớp nào để mở đường đua Cá Ngựa.");
      return;
    }
    setLudoClassName(nextClass);
    setLudoActiveStudent(activeStudent && activeStudent.className === nextClass ? activeStudent : null);
    setLudoDice(null);
    setLudoReturnHint(returnHint);
    setShowLudoModal(true);
  };

  const openBattleLudoTurns = (turns: BattleLudoTurn[], returnHint: LudoReturnHint = 'battle') => {
    const validTurns = turns
      .map(turn => {
        const student = students.find(s => s.id === turn.studentId);
        return student && !student.isAbsent ? { turn, student } : null;
      })
      .filter(Boolean) as { turn: BattleLudoTurn; student: Student }[];

    if (validTurns.length === 0) {
      alert("Không có trainer hợp lệ để lắc Cá Ngựa sau Battle.");
      return;
    }

    setBattleLudoQueue(validTurns.map(item => item.turn));
    openLudoForClass(validTurns[0].student.className, validTurns[0].student, returnHint);
  };

  const handleRandomFromLudo = () => {
    setBattleLudoQueue([]);
    setLudoReturnHint(null);
    setShowLudoModal(false);
    window.setTimeout(() => handleRandom(), 0);
  };

  const getRandomIndex = (length: number) => {
    if (length <= 0) return 0;
    if (window.crypto?.getRandomValues) {
      const arr = new Uint32Array(1);
      window.crypto.getRandomValues(arr);
      return arr[0] % length;
    }
    return Math.floor(Math.random() * length);
  };

  const SPECIAL_POKEMON_DEX_IDS = new Set([
    144, 145, 146, 150, 151, 243, 244, 245, 249, 250, 251, 377, 378, 379, 380, 381, 382, 383, 384, 385, 386,
    480, 481, 482, 483, 484, 485, 486, 487, 488, 491, 492, 493, 494, 638, 639, 640, 641, 642, 643, 644, 645,
    646, 647, 648, 649, 716, 717, 718, 719, 720, 721, 772, 773, 785, 786, 787, 788, 789, 790, 791, 792,
    800, 801, 802, 807, 808, 809, 888, 889, 890, 891, 892, 893, 894, 895, 896, 897, 898, 905, 1001, 1002,
    1003, 1004, 1007, 1008, 1009, 1010, 1014, 1015, 1016, 1017, 1020, 1021, 1022, 1023, 1024, 1025
  ]);

  const LEGENDARY_POKEMON_DEX_IDS = new Set([
    144, 145, 146, 150, 151, 249, 250, 251, 382, 383, 384, 385, 386, 483, 484, 487, 491, 493, 643, 644, 646,
    716, 717, 718, 719, 720, 721, 888, 889, 890, 898, 1007, 1008, 1024, 1025
  ]);

  const createInstanceId = (prefix: string): string => {
    return globalThis.crypto?.randomUUID?.() || `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
  };

  const getEggRequiredProgress = (egg?: StudentEgg): number => egg?.requiredProgress || (egg?.kind === 'legendary' ? 30 : egg?.kind === 'special' ? 15 : 10);
  const getEggLabel = (kind: EggKind) => kind === 'legendary' ? 'Trứng huyền thoại' : kind === 'special' ? 'Trứng đặc biệt' : 'Trứng thường';
  const getEggCost = (kind: Exclude<EggKind, 'legendary'>) => kind === 'special' ? 20 : 10;

  const getRandomEggDexId = (kind: EggKind = 'normal') => {
    if (kind === 'legendary') {
      const legendaryPool = LIST_POKEMONS.filter(pokemon => LEGENDARY_POKEMON_DEX_IDS.has(pokemon.dexId));
      const pool = legendaryPool.length > 0 ? legendaryPool : LIST_POKEMONS.filter(pokemon => SPECIAL_POKEMON_DEX_IDS.has(pokemon.dexId));
      return pool[getRandomIndex(pool.length)]?.dexId || 150;
    }
    const specialPool = LIST_POKEMONS.filter(pokemon => SPECIAL_POKEMON_DEX_IDS.has(pokemon.dexId));
    const normalPool = LIST_POKEMONS.filter(pokemon => !SPECIAL_POKEMON_DEX_IDS.has(pokemon.dexId));
    const useSpecialPool = kind === 'special' || getRandomIndex(100) >= 80;
    const pool = useSpecialPool && specialPool.length > 0 ? specialPool : normalPool.length > 0 ? normalPool : LIST_POKEMONS;
    return pool[getRandomIndex(pool.length)]?.dexId || 25;
  };

  const createEgg = (kind: EggKind = 'normal', source: StudentEgg['source'] = 'shop'): StudentEgg => ({
    instanceId: createInstanceId('egg'),
    progress: 0,
    status: 'egg',
    assignedDexId: getRandomEggDexId(kind),
    kind,
    requiredProgress: kind === 'legendary' ? 30 : kind === 'special' ? 15 : 10,
    acquiredAt: Date.now(),
    source
  });

  const advanceEggForStudent = (student: Student, amount: number) => {
    let currentEgg = student.egg ? { ...student.egg } : amount > 0 ? createEgg('normal') : undefined;
    let currentStudent = student;
    let hatchedPet: PokemonPet | null = null;

    if (amount > 0 && currentEgg?.status === 'egg') {
      const requiredProgress = getEggRequiredProgress(currentEgg);
      const nextProgress = currentEgg.progress + amount;
      currentEgg = {
        ...currentEgg,
        requiredProgress,
        progress: Math.max(0, Math.min(requiredProgress, nextProgress))
      };

      if (currentEgg.progress >= requiredProgress) {
        currentEgg.status = 'hatched';
        hatchedPet = createPokemonPetFromDexId(currentEgg.assignedDexId);
        currentStudent = {
          ...currentStudent,
          pet: hatchedPet,
          pets: [hatchedPet, ...(currentStudent.pets || []).filter(p => !isSamePokemon(p, hatchedPet))],
          pokemonProgress: {
            ...currentStudent.pokemonProgress!,
            hatchedEggs: (currentStudent.pokemonProgress?.hatchedEggs || 0) + 1
          }
        };
        currentStudent = appendAdventureJournal(currentStudent, {
          type: 'pokemon-hatched',
          text: `${getPokemonDisplayName(hatchedPet)} hatched for ${student.name}.`,
          petInstanceId: hatchedPet.instanceId
        });
        if (hatchedPet.isShiny) {
          currentStudent = appendAdventureJournal(currentStudent, {
            type: 'shiny-acquired',
            text: `${student.name} discovered Shiny ${getPokemonDisplayName(hatchedPet)}.`,
            petInstanceId: hatchedPet.instanceId
          });
        }
      }
    }

    return {
      student: {
        ...currentStudent,
        egg: currentEgg
      },
      egg: currentEgg,
      hatchedPet
    };
  };

  const showHatchAnnouncement = (items: HatchAnnouncementItem[], fallbackMessage: string) => {
    setHatchAnnouncementItems(items.length > 0 ? items : null);
    setHatchSuccessMessage(fallbackMessage);
    setShowHatchModal(true);
  };

  const clearGiftPokemonTimers = () => {
    giftPokemonTimersRef.current.forEach(timerId => window.clearTimeout(timerId));
    giftPokemonTimersRef.current = [];
  };

  const resetGiftPokemonFlow = () => {
    clearGiftPokemonTimers();
    setGiftPokemonResult(null);
    setGiftAnimationPhase('select');
  };

  const closeGiftPokemonModal = () => {
    resetGiftPokemonFlow();
    setShowGiftPokemonModal(false);
  };

  const openGiftPokemonModal = () => {
    if (giftPokemonRoster.length === 0) {
      alert('Chưa có học sinh nào trong lớp hiện tại để tặng Pokémon.');
      return;
    }
    resetGiftPokemonFlow();
    setGiftStudentId(prev => giftPokemonRoster.some(student => student.id === prev) ? prev : giftPokemonRoster[0].id);
    setShowGiftPokemonModal(true);
  };

  const handleGiftPokemon = () => {
    const target = students.find(student => student.id === giftStudentId);
    if (!target || giftAnimationPhase === 'hatching') return;

    const normalizedTarget = normalizeStudentPokemonData(target);
    const hadExistingEgg = !!normalizedTarget.egg && normalizedTarget.egg.status === 'egg';
    const giftEgg = hadExistingEgg
      ? { ...normalizedTarget.egg! }
      : createEgg('special', 'reward');
    const giftReadyStudent: Student = {
      ...normalizedTarget,
      egg: {
        ...giftEgg,
        status: 'egg',
        requiredProgress: getEggRequiredProgress(giftEgg)
      }
    };
    const requiredProgress = getEggRequiredProgress(giftReadyStudent.egg);
    const eggResult = advanceEggForStudent(giftReadyStudent, requiredProgress);
    const hatchedPet = eggResult.hatchedPet || createPokemonPetFromDexId(giftReadyStudent.egg!.assignedDexId);
    const timestamp = Date.now();
    let nextStudent: Student = {
      ...eggResult.student,
      pet: hatchedPet,
      pets: updatePetInCollection(eggResult.student, hatchedPet),
      history: [{
        id: `${timestamp}${Math.random()}`,
        amount: 0,
        reason: `🎁 Tặng Pokémon: ${getPokemonDisplayName(hatchedPet)} nở từ ${getEggLabel(giftReadyStudent.egg!.kind || 'special')} (không trừ Hào Quang)`,
        timestamp
      }, ...eggResult.student.history].slice(0, 50)
    };

    nextStudent = appendAdventureJournal(nextStudent, {
      type: 'pokemon-hatched',
      text: `${getPokemonDisplayName(hatchedPet)} hatched as a gift for ${target.name}.`,
      petInstanceId: hatchedPet.instanceId
    }, timestamp);
    if (hatchedPet.isShiny) {
      nextStudent = appendAdventureJournal(nextStudent, {
        type: 'shiny-acquired',
        text: `${target.name} received Shiny ${getPokemonDisplayName(hatchedPet)} from Gift Pokemon.`,
        petInstanceId: hatchedPet.instanceId
      }, timestamp);
    }

    setGiftAnimationPhase('hatching');
    setGiftPokemonResult({
      student: nextStudent,
      pet: hatchedPet,
      egg: giftReadyStudent.egg!,
      hadExistingEgg
    });

    clearGiftPokemonTimers();
    giftPokemonTimersRef.current = [
      window.setTimeout(() => {
        setStudents(prev => prev.map(student => student.id === target.id ? nextStudent : student));
        if (editingStudent?.id === target.id) setEditingStudent(nextStudent);
        if (randomStudent?.id === target.id) setRandomStudent(nextStudent);
        setGiftPokemonResult({
          student: nextStudent,
          pet: hatchedPet,
          egg: giftReadyStudent.egg!,
          hadExistingEgg
        });
        setGiftAnimationPhase('revealed');
        showPokemonReaction([{ type: 'evolution', message: `${nextStudent.name}: ${getPokemonDisplayName(hatchedPet)} đã nở` }], 'Tặng Pokémon');
        new Audio(posSoundUrl).play().catch(() => {});
      }, 2200)
    ];
  };

  const handleSpendAuraToHatchEgg = (studentId: string) => {
    const target = students.find(student => student.id === studentId);
    if (!target?.egg || target.egg.status !== 'egg') {
      alert('Trainer này chưa có trứng đang ấp.');
      return;
    }

    const requiredProgress = getEggRequiredProgress(target.egg);
    const currentProgress = Math.max(0, target.egg.progress || 0);
    const remainingProgress = Math.max(0, requiredProgress - currentProgress);
    if (remainingProgress <= 0) {
      alert('Trứng đã đủ điểm ấp. Hãy bấm nở trứng ngay.');
      return;
    }
    if (target.points < remainingProgress) {
      alert(`Không đủ Hào Quang. Cần ${remainingProgress}đ để ấp nhanh, hiện có ${target.points}đ.`);
      return;
    }
    if (!window.confirm(`Đổi ${remainingProgress}đ Hào Quang để ấp nhanh ${getEggLabel(target.egg.kind || 'normal')}?`)) return;

    const timestamp = Date.now();
    const eggResult = advanceEggForStudent(target, remainingProgress);
    let nextStudent: Student = {
      ...eggResult.student,
      points: target.points - remainingProgress,
      history: [{
        id: `${timestamp}${Math.random()}`,
        amount: -remainingProgress,
        reason: `🥚 Đổi ${remainingProgress}đ Hào Quang để ấp nhanh ${getEggLabel(target.egg.kind || 'normal')}`,
        timestamp
      }, ...eggResult.student.history].slice(0, 50)
    };

    if (eggResult.hatchedPet) {
      showHatchAnnouncement(
        [{ studentId: target.id, studentName: target.name, pet: eggResult.hatchedPet }],
        `Tin vui! ${target.name} đã đổi ${remainingProgress}đ Hào Quang để trứng nở ra ${getPokemonDisplayName(eggResult.hatchedPet)}.`
      );
    }

    setStudents(prev => prev.map(student => student.id === studentId ? nextStudent : student));
    if (editingStudent?.id === studentId) setEditingStudent(nextStudent);
    if (randomStudent?.id === studentId) setRandomStudent(nextStudent);
    new Audio(posSoundUrl).play().catch(() => {});
  };

  const shuffleLuckyWheelRewards = (rewards: LuckyWheelReward[]) => {
    const next = [...rewards];
    for (let i = next.length - 1; i > 0; i -= 1) {
      const j = getRandomIndex(i + 1);
      [next[i], next[j]] = [next[j], next[i]];
    }
    return next;
  };

  const isGoodLuckyWheelReward = (reward: LuckyWheelReward) => {
    if (reward.type === 'points' || reward.type === 'hp') return (reward.amount || 0) > 0;
    return reward.type === 'pokemon' || reward.type === 'skill' || reward.type === 'ludo_rolls';
  };

  const getWeightedLudoFinishRewards = () => {
    const sourceRewards = luckyWheelRewards.length > 0 ? luckyWheelRewards : DEFAULT_LUCKY_WHEEL_REWARDS;
    const goodRewards = sourceRewards.filter(isGoodLuckyWheelReward);
    const badRewards = sourceRewards.filter(reward => !isGoodLuckyWheelReward(reward) && (reward.type === 'points' || reward.type === 'hp'));
    return {
      goodRewards,
      badRewards,
      displayRewards: shuffleLuckyWheelRewards([...goodRewards, ...badRewards])
    };
  };

  const chooseLuckyWheelReward = (validRewards: LuckyWheelReward[]) => {
    if (luckyWheelMode !== 'ludo-finish') return validRewards[getRandomIndex(validRewards.length)];

    const goodRewards = validRewards.filter(isGoodLuckyWheelReward);
    const badRewards = validRewards.filter(reward => !isGoodLuckyWheelReward(reward) && (reward.type === 'points' || reward.type === 'hp'));
    const preferGood = getRandomIndex(100) < 60;
    const preferredPool = preferGood ? goodRewards : badRewards;
    const fallbackPool = preferGood ? badRewards : goodRewards;
    const pool = preferredPool.length > 0 ? preferredPool : fallbackPool.length > 0 ? fallbackPool : validRewards;
    return pool[getRandomIndex(pool.length)];
  };

  const openLuckyWheelForLudoFinish = (student: Student) => {
    if (isLuckyWheelSpinning) return;
    const { displayRewards } = getWeightedLudoFinishRewards();
    setLuckyWheelMode('ludo-finish');
    setLuckyWheelCandidateIds([student.id]);
    setLuckyWheelDisplayRewards(displayRewards);
    setLuckyWheelPendingResult(null);
    setLuckyWheelResult(null);
    setShowLuckyWheelModal(true);
  };

  const isSamePokemon = (a?: PokemonPet, b?: PokemonPet) => {
    return isSamePokemonPet(a, b);
  };

  const queuePokemonReleaseEvents = (events: PokemonReleaseEvent[]) => {
    if (events.length === 0) return;
    setPokemonReleaseEvent(events[0]);
    setPokemonReleaseQueue(events.slice(1));
  };

  const showNextPokemonReleaseEvent = () => {
    setPokemonReleaseQueue(prev => {
      const [nextEvent, ...rest] = prev;
      setPokemonReleaseEvent(nextEvent || null);
      return rest;
    });
  };

  const handleSelectReplacementPokemon = (pet: PokemonPet) => {
    if (!pokemonReleaseEvent) return;
    setStudents(prev => prev.map(s => {
      if (s.id !== pokemonReleaseEvent.studentId) return s;
      const nextPet = normalizePokemonPet(pet);
      const nextStudent = { ...s, pet: nextPet, pets: updatePetInCollection(s, nextPet) };
      if (editingStudent?.id === s.id) setEditingStudent(nextStudent);
      return nextStudent;
    }));
    showNextPokemonReleaseEvent();
  };

  const handleOpenEggAfterRelease = () => {
    if (!pokemonReleaseEvent) return;
    const student = students.find(s => s.id === pokemonReleaseEvent.studentId);
    if (student) {
      setEditingStudent(student);
      setProfileTab('pet');
      setCurrentScreen('profile');
    }
    showNextPokemonReleaseEvent();
  };

  const handleUpdatePoints = async (ids: string[], amount: number, reason: string, source: GameEventSource = 'manual') => {
    if (isNaN(amount)) return;

    // Play Sound using dynamic URLs
    const sound = new Audio(amount >= 0 ? posSoundUrl : negSoundUrl);
    sound.play().catch(() => {});

    let hatchItems: HatchAnnouncementItem[] = [];
    let evolvedMessages: string[] = [];
    let progressionEvents: PokemonUiEvent[] = [];
    let releaseEventToShow: PokemonReleaseEvent | null = null;

    const updatedStudents = students.map(s => {
      if (ids.includes(s.id)) {
        const oldRank = getRank(s.points, s.gender);
        const newPoints = s.points + amount;
        const newRank = getRank(newPoints, s.gender);
        const history: HistoryItem = { id: Date.now().toString() + Math.random(), amount, reason, timestamp: Date.now() };

        if (ids.length === 1 && oldRank.id !== newRank.id) {
          generateEdict(s.name, newRank.title, newPoints > s.points).then(setEdict);
        }

        let currentStudent = normalizeStudentPokemonData(s);
        const eggProgressAmount = source === 'solo' ? (amount > 0 ? amount : 0) : amount;
        const eggResult = advanceEggForStudent(currentStudent, eggProgressAmount);
        currentStudent = eggResult.student;
        if (eggResult.hatchedPet) {
          hatchItems.push({ studentId: s.id, studentName: s.name, pet: eggResult.hatchedPet });
        }

        if (currentStudent.pet && amount !== 0) {
          const hpUpdate = applyPetHpDeltaToStudent(currentStudent, amount, `${reason}: ${amount >= 0 ? 'hồi' : 'mất'} ${Math.abs(amount)} HP`);
          currentStudent = hpUpdate.student;
          if (hpUpdate.releaseEvent && !releaseEventToShow) {
            releaseEventToShow = hpUpdate.releaseEvent;
          }
        }

        if (source === 'solo') {
          const progressionResult = applyGameEventToStudent(
            { ...currentStudent, points: newPoints },
            {
              type: 'SOLO_RESULT',
              source,
              studentId: s.id,
              auraDelta: amount,
              timestamp: Date.now()
            }
          );
          currentStudent = progressionResult.student;
          progressionEvents = [...progressionEvents, ...progressionResult.uiEvents];
          progressionResult.uiEvents
            .filter(event => event.type === 'evolution')
            .forEach(event => evolvedMessages.push(`Pokémon của ${s.name}: ${event.message}!`));
          const trainerXpGain = (amount > 0 ? 5 : 0)
            + (progressionResult.uiEvents.some(event => event.type === 'evolution') ? 15 : 0);
          currentStudent = applyTrainerJourneyProgress(
            currentStudent,
            trainerXpGain,
            Date.now(),
            progressionEvents,
            amount > 0 ? 'Positive Solo' : undefined
          );
          if (amount > 0) {
            currentStudent = addWeeklyChestProgress(currentStudent, 3);
          }
        }

        return {
          ...currentStudent,
          points: newPoints,
          history: [history, ...currentStudent.history].slice(0, 50),
          egg: eggResult.egg
        };
      }
      return s;
    });

    setStudents(updatedStudents);
    if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);

    // Keep profile details in sync if points were changed while viewing them
    if (editingStudent && ids.includes(editingStudent.id)) {
      const updatedSelf = updatedStudents.find(x => x.id === editingStudent.id);
      if (updatedSelf) setEditingStudent(updatedSelf);
    }
    if (randomStudent && ids.includes(randomStudent.id)) {
      const updatedRandomStudent = updatedStudents.find(x => x.id === randomStudent.id);
      if (updatedRandomStudent) setRandomStudent(updatedRandomStudent);
    }

    if (source === 'solo' && !releaseEventToShow) {
      const toastEvents: PokemonUiEvent[] = [
        ...progressionEvents.filter(event => ['xp', 'bond', 'streak', 'passive', 'charge-ready', 'level-up', 'evolution', 'hp', 'random-drop', 'mastery'].includes(event.type))
      ];
      if (hatchItems.length > 0) {
        toastEvents.unshift({
          type: 'evolution',
          message: `Trứng của ${hatchItems.map(item => item.studentName).join(', ')} đã nở`
        });
      }
      const hasActivePetAfterUpdate = updatedStudents.some(student => ids.includes(student.id) && !!student.pet);
      if (amount !== 0 && hasActivePetAfterUpdate) {
        toastEvents.push({
          type: 'hp',
          message: amount > 0 ? `HP +${amount}` : `HP -${Math.abs(amount)}`
        });
      }
      showPokemonReaction(toastEvents, amount >= 0 ? 'Pokémon phản ứng vui vẻ' : 'Pokémon vẫn cố gắng');
      if (hatchItems.length > 0) {
        showHatchAnnouncement(
          hatchItems,
          `Tin vui! Trứng của ${hatchItems.map(item => item.studentName).join(', ')} đã nở ra Pokémon đồng hành mới.`
        );
      }
    } else if (hatchItems.length > 0) {
      showHatchAnnouncement(
        hatchItems,
        `Tin vui! Trứng của ${hatchItems.map(item => item.studentName).join(', ')} đã nở ra Pokémon đồng hành mới.`
      );
    } else if (evolvedMessages.length > 0) {
      setHatchAnnouncementItems(null);
      setHatchSuccessMessage(`✨ POKÉMON EVOLUTION ✨\n\n${evolvedMessages.join('\n')}\nHãy chúc mừng trainer và Pokémon đồng hành.`);
      setShowHatchModal(true);
    }

    setShowSkillModal(false);
    if (source !== 'solo') {
      setShowRandomModal(false);
    }
    setFeedbackSource('manual');
    setManualPoints('');
    setSelectedStudentIds(source === 'solo' ? ids : []);
    setIsMultiSelectMode(false);
    if (source === 'solo') {
      const resolvedClassName = updatedStudents.find(student => ids.includes(student.id))?.className;
      incrementBossCounterForClass(resolvedClassName);
      if (amount > 0 && ids.length === 1 && !releaseEventToShow) {
        const ludoStudent = updatedStudents.find(student => student.id === ids[0]);
        if (ludoStudent) {
          setShowRandomModal(false);
          openLudoForClass(ludoStudent.className, ludoStudent, 'solo');
        }
      }
    }
  };

  const handleBuySkill = (studentId: string, skillId: string, cost: number, skillName: string) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;
    if (student.points < cost) {
      alert(`Không đủ Hào quang! Trainer cần thêm ${cost - student.points} điểm để học skill ${skillName}.`);
      return;
    }

    if (!window.confirm(`Bạn có đồng ý tiêu hao ${cost} điểm Hào quang để rèn luyện tuyệt kỹ ${skillName} cho Pet?`)) return;

    const newPoints = student.points - cost;
    const historyItem: HistoryItem = {
      id: Date.now().toString(),
      amount: -cost,
      reason: `Học pháp bảo: ${skillName}`,
      timestamp: Date.now()
    };

    const updatedStudents = students.map(s => {
      if (s.id === studentId && s.pet) {
        const currentUses = s.pet.skillUses ? { ...s.pet.skillUses } : {};
        currentUses[skillId] = 0; // Reset usages to 0 on purchase!
        const updatedPet = {
          ...s.pet,
          skills: [...(s.pet.skills || []), skillId],
          skillUses: currentUses
        };
        const updatedS = {
          ...s,
          points: newPoints,
          pet: updatedPet,
          pets: updatePetInCollection(s, updatedPet),
          history: [historyItem, ...s.history].slice(0, 50)
        };
        // Update editingStudent too!
        setEditingStudent(updatedS);
        return updatedS;
      }
      return s;
    });

    setStudents(updatedStudents);
    new Audio(posSoundUrl).play().catch(() => {});
    alert(`Pokémon đã học skill ${skillName}! Khấu trừ ${cost} điểm.`);
  };

  const handleRenamePet = (studentId: string, newName: string) => {
    if (!newName.trim()) return;
    const updatedStudents = students.map(s => {
      if (s.id === studentId && s.pet) {
        const trimmedName = newName.trim();
        const updatedPet = {
          ...s.pet,
          nickname: trimmedName,
          name: trimmedName
        };
        const updatedS = { ...s, pet: updatedPet, pets: updatePetInCollection(s, updatedPet) };
        setEditingStudent(updatedS);
        return updatedS;
      }
      return s;
    });
    setStudents(updatedStudents);
  };

  const handleBuyNewEgg = (
    studentId: string,
    kind: Exclude<EggKind, 'legendary'> = 'normal',
    options: { skipConfirm?: boolean; silent?: boolean } = {}
  ) => {
    const s = students.find(x => x.id === studentId);
    if (!s) return false;
    const cost = getEggCost(kind);
    const eggLabel = getEggLabel(kind);
    const requiredProgress = kind === 'special' ? 15 : 10;
    if (s.points < cost) {
      alert(`Không đủ Hào quang! Trainer cần tối thiểu ${cost} điểm để mua ${eggLabel}.`);
      return false;
    }
    if (!options.skipConfirm && !window.confirm(`Bạn có đồng ý mua ${eggLabel} bằng cách tiêu hao ${cost}đ Hào Quang? Trứng này cần +${requiredProgress} Hào Quang để nở.`)) return false;
    
    // Save current companion in collection
    const currentActivePet = s.pet;
    let ownedPets = s.pets ? [...s.pets] : [];
    if (currentActivePet) {
      const exists = ownedPets.some(p => isSamePokemon(p, currentActivePet));
      if (!exists) {
        ownedPets.push(currentActivePet);
      }
    }

    const nextPoints = s.points - cost;
    const historyItem: HistoryItem = {
      id: Date.now().toString() + Math.random(),
      amount: -cost,
      reason: `Thỉnh ${eggLabel} Pokémon mới (-${cost}đ)`,
      timestamp: Date.now()
    };

    const updatedS: Student = {
      ...s,
      points: nextPoints,
      egg: createEgg(kind, 'shop'),
      pet: undefined, // Clear active pet so they see incubating layout
      pets: ownedPets,
      history: [historyItem, ...s.history].slice(0, 50)
    };

    setStudents(prev => prev.map(x => x.id === studentId ? updatedS : x));
    if (editingStudent?.id === studentId) setEditingStudent(updatedS);
    new Audio(posSoundUrl).play().catch(() => {});
    if (!options.silent) {
      alert(`Mua ${eggLabel} thành công! Hãy tích cực cộng điểm để sinh linh sớm thức tỉnh khỏi vỏ trứng.`);
    }
    return true;
  };

  const handleStartInventoryEgg = (studentId: string, eggInstanceId: string) => {
    const updatedStudents = students.map(student => {
      if (student.id !== studentId || student.egg?.status === 'egg') return student;
      const inventory = student.eggInventory || [];
      const chosenEgg = inventory.find(egg => egg.instanceId === eggInstanceId);
      if (!chosenEgg) return student;
      const updatedStudent = {
        ...student,
        egg: { ...chosenEgg, status: 'egg' as const },
        eggInventory: inventory.filter(egg => egg.instanceId !== eggInstanceId)
      };
      if (editingStudent?.id === student.id) setEditingStudent(updatedStudent);
      return updatedStudent;
    });
    setStudents(updatedStudents);
  };

  const renderEggInventory = (student: Student) => {
    const inventory = student.eggInventory || [];
    if (inventory.length === 0) return null;
    const counts = inventory.reduce<Record<string, number>>((acc, egg) => {
      const label = getEggLabel(egg.kind || 'normal');
      acc[label] = (acc[label] || 0) + 1;
      return acc;
    }, {});
    const canStartEgg = !student.egg || student.egg.status === 'hatched';

    return (
      <div className="rounded-[32px] border border-amber-200 bg-amber-50/60 p-5 text-left shadow-sm">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div>
            <h4 className="font-royal text-xl text-amber-950">🥚 Egg Inventory</h4>
            <p className="mt-1 text-xs font-bold text-amber-900/70">
              {Object.entries(counts).map(([label, count]) => `${label} x${count}`).join(' · ')}
            </p>
          </div>
          {!canStartEgg && (
            <span className="rounded-full bg-white px-3 py-1 text-[10px] font-black uppercase text-amber-700">
              Đang có trứng trong incubator
            </span>
          )}
        </div>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {inventory.map(egg => (
            <div key={egg.instanceId || `${egg.kind}-${egg.assignedDexId}-${egg.acquiredAt}`} className="flex items-center justify-between gap-3 rounded-2xl border border-amber-100 bg-white p-3">
              <div>
                <p className="text-xs font-black text-amber-950">{getEggLabel(egg.kind || 'normal')}</p>
                <p className="text-[10px] font-bold text-stone-400">Cần {getEggRequiredProgress(egg)} Hào Quang để nở</p>
              </div>
              <button
                disabled={!canStartEgg || !egg.instanceId}
                onClick={() => egg.instanceId && handleStartInventoryEgg(student.id, egg.instanceId)}
                className="rounded-xl bg-amber-600 px-3 py-2 text-[10px] font-black uppercase tracking-wider text-white shadow-sm hover:bg-amber-700 disabled:bg-stone-200 disabled:text-stone-500"
              >
                Bắt đầu ấp
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const renderExpeditionPanel = (student: Student) => {
    const expedition = student.expedition;
    const now = Date.now();
    const readyStudent = markExpeditionReadyIfDue(student, now);
    const readyExpedition = readyStudent.expedition;
    const isReady = readyExpedition?.status === 'ready';
    const remainingMs = readyExpedition && readyExpedition.status === 'active'
      ? Math.max(0, readyExpedition.resolvesAt - now)
      : 0;
    const remainingHours = Math.ceil(remainingMs / (60 * 60 * 1000));

    return (
      <div className="rounded-[32px] border border-emerald-200 bg-emerald-50/70 p-5 text-left shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-royal text-xl text-emerald-950">🧭 Pokémon Expedition</h4>
            <p className="mt-1 text-xs font-bold text-emerald-900/70">
              {!student.pet
                ? 'Cần active Pokémon để đi expedition.'
                : !readyExpedition
                  ? 'Chưa có expedition. Chốt điểm danh buổi mới để tự bắt đầu.'
                  : isReady
                    ? 'Pokémon đã trở về và có quà sẵn sàng.'
                    : `Đang khám phá. Còn khoảng ${remainingHours} giờ.`}
            </p>
          </div>
          {isReady && (
            <button
              onClick={() => {
                const result = claimReadyExpedition(readyStudent);
                setEditingStudent(result.student);
                setStudents(prev => prev.map(current => current.id === student.id ? result.student : current));
                if (result.message) showPokemonReaction([{ type: 'xp', message: result.message }], 'Expedition hoàn tất');
              }}
              className="rounded-2xl bg-emerald-700 px-4 py-2 text-[10px] font-black uppercase tracking-wider text-white shadow-md hover:bg-emerald-800"
            >
              Nhận quà
            </button>
          )}
        </div>
        {readyExpedition?.reward && (
          <div className="mt-3 grid grid-cols-3 gap-2 text-center text-[10px] font-black text-emerald-900">
            <span className="rounded-2xl bg-white p-2">XP +{readyExpedition.reward.xp}</span>
            <span className="rounded-2xl bg-white p-2">Bond +{readyExpedition.reward.bond}</span>
            <span className="rounded-2xl bg-white p-2">{readyExpedition.reward.rare ? 'Rare Loot' : 'Loot'}</span>
          </div>
        )}
      </div>
    );
  };

  const renderWeeklyChestPanel = (student: Student) => {
    const weekKey = getLocalWeekKey();
    const chest = student.weeklyChest?.weekKey === weekKey
      ? student.weeklyChest
      : { weekKey, progress: 0, claimed: false };
    const fragments = student.eggFragments || {};

    return (
      <div className="rounded-[32px] border border-sky-200 bg-sky-50/70 p-5 text-left shadow-sm">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h4 className="font-royal text-xl text-sky-950">🎁 Weekly Chest</h4>
            <p className="mt-1 text-xs font-bold text-sky-900/70">
              Tuần {chest.weekKey} · {chest.claimed ? 'Đã nhận' : chest.progress >= 100 ? 'Sẵn sàng mở' : `${chest.progress}/100`}
            </p>
          </div>
          <button
            disabled={chest.progress < 100 || chest.claimed}
            onClick={() => {
              const result = claimWeeklyChest({ ...student, weeklyChest: chest });
              setEditingStudent(result.student);
              setStudents(prev => prev.map(current => current.id === student.id ? result.student : current));
              showPokemonReaction([{ type: 'random-drop', message: result.message }], 'Weekly Chest');
            }}
            className="rounded-2xl bg-sky-700 px-4 py-2 text-[10px] font-black uppercase tracking-wider text-white shadow-md hover:bg-sky-800 disabled:bg-stone-200 disabled:text-stone-500"
          >
            Mở rương
          </button>
        </div>
        <div className="mt-3 h-2 overflow-hidden rounded-full bg-white">
          <div className="h-full rounded-full bg-sky-600" style={{ width: `${Math.min(100, chest.progress)}%` }} />
        </div>
        <div className="mt-4 grid gap-2 sm:grid-cols-2">
          {(['normal', 'special'] as const).map(kind => (
            <div key={kind} className="flex items-center justify-between rounded-2xl bg-white p-3 text-xs font-black text-sky-950">
              <span>{getEggLabel(kind)} Fragment: {fragments[kind] || 0}/10</span>
              <button
                disabled={(fragments[kind] || 0) < 10}
                onClick={() => {
                  const result = craftEggFromFragments(student, kind);
                  setEditingStudent(result.student);
                  setStudents(prev => prev.map(current => current.id === student.id ? result.student : current));
                  showPokemonReaction([{ type: 'random-drop', message: result.message }], 'Craft Egg');
                }}
                className="rounded-xl bg-amber-600 px-3 py-1.5 text-[9px] font-black uppercase text-white disabled:bg-stone-200 disabled:text-stone-500"
              >
                Craft
              </button>
            </div>
          ))}
        </div>
      </div>
    );
  };

  const getSupportPetForStudent = (student: Student): PokemonPet | undefined => {
    return (student.pets || []).find(pet => pet.instanceId === student.supportPetInstanceId);
  };

  const getSynergyLabel = (student: Student): string | null => {
    const activeBase = student.pet?.baseDexId || student.pet?.dexId;
    const support = getSupportPetForStudent(student);
    const supportBase = support?.baseDexId || support?.dexId;
    const pair = new Set([activeBase, supportBase]);
    if (pair.has(4) && pair.has(7)) return '🔥💧 Kanto Partners';
    if (pair.has(25) && pair.has(133)) return '⚡🌟 Best Friends';
    if (pair.has(1) && pair.has(4)) return '🌱🔥 Starter Spark';
    return null;
  };

  const handleOpenShop = () => {
    if (currentClassStudents.length === 0) {
      alert('Chưa có trainer trong lớp hiện tại để mở Shop.');
      return;
    }
    setShopSelections({});
    setShopReview(null);
    setShowShopModal(true);
  };

  const toggleShopEgg = (studentId: string, kind: Exclude<EggKind, 'legendary'>) => {
    setShopSelections(prev => {
      const current = prev[studentId] || { skills: [] };
      return {
        ...prev,
        [studentId]: {
          ...current,
          egg: current.egg === kind ? undefined : kind
        }
      };
    });
  };

  const toggleShopSkill = (studentId: string, skillId: string) => {
    setShopSelections(prev => {
      const current = prev[studentId] || { skills: [] };
      const hasSkill = current.skills.includes(skillId);
      return {
        ...prev,
        [studentId]: {
          ...current,
          skills: hasSkill ? current.skills.filter(id => id !== skillId) : [...current.skills, skillId]
        }
      };
    });
  };

  const buildShopReview = (): ShopReviewItem[] => currentClassStudents
    .map(student => {
      const selection = shopSelections[student.id] || { skills: [] };
      const ownedSkillIds = student.pet?.skills || [];
      const skillIds = selection.skills.filter(skillId => student.pet && !ownedSkillIds.includes(skillId));
      const selectedSkills = skillIds
        .map(skillId => petSkills.find(skill => skill.id === skillId))
        .filter(Boolean) as PetSkill[];
      const skillCost = selectedSkills.reduce((sum, skill) => sum + skill.cost, 0);
      const eggCost = selection.egg ? getEggCost(selection.egg) : 0;
      const totalCost = skillCost + eggCost;
      const itemLabels = [
        ...selectedSkills.map(skill => `${skill.icon} ${skill.name}`),
        ...(selection.egg ? [`🥚 ${getEggLabel(selection.egg)}`] : [])
      ];

      return {
        studentId: student.id,
        studentName: student.name,
        pointBalance: student.points,
        egg: selection.egg,
        skillIds,
        itemLabels,
        totalCost,
        canAfford: totalCost > 0 && student.points >= totalCost
      };
    })
    .filter(item => item.totalCost > 0);

  const handlePrepareShopPurchase = () => {
    const reviewItems = buildShopReview();
    if (reviewItems.length === 0) {
      alert('Chưa tick món nào trong Shop.');
      return;
    }
    setShopReview(reviewItems);
  };

  const handleConfirmShopPurchase = () => {
    if (!shopReview) return;
    const purchasableItems = shopReview.filter(item => item.canAfford);
    if (purchasableItems.length === 0) {
      alert('Chưa có trainer nào đủ Hào Quang để mua các món đã chọn.');
      return;
    }
    const purchaseMap = new Map(purchasableItems.map(item => [item.studentId, item]));
    const timestamp = Date.now();

    const updatedStudents = students.map(student => {
      const item = purchaseMap.get(student.id);
      if (!item) return student;

      let updatedStudent = normalizeStudentPokemonData(student);
      let updatedPet = updatedStudent.pet;
      const historyItems: HistoryItem[] = [];

      if (updatedPet && item.skillIds.length > 0) {
        const currentUses = updatedPet.skillUses ? { ...updatedPet.skillUses } : {};
        item.skillIds.forEach(skillId => {
          currentUses[skillId] = 0;
        });
        updatedPet = {
          ...updatedPet,
          skills: [...(updatedPet.skills || []), ...item.skillIds],
          skillUses: currentUses
        };
        updatedStudent = {
          ...updatedStudent,
          pet: updatedPet,
          pets: updatePetInCollection(updatedStudent, updatedPet)
        };
      }

      if (item.egg) {
        const currentActivePet = updatedStudent.pet;
        let ownedPets = updatedStudent.pets ? [...updatedStudent.pets] : [];
        if (currentActivePet && !ownedPets.some(p => isSamePokemon(p, currentActivePet))) {
          ownedPets.push(currentActivePet);
        }
        updatedStudent = {
          ...updatedStudent,
          egg: createEgg(item.egg),
          pet: undefined,
          pets: ownedPets
        };
      }

      historyItems.push({
        id: `${timestamp}${Math.random()}`,
        amount: -item.totalCost,
        reason: `🛒 Shop: ${item.itemLabels.join(', ')} (-${item.totalCost}đ)`,
        timestamp
      });

      return {
        ...updatedStudent,
        points: updatedStudent.points - item.totalCost,
        history: [...historyItems, ...updatedStudent.history].slice(0, 50)
      };
    });

    setStudents(updatedStudents);
    if (editingStudent) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    setShowShopModal(false);
    setShopReview(null);
    setShopSelections({});
    new Audio(posSoundUrl).play().catch(() => {});
    showPokemonReaction(
      [{ type: 'bond', message: `${purchasableItems.length} trainer đã mua đồ trong Shop` }],
      'Shop đã chốt đơn'
    );
  };

  const handleSelectActivePet = (studentId: string, chosenPet: PokemonPet) => {
    const s = students.find(x => x.id === studentId);
    if (!s) return;

    let ownedPets = s.pets ? [...s.pets] : [];
    
    // Backup active pet if any
    if (s.pet) {
      const exists = ownedPets.some(p => isSamePokemon(p, s.pet));
      if (!exists) {
        ownedPets.push(s.pet);
      }
    }

    // Load selected pet as active
    const nextPet = normalizePokemonPet(chosenPet);

    const updatedS: Student = {
      ...s,
      pet: nextPet,
      pets: updatePetInCollection({ ...s, pets: ownedPets }, nextPet)
    };

    setStudents(prev => prev.map(x => x.id === studentId ? updatedS : x));
    setEditingStudent(updatedS);
    alert(`Pokémon ${getPokemonDisplayName(nextPet)} đã trở lại đồng hành cùng trainer!`);
  };

  const handleSelectSupportPet = (studentId: string, supportPet?: PokemonPet) => {
    const updatedStudents = students.map(student => {
      if (student.id !== studentId) return student;
      const updatedStudent = {
        ...student,
        supportPetInstanceId: supportPet?.instanceId
      };
      if (editingStudent?.id === studentId) setEditingStudent(updatedStudent);
      return updatedStudent;
    });
    setStudents(updatedStudents);
  };

  const handleUsePetSkill = (studentId: string, skillId: string, skillName: string) => {
    const s = students.find(x => x.id === studentId);
    if (!s || !s.pet) return;

    const skillUses = s.pet.skillUses ? { ...s.pet.skillUses } : {};
    const currentUses = skillUses[skillId] || 0;

    if (currentUses >= 2) {
      alert("Tuyệt chiêu này đã cạn kiệt linh năng!");
      return;
    }

    if (!window.confirm(`Bạn có đồng ý kích hoạt skill [${skillName}] của Pokémon?`)) return;

    const nextUses = currentUses + 1;
    let skillsList = [...s.pet.skills];
    let alertMsg = "";

    if (nextUses >= 2) {
      // Exploded! Remove
      skillsList = skillsList.filter(id => id !== skillId);
      delete skillUses[skillId];
      alertMsg = `Kích hoạt thành công [${skillName}] (Lần 2/2)!\n\nChiêu pháp đã cạn pháp khí nên đã bốc hơi rã tiên! Hãy mua lại bí truyền nếu muốn dùng tiếp.`;
    } else {
      skillUses[skillId] = nextUses;
      alertMsg = `Kích hoạt thành công [${skillName}] (Lần 1/2)! Còn lại 1 lượt vận công pháp báu.`;
    }

    const historyItem: HistoryItem = {
      id: Date.now().toString() + Math.random(),
      amount: 0,
      reason: `[Pokémon] Kích hoạt skill: ${skillName} (${nextUses}/2)`,
      timestamp: Date.now()
    };

    const updatedPet = {
      ...s.pet,
      skills: skillsList,
      skillUses: skillUses
    };

    const updatedS: Student = {
      ...s,
      pet: updatedPet,
      pets: updatePetInCollection(s, updatedPet),
      history: [historyItem, ...s.history].slice(0, 50)
    };

    setStudents(prev => prev.map(x => x.id === studentId ? updatedS : x));
    setEditingStudent(updatedS);
    new Audio(posSoundUrl).play().catch(() => {});
    alert(alertMsg);
  };

  const handleExportJSON = () => {
    const data = {
      students,
      skills,
      petSkills,
      ranksMale,
      ranksFemale,
      posSoundUrl,
      negSoundUrl,
      timerSoundUrl,
      wheelSpinSoundUrl,
      wheelFinishSoundUrl,
      customLudoTiles,
      luckyWheelRewards,
      bossStatesByClass,
      bossEncounterFrequency,
      exportedAt: Date.now()
    };
    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `classivy_backup_${new Date().toISOString().slice(0,10)}.json`;
    link.click();
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const text = event.target?.result as string;
        const data = JSON.parse(text);

        const importedStudents = data.students && Array.isArray(data.students)
          ? data.students.map(normalizeStudentPokemonData)
          : [];
        if (data.students && Array.isArray(data.students)) {
          setStudents(importedStudents);
        }
        if (data.skills && Array.isArray(data.skills)) {
          setSkills(data.skills);
        }
        if (data.petSkills && Array.isArray(data.petSkills)) {
          setPetSkills(data.petSkills);
          localStorage.setItem(PET_SKILLS_KEY, JSON.stringify(data.petSkills));
        }
        if (data.ranksMale && Array.isArray(data.ranksMale)) {
          setRanksMale(data.ranksMale);
        }
        if (data.ranksFemale && Array.isArray(data.ranksFemale)) {
          setRanksFemale(data.ranksFemale);
        }
        if (data.posSoundUrl) {
          setPosSoundUrl(data.posSoundUrl);
        }
        if (data.negSoundUrl) {
          setNegSoundUrl(data.negSoundUrl);
        }
        if (data.timerSoundUrl) {
          setTimerSoundUrl(data.timerSoundUrl);
        }
        if (data.wheelSpinSoundUrl) {
          setWheelSpinSoundUrl(data.wheelSpinSoundUrl);
        }
        if (data.wheelFinishSoundUrl) {
          setWheelFinishSoundUrl(data.wheelFinishSoundUrl);
        }
        if (data.customLudoTiles && typeof data.customLudoTiles === 'object') {
          setCustomLudoTiles(data.customLudoTiles);
          localStorage.setItem('custom_ludo_tiles', JSON.stringify(data.customLudoTiles));
        }
        if (data.luckyWheelRewards && Array.isArray(data.luckyWheelRewards)) {
          setLuckyWheelRewards(data.luckyWheelRewards);
          setLuckyWheelDisplayRewards(data.luckyWheelRewards);
          localStorage.setItem(LUCKY_WHEEL_REWARDS_KEY, JSON.stringify(data.luckyWheelRewards));
        }
        const importedBossFrequency = isBossEncounterFrequency(data.bossEncounterFrequency)
          ? data.bossEncounterFrequency
          : bossEncounterFrequency;
        const importedBossStates = data.bossStatesByClass && typeof data.bossStatesByClass === 'object'
          ? normalizeBossStatesByClass(data.bossStatesByClass, importedBossFrequency)
          : {};
        setBossEncounterFrequency(importedBossFrequency);
        localStorage.setItem(BOSS_ENCOUNTER_FREQUENCY_KEY, importedBossFrequency);
        setBossStatesByClass(importedBossStates);
        localStorage.setItem(BOSS_STATES_KEY, JSON.stringify(importedBossStates));

        // Trigger immediate sync to Supabase if user is authenticated
        if (user) {
          setIsSyncing(true);
          upsertUserSettings(user.uid, {
              students: importedStudents,
              ranksMale: data.ranksMale || [],
              ranksFemale: data.ranksFemale || [],
              skills: data.skills || [],
              petSkills: data.petSkills || petSkills,
              posSoundUrl: data.posSoundUrl || "",
              negSoundUrl: data.negSoundUrl || "",
              timerSoundUrl: data.timerSoundUrl || "",
              wheelSpinSoundUrl: data.wheelSpinSoundUrl || wheelSpinSoundUrl,
              wheelFinishSoundUrl: data.wheelFinishSoundUrl || wheelFinishSoundUrl,
              customLudoTiles: data.customLudoTiles || customLudoTiles,
              luckyWheelRewards: data.luckyWheelRewards || luckyWheelRewards,
              bossStatesByClass: importedBossStates,
              bossEncounterFrequency: importedBossFrequency
          }).then((updatedAt) => {
            setLastSyncedTime(updatedAt);
            setIsSyncing(false);
          }).catch((err) => {
            console.error("Cloud sync during import failed:", err);
            setIsSyncing(false);
          });
        }

        alert("Đã phục hồi toàn bộ dữ liệu Trainer Hub thành công!");
      } catch (err) {
        console.error("Import JSON failed", err);
        alert("Có lỗi xảy ra: Không thể giải mã tập tin JSON này! Xin vui lòng kiểm tra lại cấu trúc file.");
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  const handleBackupToCloud = async (silent = false) => {
    if (!user) {
      if (!silent) alert("Vui lòng đăng nhập để thực hiện sao lưu lên đám mây!");
      return;
    }
    setIsSyncing(true);
    try {
      const updatedAt = await upsertUserSettings(user.uid, {
        students,
        ranksMale,
        ranksFemale,
        skills,
        petSkills,
        posSoundUrl,
        negSoundUrl,
        timerSoundUrl,
        wheelSpinSoundUrl,
        wheelFinishSoundUrl,
        customLudoTiles,
        luckyWheelRewards,
        bossStatesByClass,
        bossEncounterFrequency
      });
      setLastSyncedTime(updatedAt);
      if (!silent) {
        alert("Toàn bộ dữ liệu trainer, Pokémon và lớp học đã được sao lưu lên đám mây thành công!");
      }
    } catch (err) {
      console.error("Backup to Cloud failed:", err);
      if (!silent) {
        alert("Có lỗi xảy ra khi sao lưu lên đám mây: " + (err instanceof Error ? err.message : String(err)));
      }
    } finally {
      setIsSyncing(false);
    }
  };

  const handleRestoreFromCloud = async () => {
    if (!user) {
      alert("Vui lòng đăng nhập để phục hồi dữ liệu!");
      return;
    }
    if (!confirm("Người có chắc chắn muốn PHỤC HỒI dữ liệu từ đám mây? Thao tác này sẽ ghi đè toàn bộ dữ liệu hiện tại trên thiết bị!")) {
      return;
    }
    setIsSyncing(true);
    try {
      const cloudData = await fetchUserSettings(user.uid);

      if (cloudData) {
        if (cloudData.students && Array.isArray(cloudData.students)) {
          setStudents(cloudData.students);
        }
        if (cloudData.ranksMale && Array.isArray(cloudData.ranksMale)) {
          setRanksMale(cloudData.ranksMale);
        }
        if (cloudData.ranksFemale && Array.isArray(cloudData.ranksFemale)) {
          setRanksFemale(cloudData.ranksFemale);
        }
        if (cloudData.skills && Array.isArray(cloudData.skills)) {
          setSkills(cloudData.skills);
        }
        if (cloudData.petSkills && Array.isArray(cloudData.petSkills) && cloudData.petSkills.length > 0) {
          setPetSkills(cloudData.petSkills);
          localStorage.setItem(PET_SKILLS_KEY, JSON.stringify(cloudData.petSkills));
        }
        if (cloudData.posSoundUrl) {
          setPosSoundUrl(cloudData.posSoundUrl);
        }
        if (cloudData.negSoundUrl) {
          setNegSoundUrl(cloudData.negSoundUrl);
        }
        if (cloudData.timerSoundUrl) {
          setTimerSoundUrl(cloudData.timerSoundUrl);
        }
        if (cloudData.wheelSpinSoundUrl) {
          setWheelSpinSoundUrl(cloudData.wheelSpinSoundUrl);
          localStorage.setItem(WHEEL_SPIN_SOUND_KEY, cloudData.wheelSpinSoundUrl);
        }
        if (cloudData.wheelFinishSoundUrl) {
          setWheelFinishSoundUrl(cloudData.wheelFinishSoundUrl);
          localStorage.setItem(WHEEL_FINISH_SOUND_KEY, cloudData.wheelFinishSoundUrl);
        }
        if (cloudData.customLudoTiles && typeof cloudData.customLudoTiles === 'object') {
          setCustomLudoTiles(cloudData.customLudoTiles);
          localStorage.setItem('custom_ludo_tiles', JSON.stringify(cloudData.customLudoTiles));
        }
        if (cloudData.luckyWheelRewards && Array.isArray(cloudData.luckyWheelRewards) && cloudData.luckyWheelRewards.length > 0) {
          setLuckyWheelRewards(cloudData.luckyWheelRewards);
          setLuckyWheelDisplayRewards(cloudData.luckyWheelRewards);
          localStorage.setItem(LUCKY_WHEEL_REWARDS_KEY, JSON.stringify(cloudData.luckyWheelRewards));
        }
        const cloudBossFrequency = isBossEncounterFrequency(cloudData.bossEncounterFrequency)
          ? cloudData.bossEncounterFrequency
          : DEFAULT_BOSS_ENCOUNTER_FREQUENCY;
        const cloudBossStates = normalizeBossStatesByClass(cloudData.bossStatesByClass || {}, cloudBossFrequency);
        setBossEncounterFrequency(cloudBossFrequency);
        localStorage.setItem(BOSS_ENCOUNTER_FREQUENCY_KEY, cloudBossFrequency);
        setBossStatesByClass(cloudBossStates);
        localStorage.setItem(BOSS_STATES_KEY, JSON.stringify(cloudBossStates));
        setLastSyncedTime(cloudData.updatedAt || Date.now());
        alert("Đã khôi phục dữ liệu từ đám mây thành công!");
      } else {
        alert("Không tìm thấy bản sao lưu nào của người dùng này trên Đám mây!");
      }
    } catch (err) {
      console.error("Restore from Cloud failed:", err);
      alert("Có lỗi xảy ra khi phục hồi từ đám mây: " + (err instanceof Error ? err.message : String(err)));
    } finally {
      setIsSyncing(false);
    }
  };

  const handleDeleteStudents = () => {
    if (selectedStudentIds.length === 0) return;
    const count = selectedStudentIds.length;
    const confirmMsg = count === 1 
      ? `Bạn có chắc chắn muốn xóa trainer này?` 
      : `Bạn có chắc chắn muốn xóa ${count} trainer đã chọn?`;
    
    if (window.confirm(confirmMsg)) {
      setStudents(prev => prev.filter(s => !selectedStudentIds.includes(s.id)));
      setSelectedStudentIds([]);
      setIsMultiSelectMode(false);
    }
  };

  const resetPokemonLevelToOne = (pet: PokemonPet): PokemonPet => {
    return normalizePokemonPet({
      ...pet,
      level: 1,
      xp: 0,
      totalXp: 0,
      masteryXp: 0,
      masteryStars: 0
    });
  };

  const resetStudentPokemonLevels = (student: Student): Student => {
    const currentPets = student.pets && student.pets.length > 0 ? student.pets : (student.pet ? [student.pet] : []);
    const resetPets = currentPets.map(resetPokemonLevelToOne);
    const activePet = student.pet ? resetPokemonLevelToOne(student.pet) : undefined;
    const mergedPets = activePet
      ? [activePet, ...resetPets.filter(pet => !isSamePokemon(pet, activePet))]
      : resetPets;
    const uniquePets = mergedPets.filter((pet, index, pets) => pets.findIndex(candidate => isSamePokemon(candidate, pet)) === index);

    return {
      ...student,
      pet: activePet,
      pets: uniquePets
    };
  };

  const handleResetPokemonLevels = () => {
    const affectedCount = students.filter(student => student.pet || (student.pets && student.pets.length > 0)).length;
    if (affectedCount === 0) {
      alert('Chưa có trainer nào có Pokémon để reset level.');
      return;
    }
    if (!window.confirm(`Reset level toàn bộ Pokémon của ${affectedCount} trainer về Level 1? Hào Quang, HP, kỹ năng và phụ kiện vẫn được giữ nguyên.`)) {
      return;
    }

    const updatedStudents = students.map(resetStudentPokemonLevels);
    setStudents(updatedStudents);

    if (editingStudent) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    if (randomStudent) {
      const updatedRandomStudent = updatedStudents.find(student => student.id === randomStudent.id);
      if (updatedRandomStudent) setRandomStudent(updatedRandomStudent);
    }

    showPokemonReaction(
      [{ type: 'level-up', message: `${affectedCount} trainer: Pokémon đã về Level 1` }],
      'Reset Level Pokémon'
    );
  };

  const handleResetSelectedAura = () => {
    if (selectedStudentIds.length === 0) {
      alert('Hãy chọn trainer cần reset Hào Quang trước.');
      return;
    }
    const selectedStudents = students.filter(student => selectedStudentIds.includes(student.id));
    if (selectedStudents.length === 0) {
      alert('Không tìm thấy trainer đã chọn.');
      return;
    }
    if (!window.confirm(`Reset Hào Quang của ${selectedStudents.length} trainer đã chọn về 0? Pokémon hiện có vẫn được giữ nguyên.`)) {
      return;
    }

    const timestamp = Date.now();
    const selectedSet = new Set(selectedStudentIds);
    const updatedStudents = students.map(student => {
      if (!selectedSet.has(student.id)) return student;
      const historyItem: HistoryItem = {
        id: `${timestamp}${Math.random()}`,
        amount: -student.points,
        reason: '🧹 Reset Hào Quang về 0',
        timestamp
      };
      return {
        ...student,
        points: 0,
        history: [historyItem, ...student.history].slice(0, 50)
      };
    });

    setStudents(updatedStudents);
    if (editingStudent && selectedSet.has(editingStudent.id)) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    if (randomStudent && selectedSet.has(randomStudent.id)) {
      const updatedRandomStudent = updatedStudents.find(student => student.id === randomStudent.id);
      if (updatedRandomStudent) setRandomStudent(updatedRandomStudent);
    }
    setSelectedStudentIds([]);
    setIsMultiSelectMode(false);

    showPokemonReaction(
      [{ type: 'bond', message: `${selectedStudents.length} trainer đã reset Hào Quang về 0` }],
      'Reset Hào Quang'
    );
  };

  const handleClaimAllRewards = () => {
    const rewardRoster = students.filter(student => filterClass === 'Tất cả' || student.className === filterClass);
    if (rewardRoster.length === 0) {
      alert('Chưa có học sinh nào trong lớp hiện tại để nhận quà.');
      return;
    }

    const timestamp = Date.now();
    const weekKey = getLocalWeekKey();
    const targetIds = new Set(rewardRoster.map(student => student.id));
    const summaries: ClaimAllRewardSummary[] = [];

    const updatedStudents = students.map(student => {
      if (!targetIds.has(student.id)) return student;

      let nextStudent = markExpeditionReadyIfDue(student, timestamp);
      let expeditionMessage: string | undefined;
      let chestMessage: string | undefined;

      if (nextStudent.expedition?.status === 'ready') {
        const result = claimReadyExpedition(nextStudent, timestamp);
        nextStudent = result.student;
        expeditionMessage = result.message;
      }

      const chest = nextStudent.weeklyChest?.weekKey === weekKey
        ? nextStudent.weeklyChest
        : { weekKey, progress: 0, claimed: false };
      if (chest.progress >= 100 && !chest.claimed) {
        const result = claimWeeklyChest({ ...nextStudent, weeklyChest: chest });
        nextStudent = result.student;
        chestMessage = result.message;
      }

      if (expeditionMessage || chestMessage) {
        summaries.push({
          studentId: student.id,
          studentName: student.name,
          expeditionMessage,
          chestMessage
        });
      }

      return nextStudent;
    });

    setStudents(updatedStudents);
    if (editingStudent) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    if (randomStudent) {
      const updatedRandomStudent = updatedStudents.find(student => student.id === randomStudent.id);
      if (updatedRandomStudent) setRandomStudent(updatedRandomStudent);
    }
    setClaimAllRewardSummary(summaries);
    showPokemonReaction(
      [{ type: 'random-drop', message: summaries.length > 0 ? `${summaries.length} học sinh đã nhận quà` : 'Không có quà hoặc rương sẵn sàng' }],
      'Nhận quà cả lớp'
    );
  };

  const toggleAttendance = (id: string) => {
    setStudents(prev => prev.map(s => {
      if (s.id !== id) return s;
      const nextAbsent = !s.isAbsent;
      return {
        ...s,
        isAbsent: nextAbsent,
        attendanceStatus: nextAbsent ? 'absent' : 'present'
      };
    }));
  };

  const handleToggleSelectAll = () => {
    const activeClassStudents = currentClassStudents.filter(s => !s.isAbsent);
    if (activeClassStudents.length === 0) return;
    const activeIds = activeClassStudents.map(s => s.id);
    const isAllSelected = activeIds.length > 0 && activeIds.every(id => selectedStudentIds.includes(id));
    if (isAllSelected) {
      setSelectedStudentIds([]);
      setIsMultiSelectMode(false);
    } else {
      setSelectedStudentIds(activeIds);
      setIsMultiSelectMode(true);
    }
  };

  const openHomeworkCheck = () => {
    if (presentStudents.length === 0) {
      alert("Không có trainer đang hiện diện để check BTVN.");
      return;
    }
    const defaultStatuses: Record<string, HomeworkStatus> = {};
    presentStudents.forEach(student => {
      defaultStatuses[student.id] = 'done';
    });
    setHomeworkStatuses(defaultStatuses);
    setShowHomeworkModal(true);
  };

  const openAttendanceCheck = () => {
    if (currentClassStudents.length === 0) {
      alert("Không có trainer trong lớp hiện tại để check đi học.");
      return;
    }
    const defaultStatuses: Record<string, AttendanceStatus> = {};
    currentClassStudents.forEach(student => {
      defaultStatuses[student.id] = student.attendanceStatus || (student.isAbsent ? 'absent' : 'present');
    });
    setAttendanceStatuses(defaultStatuses);
    setShowAttendanceModal(true);
  };

  const setAttendanceStatus = (studentId: string, status: AttendanceStatus) => {
    setAttendanceStatuses(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const toggleHomeworkStatus = (studentId: string) => {
    setHomeworkStatuses(prev => ({
      ...prev,
      [studentId]: prev[studentId] === 'done' ? 'not-yet' : prev[studentId] === 'not-yet' ? 'missing' : 'done'
    }));
  };

  const setHomeworkStatus = (studentId: string, status: HomeworkStatus) => {
    setHomeworkStatuses(prev => ({
      ...prev,
      [studentId]: status
    }));
  };

  const handleConfirmHomeworkCheck = () => {
    const timestamp = Date.now();
    const uiEvents: PokemonUiEvent[] = [];
    const hatchItems: HatchAnnouncementItem[] = [];
    let doneCount = 0;
    let notYetCount = 0;
    let missingCount = 0;
    let skippedCount = 0;
    let releaseEventToShow: PokemonReleaseEvent | null = null;

    const updatedStudents = students.map(student => {
      if (!presentStudents.some(present => present.id === student.id)) return student;

      const lessonKey = `${student.className}:${homeworkLessonDateKey}`;
      if (student.pokemonProgress?.lastHomeworkLessonKey === lessonKey) {
        skippedCount += 1;
        return student;
      }

      const status = homeworkStatuses[student.id] || 'done';
      const baseStudent = normalizeStudentPokemonData(student);
      const historyItem: HistoryItem = {
        id: timestamp.toString() + Math.random(),
        amount: status === 'done' ? 8 : status === 'missing' ? -10 : 0,
        reason: status === 'done'
          ? `📚 Homework Done (${homeworkLessonDateKey}) (+8 Hào Quang, Pokémon +8 HP)`
          : status === 'missing'
            ? `📚 Homework Missing (${homeworkLessonDateKey}) (-10 Hào Quang, Pokémon -10 HP)`
            : `📚 Homework Not Yet (${homeworkLessonDateKey})`,
        timestamp
      };

      if (status === 'not-yet') {
        notYetCount += 1;
        return baseStudent;
      }

      if (status === 'missing') {
        missingCount += 1;
        const result = applyGameEventToStudent(baseStudent, {
          type: 'HOMEWORK_MISSING',
          source: 'homework',
          studentId: student.id,
          lessonKey,
          timestamp
        });
        let resultStudent = {
          ...result.student,
          points: result.student.points - 10
        };
        if (resultStudent.pet) {
          const hpUpdate = applyPetHpDeltaToStudent(resultStudent, -10, 'Homework Missing: mất 10 HP');
          resultStudent = hpUpdate.student;
          if (hpUpdate.releaseEvent && !releaseEventToShow) releaseEventToShow = hpUpdate.releaseEvent;
          uiEvents.push({ type: 'hp', message: `${student.name}: Pokémon -10 HP` });
        }
        return {
          ...resultStudent,
          history: [historyItem, ...resultStudent.history].slice(0, 50)
        };
      }

      doneCount += 1;
      const rewardedStudent = {
        ...baseStudent,
        points: baseStudent.points + 8
      };
      const result = applyGameEventToStudent(baseStudent, {
        type: 'HOMEWORK_COMPLETE',
        source: 'homework',
        studentId: student.id,
        lessonKey,
        timestamp
      });
      let resultStudent = {
        ...result.student,
        points: rewardedStudent.points
      };
      const eggResult = advanceEggForStudent(resultStudent, 8);
      resultStudent = eggResult.student;
      if (eggResult.hatchedPet) {
        uiEvents.push({ type: 'evolution', message: `${student.name}: trứng đã nở` });
        hatchItems.push({ studentId: student.id, studentName: student.name, pet: eggResult.hatchedPet });
      }
      if (resultStudent.pet) {
        const hpUpdate = applyPetHpDeltaToStudent(resultStudent, 8, 'Homework Done: hồi 8 HP');
        resultStudent = hpUpdate.student;
        uiEvents.push({ type: 'hp', message: `${student.name}: Pokémon +8 HP` });
      }
      uiEvents.push(...result.uiEvents);
      resultStudent = applyTrainerJourneyProgress(resultStudent, 10, timestamp, uiEvents, 'Homework Done');
      resultStudent = addWeeklyChestProgress(resultStudent, 15);

      return {
        ...resultStudent,
        history: [historyItem, ...resultStudent.history].slice(0, 50)
      };
    });

    setStudents(updatedStudents);
    if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
    if (editingStudent) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    setShowHomeworkModal(false);
    setHomeworkStatuses({});

    const summaryEvents: PokemonUiEvent[] = [
      { type: 'bond', message: `${doneCount} Done · ${notYetCount} Not Yet · ${missingCount} Missing${skippedCount ? ` · ${skippedCount} đã chốt` : ''}` },
      ...uiEvents.filter(event => ['xp', 'bond', 'hp', 'streak', 'passive', 'level-up', 'evolution', 'mastery'].includes(event.type)).slice(0, 3)
    ];
    showPokemonReaction(summaryEvents, 'Homework Check đã chốt');
    if (hatchItems.length > 0 && !releaseEventToShow) {
      showHatchAnnouncement(
        hatchItems,
        `Tin vui! Trứng của ${hatchItems.map(item => item.studentName).join(', ')} đã nở sau Homework.`
      );
    }
  };

  const handleConfirmAttendanceCheck = () => {
    const timestamp = Date.now();
    const lessonKeySuffix = getLocalDateKey();
    const uiEvents: PokemonUiEvent[] = [];
    const hatchItems: HatchAnnouncementItem[] = [];
    let presentCount = 0;
    let lateCount = 0;
    let absentCount = 0;
    let skippedCount = 0;
    let releaseEventToShow: PokemonReleaseEvent | null = null;

    const updatedStudents = students.map(student => {
      if (!currentClassStudents.some(classStudent => classStudent.id === student.id)) return student;

      const lessonKey = `${student.className}:${lessonKeySuffix}`;
      if (student.pokemonProgress?.lastAttendanceLessonKey === lessonKey) {
        skippedCount += 1;
        return student;
      }

      const status = attendanceStatuses[student.id] || 'present';
      const baseStudent = normalizeStudentPokemonData(student);
      const currentProgress = baseStudent.pokemonProgress!;
      const pointDelta = status === 'present' ? 5 : status === 'late' ? -5 : 0;
      const nextAttendanceStreak = status === 'absent' ? 0 : (currentProgress.attendanceStreak || 0) + 1;
      const nextProgress = {
        ...currentProgress,
        attendanceStreak: nextAttendanceStreak,
        bestAttendanceStreak: Math.max(currentProgress.bestAttendanceStreak || 0, nextAttendanceStreak),
        lastAttendanceLessonKey: lessonKey
      };
      const label = status === 'present' ? 'Có mặt' : status === 'late' ? 'Muộn' : 'Vắng';
      const historyItem: HistoryItem = {
        id: `${timestamp}${Math.random()}`,
        amount: pointDelta,
        reason: status === 'present'
          ? `🧭 Đi học Có mặt (${lessonKeySuffix}) (+5 Hào Quang, Pokémon +5 HP)`
          : status === 'late'
            ? `🧭 Đi học Muộn (${lessonKeySuffix}) (-5 Hào Quang, Pokémon -5 HP)`
            : `🧭 Đi học Vắng (${lessonKeySuffix})`,
        timestamp
      };

      if (status === 'present') presentCount += 1;
      if (status === 'late') lateCount += 1;
      if (status === 'absent') absentCount += 1;

      let resultStudent: Student = {
        ...baseStudent,
        points: baseStudent.points + pointDelta,
        pokemonProgress: nextProgress,
        isAbsent: status === 'absent',
        attendanceStatus: status,
        history: [historyItem, ...baseStudent.history].slice(0, 50)
      };

      if (pointDelta > 0) {
        const eggResult = advanceEggForStudent(resultStudent, pointDelta);
        resultStudent = eggResult.student;
        if (eggResult.hatchedPet) {
          hatchItems.push({ studentId: student.id, studentName: student.name, pet: eggResult.hatchedPet });
        }
      }

      if (resultStudent.pet && pointDelta !== 0) {
        const hpUpdate = applyPetHpDeltaToStudent(
          resultStudent,
          pointDelta,
          `Đi học ${label}: ${pointDelta > 0 ? 'hồi' : 'mất'} ${Math.abs(pointDelta)} HP`
        );
        resultStudent = hpUpdate.student;
        if (hpUpdate.releaseEvent && !releaseEventToShow) releaseEventToShow = hpUpdate.releaseEvent;
        uiEvents.push({ type: 'hp', message: `${student.name}: Pokémon ${pointDelta > 0 ? '+' : ''}${pointDelta} HP` });
      }

      if (status !== 'absent') {
        uiEvents.push({ type: 'streak', message: `${student.name}: streak đi học ${nextAttendanceStreak}` });
      }

      if (status === 'present') {
        resultStudent = applyTrainerJourneyProgress(resultStudent, 5, timestamp, uiEvents, 'Attendance');
        resultStudent = addWeeklyChestProgress(resultStudent, 10);
      }

      if (status !== 'absent') {
        resultStudent = ensureActiveExpedition(resultStudent, timestamp);
      }

      return resultStudent;
    });

    setStudents(updatedStudents);
    if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
    if (editingStudent) {
      const updatedEditingStudent = updatedStudents.find(student => student.id === editingStudent.id);
      if (updatedEditingStudent) setEditingStudent(updatedEditingStudent);
    }
    if (randomStudent) {
      const updatedRandomStudent = updatedStudents.find(student => student.id === randomStudent.id);
      if (updatedRandomStudent) setRandomStudent(updatedRandomStudent);
    }
    setShowAttendanceModal(false);
    setAttendanceStatuses({});

    if (hatchItems.length > 0 && !releaseEventToShow) {
      showHatchAnnouncement(
        hatchItems,
        `Tin vui! Trứng của ${hatchItems.map(item => item.studentName).join(', ')} đã nở sau điểm chuyên cần.`
      );
    }

    showPokemonReaction(
      [
        { type: 'bond', message: `${presentCount} Có mặt · ${lateCount} Muộn · ${absentCount} Vắng${skippedCount ? ` · ${skippedCount} đã chốt` : ''}` },
        ...uiEvents.slice(0, 3)
      ],
      'Check đi học đã chốt'
    );
  };

  const incrementBossCounterForClass = (className?: string) => {
    if (!className) return;
    setBossStatesByClass(prev => {
      const state = normalizeClassBossState(prev[className], className, bossEncounterFrequency);
      return {
        ...prev,
        [className]: incrementBossEncounterCounter(state)
      };
    });
  };

  const openBossEncounter = (className: string, state: ClassBossState, options: { notify?: boolean } = {}): boolean => {
    const classStudents = students.filter(student => student.className === className);
    const { party, nextQueue } = selectBossParty(classStudents, state.participantQueue, state.previousPartyIds);
    if (party.length < BOSS_PARTY_SIZE) {
      if (options.notify) {
        alert(`Boss đã xuất hiện nhưng cần ít nhất ${BOSS_PARTY_SIZE} trainer đang có Pokémon còn HP để chiến đấu.`);
      }
      return false;
    }

    const round: ActiveBossRound = {
      roundId: createInstanceId('boss-round'),
      bossInstanceId: state.boss.instanceId,
      className,
      partyStudentIds: party.map(student => student.id),
      openedAt: Date.now()
    };

    setBossStatesByClass(prev => ({
      ...prev,
      [className]: {
        ...state,
        encounterReady: true,
        participantQueue: nextQueue,
        updatedAt: Date.now()
      }
    }));
    setActiveBossRound(round);
    setRandomMode('boss');
    setRandomStudent(null);
    setBattleStudentA(null);
    setBattleStudentB(null);
    setBattleResultSummary(null);
    setSelectedStudentIds(round.partyStudentIds);
    setShowRandomModal(true);
    return true;
  };

  const handleRandom = (forceMode?: RandomMode) => {
    setBattleResultSummary(null);
    const available = presentStudents;
    if (available.length === 0) return alert("Không có trainer nào hiện diện.");

    if (activeRandomClassName) {
      if (activeBossRound?.className === activeRandomClassName) {
        setRandomMode('boss');
        setSelectedStudentIds(activeBossRound.partyStudentIds);
        setShowRandomModal(true);
        return;
      }
      const bossState = normalizeClassBossState(bossStatesByClass[activeRandomClassName], activeRandomClassName, bossEncounterFrequency);
      const bossReady = isBossEncounterReady(bossState);
      if (bossReady && openBossEncounter(activeRandomClassName, { ...bossState, encounterReady: true }, { notify: forceMode === 'boss' })) return;
      if (forceMode === 'boss') {
        setActiveBossRound(null);
        setRandomMode('boss');
        setShowRandomModal(true);
        return;
      }
    } else if (forceMode === 'boss') {
      setActiveBossRound(null);
      setRandomMode('boss');
      setShowRandomModal(true);
      return;
    }
    
    // Pick mode: if forceMode provided use it, otherwise randomly pick solo or battle (50/50 if available.length >= 2)
    const mode = forceMode && forceMode !== 'boss'
      ? forceMode
      : (available.length >= 2 ? (Math.random() > 0.5 ? 'battle' : 'solo') : 'solo');
    setRandomMode(mode);

    if (mode === 'solo') {
      let currentQueue = uncalledMap[filterClass] || [];
      currentQueue = currentQueue.filter(id => available.some(s => s.id === id));

      if (currentQueue.length === 0) {
        currentQueue = available.map(s => s.id);
      }

      const randomIndex = Math.floor(Math.random() * currentQueue.length);
      const chosenId = currentQueue[randomIndex];
      const nextQueue = currentQueue.filter(id => id !== chosenId);

      setUncalledMap(prev => ({ ...prev, [filterClass]: nextQueue }));

      const chosenStudent = students.find(s => s.id === chosenId) || available[0];
      setRandomStudent(chosenStudent);
      setSelectedStudentIds([chosenStudent.id]);
    } else {
      // Battle Mode: pick 2 distinct random students
      const shuffled = [...available].sort(() => 0.5 - Math.random());
      const sA = shuffled[0];
      const sB = shuffled[1];
      setBattleStudentA(sA);
      setBattleStudentB(sB);
      setBattleScoreA(0);
      setBattleScoreB(0);
      setSelectedStudentIds([sA.id, sB.id]);
    }

    setShowRandomModal(true);
  };

  const applyAuraRewardToStudent = (student: Student, amount: number, reason: string, timestamp: number): Student => {
    const historyItem: HistoryItem = {
      id: `${timestamp}${Math.random()}`,
      amount,
      reason,
      timestamp
    };
    let currentStudent: Student = {
      ...normalizeStudentPokemonData(student),
      points: student.points + amount
    };
    const eggResult = advanceEggForStudent(currentStudent, amount);
    currentStudent = eggResult.student;
    if (currentStudent.pet && amount !== 0) {
      const hpUpdate = applyPetHpDeltaToStudent(
        currentStudent,
        amount,
        `${reason}: ${amount > 0 ? 'hồi' : 'mất'} ${Math.abs(amount)} HP`
      );
      currentStudent = hpUpdate.student;
    }
    return {
      ...currentStudent,
      history: [historyItem, ...currentStudent.history].slice(0, 50)
    };
  };

  const handleResolveBossRound = (result: 'success' | 'failure') => {
    if (!activeBossRound || bossRoundResolving) return;
    const className = activeBossRound.className;
    const state = normalizeClassBossState(bossStatesByClass[className], className, bossEncounterFrequency);
    if (state.boss.instanceId !== activeBossRound.bossInstanceId) {
      alert('Boss round này đã cũ. Hãy Random lại để mở encounter mới.');
      setActiveBossRound(null);
      return;
    }

    setBossRoundResolving(true);
    setBossRoundVisualResult(result);
    window.setTimeout(() => setBossRoundVisualResult(null), 900);
    const timestamp = Date.now();
    const partyIds = activeBossRound.partyStudentIds;
    const resolution = result === 'success'
      ? resolveBossSuccess(state, partyIds, activeBossRound.roundId, timestamp, bossEncounterFrequency)
      : resolveBossFailure(state, partyIds, activeBossRound.roundId, timestamp, bossEncounterFrequency);
    const topRewardIds = resolution.bossDefeated ? new Set(resolution.topContributors.map(contribution => contribution.studentId)) : new Set<string>();
    const releaseEvents: PokemonReleaseEvent[] = [];
    const journeyEvents: PokemonUiEvent[] = [];

    const updatedStudents = students.map(student => {
      let nextStudent = normalizeStudentPokemonData(student);

      if (result === 'success' && partyIds.includes(student.id)) {
        nextStudent = applyAuraRewardToStudent(
          nextStudent,
          5,
          `👹 Boss Raid thành công: +5 Hào Quang`,
          timestamp
        );
        nextStudent = {
          ...nextStudent,
          pokemonProgress: {
            ...nextStudent.pokemonProgress!,
            bossSuccessfulRounds: (nextStudent.pokemonProgress?.bossSuccessfulRounds || 0) + 1
          }
        };
        nextStudent = applyTrainerJourneyProgress(nextStudent, 10, timestamp, journeyEvents, 'Boss Success');
        nextStudent = addWeeklyChestProgress(nextStudent, 5);
        nextStudent = appendAdventureJournal(nextStudent, {
          type: 'boss-win',
          text: `${nextStudent.name} helped land a successful hit on ${state.boss.name}.`,
          metadata: { damage: state.boss.damagePerSuccessfulStudent }
        }, timestamp);
      }

      if (result === 'failure' && partyIds.includes(student.id)) {
        const hpUpdate = applyPetHpDeltaToStudent(
          nextStudent,
          -state.boss.failDamage,
          `👹 Boss phản công: Pokémon -${state.boss.failDamage} HP`
        );
        nextStudent = hpUpdate.student;
        if (hpUpdate.releaseEvent) releaseEvents.push(hpUpdate.releaseEvent);
        nextStudent = {
          ...nextStudent,
          history: [{
            id: `${timestamp}${Math.random()}`,
            amount: 0,
            reason: `👹 Boss phản công: Pokémon -${state.boss.failDamage} HP`,
            timestamp
          }, ...nextStudent.history].slice(0, 50)
        };
      }

      if (topRewardIds.has(student.id)) {
        nextStudent = {
          ...nextStudent,
          pokemonProgress: {
            ...nextStudent.pokemonProgress!,
            bossTop5Finishes: (nextStudent.pokemonProgress?.bossTop5Finishes || 0) + 1
          }
        };
        nextStudent = applyAuraRewardToStudent(
          nextStudent,
          5,
          `🏆 Top 5 Boss Contributor: +5 Hào Quang + Legendary Egg`,
          timestamp
        );
        nextStudent = {
          ...nextStudent,
          eggInventory: [createEgg('legendary', 'boss'), ...(nextStudent.eggInventory || [])]
        };
        nextStudent = applyTrainerJourneyProgress(nextStudent, 25, timestamp, journeyEvents, 'Boss Top 5');
        nextStudent = appendAdventureJournal(nextStudent, {
          type: 'boss-top5',
          text: `${nextStudent.name} finished Top 5 against ${state.boss.name} and received a Legendary Egg.`
        }, timestamp);
      }

      return nextStudent;
    });

    setStudents(updatedStudents);
    setBossStatesByClass(prev => ({
      ...prev,
      [className]: resolution.state
    }));
    setActiveBossRound(null);
    setSelectedStudentIds([]);
    setBossRoundResolving(false);
    if (result === 'success') {
      const bossLudoTurns: BattleLudoTurn[] = partyIds.map(studentId => ({ studentId, role: 'boss' }));
      const firstBossStudent = updatedStudents.find(student => student.id === bossLudoTurns[0]?.studentId) || null;
      if (firstBossStudent) {
        setShowRandomModal(false);
        setBattleLudoQueue(bossLudoTurns);
        openLudoForClass(className, firstBossStudent, 'boss');
      }
    }

    if (releaseEvents.length > 0) queuePokemonReleaseEvents(releaseEvents);
    if (resolution.bossDefeated) {
      setBossDefeatedAnnouncement({
        boss: {
          ...state.boss,
          currentHp: 0,
          defeatedAt: timestamp
        },
        topContributors: resolution.topContributors
      });
    }

    const eventMessage = result === 'success'
      ? `Perfect Team Attack: ${state.boss.name} -${resolution.damageDealt} HP`
      : `${state.boss.name} phản công: Pokémon -${state.boss.failDamage} HP`;
    showPokemonReaction([{ type: result === 'success' ? 'hp' : 'random-drop', message: eventMessage }, ...journeyEvents.slice(0, 3)], result === 'success' ? 'Boss Raid thành công' : 'Boss Raid thất bại');
    new Audio(result === 'success' ? posSoundUrl : negSoundUrl).play().catch(() => {});
  };

  const getLuckyWheelValidRewards = (student: Student) => {
    const ownedSkillIds = student.pet?.skills || [];
    return luckyWheelRewards.filter(reward => {
      if (reward.type === 'hp') return !!student.pet;
      if (reward.type === 'skill') {
        return !!student.pet && petSkills.some(sk => !ownedSkillIds.includes(sk.id));
      }
      if (reward.type === 'ludo_rolls') return (reward.amount || 0) > 0;
      return true;
    });
  };

  const prepareLuckyWheelResult = (student: Student, reward: LuckyWheelReward): LuckyWheelResult => {
    if (reward.type === 'pokemon') {
      const randomPokemon = getRandomPokemon();
      const giftedPet = createPokemonPetFromDexId(randomPokemon.dexId);
      return {
        student,
        reward,
        pokemon: giftedPet,
        message: `${student.name} nhận được ${giftedPet.isShiny ? 'Shiny ' : ''}Pokémon ${getPokemonDisplayName(giftedPet)}!`
      };
    }

    if (reward.type === 'skill' && student.pet) {
      const ownedSkillIds = student.pet.skills || [];
      const availableSkills = petSkills.filter(sk => !ownedSkillIds.includes(sk.id));
      const giftedSkill = availableSkills[Math.floor(Math.random() * availableSkills.length)];
      return {
        student,
        reward,
        skill: giftedSkill,
        message: `${student.name} nhận thêm tuyệt chiêu ${giftedSkill.name} cho ${getPokemonDisplayName(student.pet)}!`
      };
    }

    if (reward.type === 'hp') {
      const hpDelta = reward.amount || 0;
      return {
        student,
        reward,
        hpDelta,
        message: hpDelta >= 0
          ? `Pokémon của ${student.name} hồi ${hpDelta} HP!`
          : `Pokémon của ${student.name} bị trừ ${Math.abs(hpDelta)} HP!`
      };
    }

    if (reward.type === 'ludo_rolls') {
      const rolls = Math.min(5, Math.max(1, reward.amount || 1));
      return {
        student,
        reward: { ...reward, amount: rolls },
        message: `${student.name} được thêm ${rolls} lượt lắc xúc xắc Cá Ngựa!`
      };
    }

    const pointAmount = reward.amount || 0;
    return {
      student,
      reward,
      message: `${student.name} ${pointAmount >= 0 ? 'được cộng' : 'bị trừ'} ${Math.abs(pointAmount)} điểm Hào quang!`
    };
  };

  const updateActivePetInCollection = (student: Student, nextPet: PokemonPet) => {
    return updatePetInCollection(student, nextPet);
  };

  const applyLuckyWheelReward = async (result: LuckyWheelResult) => {
    const reward = result.reward;

    if (reward.type === 'points') {
      await handleUpdatePoints([result.student.id], reward.amount || 0, `🎡 Vòng quay may mắn: ${reward.label}`, 'lucky-wheel');
      setLuckyWheelResult(result);
      setIsLuckyWheelSpinning(false);
      return;
    }

    const isPositiveReward = reward.type !== 'hp' || (result.hpDelta || 0) >= 0;
    let releaseEventToShow: PokemonReleaseEvent | null = null;

    setStudents(prev => {
      let updatedTarget: Student | null = null;

      const nextStudents = prev.map(s => {
        if (s.id !== result.student.id) return s;

        const historyItem: HistoryItem = {
          id: Date.now().toString() + Math.random(),
          amount: 0,
          reason: `🎡 Vòng quay may mắn: ${result.message}`,
          timestamp: Date.now()
        };

        if (reward.type === 'pokemon' && result.pokemon) {
          const currentPets = s.pets ? [...s.pets] : [];
          if (s.pet && !currentPets.some(p => isSamePokemon(p, s.pet))) {
            currentPets.push(s.pet);
          }
          let updatedS: Student = {
            ...s,
            pet: result.pokemon,
            pets: [result.pokemon, ...currentPets],
            history: [historyItem, ...s.history].slice(0, 50)
          };
          if (result.pokemon.isShiny) {
            updatedS = appendAdventureJournal(updatedS, {
              type: 'shiny-acquired',
              text: `${s.name} received Shiny ${getPokemonDisplayName(result.pokemon)} from Lucky Wheel.`,
              petInstanceId: result.pokemon.instanceId
            });
          }
          updatedTarget = updatedS;
          return updatedS;
        }

        if (reward.type === 'skill' && result.skill && s.pet) {
          const currentUses = s.pet.skillUses ? { ...s.pet.skillUses } : {};
          currentUses[result.skill.id] = 0;
          const updatedPet: PokemonPet = {
            ...s.pet,
            skills: [...(s.pet.skills || []), result.skill.id],
            skillUses: currentUses
          };
          const updatedS: Student = {
            ...s,
            pet: updatedPet,
            pets: updateActivePetInCollection(s, updatedPet),
            history: [historyItem, ...s.history].slice(0, 50)
          };
          updatedTarget = updatedS;
          return updatedS;
        }

        if (reward.type === 'hp' && s.pet) {
          const hpUpdate = applyPetHpDeltaToStudent(s, result.hpDelta || 0, `Vòng quay may mắn: ${reward.label}`);
          const updatedS: Student = {
            ...hpUpdate.student,
            history: [historyItem, ...hpUpdate.student.history].slice(0, 50)
          };
          if (hpUpdate.releaseEvent && !releaseEventToShow) releaseEventToShow = hpUpdate.releaseEvent;
          updatedTarget = updatedS;
          return updatedS;
        }

        if (reward.type === 'ludo_rolls') {
          const rolls = Math.min(5, Math.max(1, reward.amount || 1));
          setLudoBonusRolls(prevRolls => ({
            ...prevRolls,
            [s.id]: (prevRolls[s.id] || 0) + rolls
          }));
          setLudoClassName(s.className);
          setLudoActiveStudent(s);
          const updatedS: Student = {
            ...s,
            history: [historyItem, ...s.history].slice(0, 50)
          };
          updatedTarget = updatedS;
          return updatedS;
        }

        return s;
      });

      if (updatedTarget && editingStudent?.id === updatedTarget.id) {
        setEditingStudent(updatedTarget);
      }

      return nextStudents;
    });

    new Audio(isPositiveReward ? posSoundUrl : negSoundUrl).play().catch(() => {});
    if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
    setSelectedStudentIds([]);
    setIsMultiSelectMode(false);
    setLuckyWheelResult(result);
    setIsLuckyWheelSpinning(false);
  };

  const handleOpenLuckyWheel = () => {
    if (isLuckyWheelSpinning) return;

    const candidates = students.filter(s => selectedStudentIds.includes(s.id) && !s.isAbsent);
    if (candidates.length === 0) {
      alert("Vui lòng chọn ít nhất 1 trainer đang hiện diện để quay Vòng quay may mắn.");
      return;
    }

    setLuckyWheelCandidateIds(candidates.map(s => s.id));
    const shuffledRewards = shuffleLuckyWheelRewards(luckyWheelRewards.length > 0 ? luckyWheelRewards : DEFAULT_LUCKY_WHEEL_REWARDS);
    setLuckyWheelMode('normal');
    setLuckyWheelDisplayRewards(shuffledRewards);
    setLuckyWheelPendingResult(null);
    setLuckyWheelResult(null);
    setShowLuckyWheelModal(true);
  };

  const stopLuckyWheelSpinSound = () => {
    if (luckyWheelSpinAudioRef.current) {
      luckyWheelSpinAudioRef.current.pause();
      luckyWheelSpinAudioRef.current.currentTime = 0;
      luckyWheelSpinAudioRef.current = null;
    }
    if (luckyWheelSpinSynthRef.current) {
      window.clearInterval(luckyWheelSpinSynthRef.current.intervalId);
      luckyWheelSpinSynthRef.current.context.close().catch(() => {});
      luckyWheelSpinSynthRef.current = null;
    }
  };

  const playLuckyWheelSpinSound = () => {
    stopLuckyWheelSpinSound();

    const spinSoundUrl = wheelSpinSoundUrl.trim() || DEFAULT_WHEEL_SPIN_SOUND_URL;
    const spinAudio = new Audio(spinSoundUrl);
    spinAudio.loop = true;
    spinAudio.volume = 0.55;
    luckyWheelSpinAudioRef.current = spinAudio;
    spinAudio.play().catch(() => {});

    const AudioContextCtor = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextCtor) return;

    const context = new AudioContextCtor();
    const playTick = () => {
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = 'triangle';
      oscillator.frequency.value = 360 + Math.random() * 520;
      gain.gain.setValueAtTime(0.0001, context.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.12, context.currentTime + 0.01);
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + 0.085);
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start();
      oscillator.stop(context.currentTime + 0.09);
    };
    playTick();
    const intervalId = window.setInterval(playTick, 115);
    luckyWheelSpinSynthRef.current = { context, intervalId };
  };

  const startLuckyWheelSpin = () => {
    if (isLuckyWheelSpinning) return;

    const candidates = students.filter(s => luckyWheelCandidateIds.includes(s.id) && !s.isAbsent);
    if (candidates.length === 0) {
      alert("Không còn trainer hợp lệ trong lượt quay này.");
      return;
    }

    const chosenStudent = candidates[getRandomIndex(candidates.length)];
    const validRewards = getLuckyWheelValidRewards(chosenStudent);
    if (validRewards.length === 0) {
      alert("Không có phần thưởng/hình phạt hợp lệ cho trainer này. Vui lòng kiểm tra Customize Vòng quay may mắn.");
      return;
    }

    const displayRewards = luckyWheelDisplayRewards.length > 0 ? luckyWheelDisplayRewards : shuffleLuckyWheelRewards(luckyWheelRewards);
    const chosenReward = chooseLuckyWheelReward(validRewards);
    const preparedResult = prepareLuckyWheelResult(chosenStudent, chosenReward);
    const rewardIndex = Math.max(0, displayRewards.findIndex(reward => reward.id === chosenReward.id));
    const segmentSize = 360 / Math.max(1, displayRewards.length);
    const targetCenter = rewardIndex * segmentSize + segmentSize / 2;
    const startRotation = luckyWheelRotation % 360;
    const finalRotation = luckyWheelRotation + 360 * 12 + (360 - targetCenter);

    setLuckyWheelPendingResult(preparedResult);
    setLuckyWheelResult(null);
    setIsLuckyWheelSpinning(true);
    setLuckyWheelRotation(startRotation);

    playLuckyWheelSpinSound();

    window.requestAnimationFrame(() => {
      if (luckyWheelRef.current) {
        luckyWheelRef.current.getAnimations().forEach(animation => animation.cancel());
        luckyWheelRef.current.animate([
          { transform: `rotate(${startRotation}deg)`, offset: 0 },
          { transform: `rotate(${startRotation + 180}deg)`, offset: 0.15 },
          { transform: `rotate(${startRotation + 360 * 8}deg)`, offset: 0.7 },
          { transform: `rotate(${finalRotation}deg)`, offset: 1 }
        ], {
          duration: 10000,
          easing: 'linear',
          fill: 'forwards'
        });
      }
    });

    window.setTimeout(() => {
      stopLuckyWheelSpinSound();
      if (wheelFinishSoundUrl.trim()) {
        new Audio(wheelFinishSoundUrl).play().catch(() => {});
      }
      setLuckyWheelRotation(finalRotation);
      applyLuckyWheelReward(preparedResult);
    }, 10000);
  };

  const handleResolveBattle = () => {
    if (!battleStudentA || !battleStudentB) return;

    const scoreA = battleScoreA;
    const scoreB = battleScoreB;
    const diff = Math.abs(scoreA - scoreB);

    let updatedStudents = [...students];
    let resultMsg = "";
    let winner: Student | null = null;
    let releaseEventToShow: PokemonReleaseEvent | null = null;
    let battleProgressMessages: string[] = [];
    let battleUiEvents: PokemonUiEvent[] = [];
    let battleHatchedNames: string[] = [];
    let battleHatchItems: HatchAnnouncementItem[] = [];

    const applyBattleOutcome = (
      student: Student,
      pointGain: number,
      outcome: 'win' | 'loss' | 'draw',
      hpDelta: number | null,
      historyReason: string,
      hpReason?: string
    ): Student => {
      const newPts = student.points + pointGain;
      let baseStudent = normalizeStudentPokemonData(student);

      if (hpDelta !== null) {
        const hpUpdate = applyPetHpDeltaToStudent(baseStudent, hpDelta, hpReason || historyReason);
        baseStudent = hpUpdate.student;
        if (hpUpdate.releaseEvent && !releaseEventToShow) releaseEventToShow = hpUpdate.releaseEvent;
      }

      const progressionResult = applyGameEventToStudent(
        { ...baseStudent, points: newPts },
        {
          type: 'BATTLE_RESULT',
          source: 'battle',
          studentId: student.id,
          battleOutcome: outcome,
          battleScore: pointGain,
          timestamp: Date.now()
        }
      );
      battleUiEvents = [...battleUiEvents, ...progressionResult.uiEvents];

      battleProgressMessages = [
        ...battleProgressMessages,
        ...progressionResult.uiEvents
          .filter(event => ['streak', 'passive', 'charge-ready', 'level-up', 'evolution', 'random-drop', 'mastery'].includes(event.type))
          .map(event => `${student.name}: ${event.message}`)
      ];

      let eventStudent = progressionResult.student;
      if (pointGain > 0) {
        const eggResult = advanceEggForStudent(eventStudent, pointGain);
        eventStudent = eggResult.student;
        if (eggResult.hatchedPet) {
          battleHatchedNames.push(student.name);
          battleHatchItems.push({ studentId: student.id, studentName: student.name, pet: eggResult.hatchedPet });
          battleUiEvents.push({ type: 'evolution', message: `${student.name}: trứng đã nở` });
        }
      }

      const trainerXpGain = (outcome === 'win' ? 10 : 0)
        + (progressionResult.uiEvents.some(event => event.type === 'evolution') ? 15 : 0);
      const journeyStudent = applyTrainerJourneyProgress(
        eventStudent,
        trainerXpGain,
        Date.now(),
        battleUiEvents,
        outcome === 'win' ? 'Battle Win' : undefined
      );
      const chestStudent = addWeeklyChestProgress(journeyStudent, 3 + (outcome === 'win' ? 5 : 0));

      return {
        ...chestStudent,
        points: newPts,
        history: [
          { id: Date.now().toString() + Math.random(), amount: pointGain, reason: historyReason, timestamp: Date.now() },
          ...chestStudent.history
        ].slice(0, 50)
      };
    };

    if (scoreA > scoreB) {
      winner = battleStudentA;
      // A wins: A gets +scoreA points, Pokemon gets +diff HP. B gets +scoreB points, Pokemon loses diff HP (-diff HP).
      updatedStudents = updatedStudents.map(s => {
        if (s.id === battleStudentA.id) {
          return applyBattleOutcome(s, scoreA, 'win', diff, `🏆 Thắng Battle: +${scoreA}đ (Pokemon +${diff} HP)`, `Battle thắng: hồi ${diff} HP`);
        }
        if (s.id === battleStudentB.id) {
          return applyBattleOutcome(s, scoreB, 'loss', -diff, `⚔️ Thua Battle: +${scoreB}đ (Pokemon -${diff} HP)`, `Battle thua: mất ${diff} HP`);
        }
        return s;
      });

      resultMsg = `🏆 ${battleStudentA.name} CHIẾN THẮNG BATTLE!\n\n• ${battleStudentA.name}: +${scoreA} điểm Hào quang (Pokemon hồi +${diff} HP)\n• ${battleStudentB.name}: +${scoreB} điểm Hào quang (Pokemon tổn hại -${diff} HP).`;
    } else if (scoreB > scoreA) {
      winner = battleStudentB;
      // B wins: B gets +scoreB points, Pokemon gets +diff HP. A gets +scoreA points, Pokemon loses diff HP (-diff HP).
      updatedStudents = updatedStudents.map(s => {
        if (s.id === battleStudentB.id) {
          return applyBattleOutcome(s, scoreB, 'win', diff, `🏆 Thắng Battle: +${scoreB}đ (Pokemon +${diff} HP)`, `Battle thắng: hồi ${diff} HP`);
        }
        if (s.id === battleStudentA.id) {
          return applyBattleOutcome(s, scoreA, 'loss', -diff, `⚔️ Thua Battle: +${scoreA}đ (Pokemon -${diff} HP)`, `Battle thua: mất ${diff} HP`);
        }
        return s;
      });

      resultMsg = `🏆 ${battleStudentB.name} CHIẾN THẮNG BATTLE!\n\n• ${battleStudentB.name}: +${scoreB} điểm Hào quang (Pokemon hồi +${diff} HP)\n• ${battleStudentA.name}: +${scoreA} điểm Hào quang (Pokemon tổn hại -${diff} HP).`;
    } else {
      // Tie
      updatedStudents = updatedStudents.map(s => {
        if (s.id === battleStudentA.id) {
          return applyBattleOutcome(s, scoreA, 'draw', null, `⚔️ Hòa Battle: +${scoreA}đ`);
        }
        if (s.id === battleStudentB.id) {
          return applyBattleOutcome(s, scoreB, 'draw', null, `⚔️ Hòa Battle: +${scoreB}đ`);
        }
        return s;
      });

      resultMsg = `🤝 TRẬN BATTLE HÒA NHAU!\n\nCả 2 trainer đều được cộng điểm và bảo toàn HP cho Pokemon.`;
    }

    if (battleProgressMessages.length > 0) {
      resultMsg += `\n\nTiến triển Pokémon:\n${battleProgressMessages.slice(0, 5).map(message => `• ${message}`).join('\n')}`;
    }
    if (battleHatchedNames.length > 0) {
      resultMsg += `\n\nTrứng đã nở: ${battleHatchedNames.join(', ')}.`;
    }

    setStudents(updatedStudents);
    if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
    if (!releaseEventToShow && battleUiEvents.length > 0) {
      showPokemonReaction(battleUiEvents, 'Kết quả Battle Pokémon');
    }
    if (!releaseEventToShow && battleHatchItems.length > 0) {
      showHatchAnnouncement(
        battleHatchItems,
        `Tin vui! Trứng của ${battleHatchItems.map(item => item.studentName).join(', ')} đã nở sau Battle.`
      );
    }
    new Audio(posSoundUrl).play().catch(() => {});

    const updatedA = updatedStudents.find(s => s.id === battleStudentA.id) || battleStudentA;
    const updatedB = updatedStudents.find(s => s.id === battleStudentB.id) || battleStudentB;
    let ludoTurns: BattleLudoTurn[] = [];
    if (scoreA > scoreB) {
      ludoTurns = [
        ...(scoreA > 0 ? [{ studentId: updatedA.id, role: 'winner' as const }] : []),
        ...(scoreB > 0 ? [{ studentId: updatedB.id, role: 'loser' as const }] : [])
      ];
    } else if (scoreB > scoreA) {
      ludoTurns = [
        ...(scoreB > 0 ? [{ studentId: updatedB.id, role: 'winner' as const }] : []),
        ...(scoreA > 0 ? [{ studentId: updatedA.id, role: 'loser' as const }] : [])
      ];
    } else {
      ludoTurns = [
        ...(scoreA > 0 ? [{ studentId: updatedA.id, role: 'draw' as const }] : []),
        ...(scoreB > 0 ? [{ studentId: updatedB.id, role: 'draw' as const }] : [])
      ];
    }
    setBattleStudentA(updatedA);
    setBattleStudentB(updatedB);

    setBattleResultSummary({
      studentA: updatedA,
      studentB: updatedB,
      winner: winner ? (updatedStudents.find(s => s.id === winner!.id) || winner) : null,
      scoreA,
      scoreB,
      diff,
      resultMsg,
      ludoTurns
    });
    incrementBossCounterForClass(updatedA.className);
  };

  // Student Custom Avatar Upload Handlers
  const handleStudentCustomAvatarUpload = (studentId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      const updated = students.map(s => {
        if (s.id === studentId) {
          const updatedS = { ...s, customAvatar: base64 };
          if (editingStudent?.id === studentId) setEditingStudent(updatedS);
          return updatedS;
        }
        return s;
      });
      setStudents(updated);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveStudentCustomAvatar = (studentId: string) => {
    const updated = students.map(s => {
      if (s.id === studentId) {
        const updatedS = { ...s, customAvatar: undefined };
        if (editingStudent?.id === studentId) setEditingStudent(updatedS);
        return updatedS;
      }
      return s;
    });
    setStudents(updated);
  };

  const getFusionCandidates = (student: Student): PokemonPet[] => {
    const candidates = [...(student.pets || [])];
    if (student.pet && !candidates.some(p => isSamePokemon(p, student.pet))) {
      candidates.unshift(student.pet);
    }
    return candidates;
  };

  // Pokemon Fusion Handler
  const handleFuseSelectedPokemons = (studentId: string) => {
    const s = students.find(x => x.id === studentId);
    const fusionCandidates = s ? getFusionCandidates(s) : [];
    if (!s || fusionCandidates.length < 2) {
      alert("Cần tối thiểu 2 Pokémon để thực hiện hợp nhất!");
      return;
    }

    if (selectedFusionPetDexIds.length < 2) {
      alert("Vui lòng chọn 2 Pokémon muốn hợp nhất!");
      return;
    }

    const petsToFuse = selectedFusionPetDexIds
      .map(index => fusionCandidates[index])
      .filter(Boolean);

    if (petsToFuse.length !== 2) {
      alert("Vui lòng chọn đúng 2 Pokémon hợp lệ để hợp nhất!");
      return;
    }

    const selectedSet = new Set(selectedFusionPetDexIds);
    const remainingPets = fusionCandidates.filter((_, index) => !selectedSet.has(index));

    const combinedSkillUses: Record<string, number> = {};
    petsToFuse.forEach(pet => {
      (pet.skills || []).forEach(skillId => {
        const uses = pet.skillUses?.[skillId] || 0;
        if (uses >= 2) return;
        if (combinedSkillUses[skillId] === undefined || uses < combinedSkillUses[skillId]) {
          combinedSkillUses[skillId] = uses;
        }
      });
    });
    const combinedSkills = Object.keys(combinedSkillUses);
    const randomNewPokemon = getRandomPokemon();
    const fusedLevel = Math.min(30, Math.max(1, Math.floor(petsToFuse.reduce((sum, pet) => sum + (pet.level || 1), 0) / petsToFuse.length)));
    const fusedIsShiny = petsToFuse.every(pet => pet.isShiny);

    const fusedPet: PokemonPet = {
      ...createPokemonPetFromDexId(randomNewPokemon.dexId, `Hợp Thể ${randomNewPokemon.name}`, { isShiny: fusedIsShiny }),
      types: Array.from(new Set(petsToFuse.flatMap(p => p.types))),
      level: fusedLevel,
      xp: 0,
      totalXp: totalXpForLevel(fusedLevel),
      bond: 0,
      charge: 0,
      masteryXp: 0,
      masteryStars: 0,
      skills: combinedSkills,
      skillUses: combinedSkillUses
    };

    const updatedPets = [fusedPet, ...remainingPets];

    const updatedS: Student = {
      ...s,
      pet: fusedPet,
      pets: updatedPets
    };

    setStudents(prev => prev.map(x => x.id === studentId ? updatedS : x));
    setEditingStudent(updatedS);
    setSelectedFusionPetDexIds([]);
    setProfileTab('pet');
    new Audio(posSoundUrl).play().catch(() => {});
    alert(`🔮 HỢP NHẤT THÀNH CÔNG!\n\nĐã dung hợp các Pokémon để tạo Pokémon mới [${getPokemonDisplayName(fusedPet)}] với ${combinedSkills.length} skill đã giữ lại!`);
  };

  const playDiceSound = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      for (let i = 0; i < 8; i++) {
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = i % 2 === 0 ? 'sine' : 'square';
        osc.frequency.setValueAtTime(220 + Math.random() * 400, now + i * 0.04);
        gain.gain.setValueAtTime(0.2, now + i * 0.04);
        gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.04 + 0.035);
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.start(now + i * 0.04);
        osc.stop(now + i * 0.04 + 0.04);
      }
    } catch (err) {
      console.error("Dice audio failed:", err);
    }
  };

  const handleSaveCustomTile = () => {
    if (tileFormIndex < 0 || tileFormIndex > 49) {
      alert("Số ô phải từ 0 đến 49.");
      return;
    }
    const newSpec: LudoTileSpec = {
      tileIndex: tileFormIndex,
      title: tileFormTitle || `Ô Đặc Biệt ${tileFormIndex}`,
      desc: tileFormDesc || 'Ô đặc biệt trên bàn cờ Cá Ngựa.',
      icon: tileFormIcon || '🌟',
      type: tileFormType,
      value: tileFormValue
    };
    setCustomLudoTiles(prev => ({ ...prev, [tileFormIndex]: newSpec }));
    resetTileForm();
    alert(`Đã lưu thiết lập ô đặc biệt số ${tileFormIndex}!`);
  };

  const editCustomTile = (tile: LudoTileSpec) => {
    setTileFormIndex(tile.tileIndex);
    setTileFormTitle(tile.title);
    setTileFormDesc(tile.desc);
    setTileFormIcon(tile.icon);
    setTileFormType(tile.type);
    setTileFormValue(tile.value || 3);
    setEditingTileIndex(tile.tileIndex);
  };

  const deleteCustomTile = (index: number) => {
    if (confirm(`Xóa ô đặc biệt số ${index}?`)) {
      setCustomLudoTiles(prev => {
        const copy = { ...prev };
        delete copy[index];
        return copy;
      });
      if (editingTileIndex === index) resetTileForm();
    }
  };

  const resetTileForm = () => {
    setTileFormIndex(0);
    setTileFormTitle('');
    setTileFormDesc('');
    setTileFormIcon('🚀');
    setTileFormType('portal');
    setTileFormValue(3);
    setEditingTileIndex(null);
  };

  const handleLudoRollDice = (student: Student, options?: { isBonusRoll?: boolean }) => {
    if (ludoRolling) return;
    const isBonusRoll = !!options?.isBonusRoll;
    let releaseEventToShow: PokemonReleaseEvent | null = null;
    const applyLudoAuraReward = (target: Student, amount: number, reason: string): Student => {
      const historyItem: HistoryItem = {
        id: Date.now().toString() + Math.random(),
        amount,
        reason,
        timestamp: Date.now()
      };
      const pointUpdatedStudent: Student = {
        ...target,
        points: target.points + amount,
        history: [historyItem, ...target.history].slice(0, 50)
      };
      const hpUpdate = applyPetHpDeltaToStudent(
        pointUpdatedStudent,
        amount,
        `${reason}: ${amount >= 0 ? 'hồi' : 'mất'} ${Math.abs(amount)} HP`
      );
      if (hpUpdate.releaseEvent && !releaseEventToShow) releaseEventToShow = hpUpdate.releaseEvent;
      return hpUpdate.student;
    };

    setLudoRolling(true);
    setLudoDice(null);
    playDiceSound();

    if (isBonusRoll) {
      setLudoBonusRolls(prev => ({
        ...prev,
        [student.id]: Math.max(0, (prev[student.id] || 0) - 1)
      }));
    }

    // 1. Award +1 point for answering correctly, except bonus rolls from Lucky Wheel.
    let updatedStudents = students.map(s => {
      if (s.id !== student.id) return s;
      if (isBonusRoll) {
        return {
          ...s,
          history: [{ id: Date.now().toString() + Math.random(), amount: 0, reason: '🎁 Lượt lắc Cá Ngựa bonus từ Vòng quay may mắn', timestamp: Date.now() }, ...s.history]
        };
      }
      return applyLudoAuraReward(s, 1, '🎲 Trả lời đúng câu hỏi Cá Ngựa (+1đ)');
    });

    setTimeout(() => {
      const roll = Math.floor(Math.random() * 6) + 1;
      setLudoDice(roll);
      setLudoRolling(false);

      const advanceBattleQueue = (nextStudents: Student[]) => {
        setBattleLudoQueue(prev => {
          if (prev.length === 0) return prev;
          const nextQueue = prev.filter(turn => turn.studentId !== student.id);
          const nextTurn = nextQueue[0];
          const nextStudent = nextTurn ? nextStudents.find(s => s.id === nextTurn.studentId) || null : null;
          setLudoActiveStudent(nextStudent);
          return nextQueue;
        });
      };

      const isStuck = !!ludoMonsterStuck[student.id];
      if (isStuck) {
        if (roll !== 6) {
          setLudoLogs(prev => [`👹 ${student.name} tung được ${roll} điểm - Chưa đủ 6 để diệt Quái vật! Vẫn bị kẹt ở ô hiện tại.`, ...prev.slice(0, 30)]);
          setLudoEventPopup({
            title: '👹 CHƯA THOÁT KHỎI QUÁI VẬT',
            message: `${student.name} tung được ${roll} điểm - Cần lắc đúng 6 điểm để tiêu diệt Quái vật! Vẫn bị kẹt ở ô hiện tại.`,
            actor: student,
            icon: '👹',
            type: 'monster'
          });
          setStudents(updatedStudents);
          if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
          advanceBattleQueue(updatedStudents);
          return;
        } else {
          setLudoMonsterStuck(prev => ({ ...prev, [student.id]: false }));
          updatedStudents = updatedStudents.map(s => s.id === student.id ? { ...s, ludoMonsterStuck: false } : s);
          setLudoLogs(prev => [`⚔️ ${student.name} tung được 6 điểm! Đã tiêu diệt Quái vật và được tiếp tục tiến bước!`, ...prev.slice(0, 30)]);
        }
      }

      const oldSteps = ludoSteps[student.id] || 0;
      let newSteps = oldSteps + roll;
      let newPos = Math.min(newSteps, LUDO_FINISH_TILE);
      const nextPositions = { ...ludoPositions };
      const nextSteps = { ...ludoSteps };
      const nextMonsterStuck = { ...ludoMonsterStuck };
      const raceRoster = students.filter(s => s.className === student.className && !s.isAbsent);
      const logs: string[] = [
        newSteps >= LUDO_FINISH_TILE
          ? `🎲 ${student.name} tung được ${roll} điểm và lao thẳng về đích!`
          : `🎲 ${student.name} tung được ${roll} điểm, tiến đến ô số ${newPos}!`
      ];
      let popupEvent: any = null;
      let reachedFinishReward = false;

      const updateKickedStudent = (target: Student) => {
        nextPositions[target.id] = 0;
        nextSteps[target.id] = 0;
        nextMonsterStuck[target.id] = false;
        updatedStudents = updatedStudents.map(s => {
          if (s.id === target.id) {
            return { ...s, ludoTile: 0, ludoSteps: 0, ludoMonsterStuck: false };
          }
          return s;
        });
      };

      const kickOccupantAt = (tileIndex: number, context: string) => {
        if (tileIndex === 0) return false;
        const target = raceRoster.find(other => other.id !== student.id && (nextPositions[other.id] || 0) === tileIndex);
        if (!target) return false;
        updateKickedStudent(target);
        logs.unshift(`💥 ${student.name} ${context} ô ${tileIndex} và ĐÁ ${target.name} về lại vạch xuất phát!`);
        popupEvent = {
          title: '💥 CÚ ĐÁ VỀ CHUỒNG! 💥',
          message: `${student.name} vừa chiếm ô ${tileIndex}. ${target.name} bị đá về Vạch Xuất Phát (ô 0)!`,
          actor: student,
          target,
          icon: '💥',
          type: 'kick',
          tileIndex
        };
        return true;
      };

      const sendToFinish = (reason: string) => {
        if (reachedFinishReward) return;
        reachedFinishReward = true;
        newSteps = 0;
        newPos = 0;
        updatedStudents = updatedStudents.map(s => {
          if (s.id === student.id) {
            return applyLudoAuraReward(s, 20, '🎉 Hoàn thành 1 vòng bàn cờ Cá Ngựa (+20đ)');
          }
          return s;
        });
        logs.unshift(`🏁 ${student.name} ${reason} và quay lại ô 0 để bắt đầu vòng mới. Thưởng +20 điểm Hào Quang!`);
        if (!popupEvent) {
          popupEvent = {
            title: '🏁 CÁN ĐÍCH!',
            message: `${student.name} đã về đích, nhận +20 điểm Hào Quang và quay lại ô 0 để chơi vòng mới.`,
            actor: student,
            icon: '🏁',
            type: 'finish'
          };
        }
      };

      const applyMovementTile = (tileSpec: LudoTileSpec) => {
        if (tileSpec.type === 'monster') {
          nextMonsterStuck[student.id] = true;
          logs.unshift(`👹 ${student.name} sa vào ${tileSpec.title}! Lượt sau cần lắc được 6 mới đi tiếp.`);
          if (!popupEvent) {
            popupEvent = {
              title: tileSpec.title,
              message: `${student.name} sa vào ô ${tileSpec.tileIndex}: ${tileSpec.desc}`,
              actor: student,
              icon: tileSpec.icon,
              type: 'monster'
            };
          }
          return;
        }

        if (tileSpec.type === 'curse' || tileSpec.type === 'portal') {
          const val = tileSpec.value || (tileSpec.type === 'curse' ? -5 : 3);
          const shiftedSteps = Math.max(0, newSteps + val);
          newSteps = shiftedSteps;
          if (shiftedSteps >= LUDO_FINISH_TILE) {
            logs.unshift(`${tileSpec.icon} ${student.name} kích hoạt ${tileSpec.title}! ${tileSpec.desc}`);
            sendToFinish('được hiệu ứng đẩy tới/vượt đích');
            return;
          }
          newPos = shiftedSteps;
          logs.unshift(`${tileSpec.icon} ${student.name} kích hoạt ${tileSpec.title}! ${tileSpec.desc}`);
          if (!popupEvent) {
            popupEvent = {
              title: tileSpec.title,
              message: `${student.name} kích hoạt ô ${tileSpec.tileIndex}: ${tileSpec.desc} Vị trí mới: ô ${newPos}.`,
              actor: student,
              icon: tileSpec.icon,
              type: tileSpec.type
            };
          }
          kickOccupantAt(newPos, 'bị hiệu ứng đưa tới');
          return;
        }

        if (tileSpec.type === 'restart') {
          newSteps = 0;
          newPos = 0;
          nextMonsterStuck[student.id] = false;
          logs.unshift(`🔁 ${student.name} kích hoạt ${tileSpec.title}! Quay về vạch xuất phát.`);
          if (!popupEvent) {
            popupEvent = {
              title: tileSpec.title,
              message: `${student.name} kích hoạt ô ${tileSpec.tileIndex}: ${tileSpec.desc}`,
              actor: student,
              icon: tileSpec.icon,
              type: 'curse'
            };
          }
          return;
        }

        if (tileSpec.type === 'treasure') {
          const val = tileSpec.value || 5;
          updatedStudents = updatedStudents.map(s => {
            if (s.id === student.id) {
              return applyLudoAuraReward(s, val, `💎 Nhặt được ${tileSpec.title} (${val >= 0 ? '+' : ''}${val}đ)`);
            }
            return s;
          });
          logs.unshift(`💎 ${student.name} kích hoạt ${tileSpec.title}! ${tileSpec.desc}`);
          if (!popupEvent) {
            popupEvent = {
              title: tileSpec.title,
              message: `${student.name} kích hoạt ô ${tileSpec.tileIndex}: ${tileSpec.desc}`,
              actor: student,
              icon: tileSpec.icon,
              type: 'special'
            };
          }
        }
      };

      if (newSteps >= LUDO_FINISH_TILE) {
        sendToFinish('đã chạm hoặc vượt vạch đích');
      } else {
        kickOccupantAt(newPos, 'đáp xuống');
        const tileSpec = effectiveLudoTiles[newPos];
        if (tileSpec) applyMovementTile(tileSpec);
      }

      if (reachedFinishReward) {
        logs.unshift(`🎡 Mở Vòng quay may mắn cho ${student.name} với tỉ lệ 60% quà tốt / 40% quà thử thách.`);
      }

      nextSteps[student.id] = newSteps;
      nextPositions[student.id] = newPos;
      setLudoSteps(nextSteps);
      setLudoPositions(nextPositions);
      setLudoMonsterStuck(nextMonsterStuck);

      // Apply student ludo status update
      updatedStudents = updatedStudents.map(s => {
        if (s.id === student.id) {
          return {
            ...s,
            ludoTile: newPos,
            ludoSteps: newSteps,
            ludoMonsterStuck: !!nextMonsterStuck[student.id]
          };
        }
        return s;
      });

      setStudents(updatedStudents);
      if (releaseEventToShow) setPokemonReleaseEvent(releaseEventToShow);
      setLudoLogs(prev => [...logs, ...prev].slice(0, 40));
      advanceBattleQueue(updatedStudents);

      if (popupEvent) {
        setLudoEventPopup(popupEvent);
      }
      if (reachedFinishReward) {
        const latestStudent = updatedStudents.find(s => s.id === student.id) || student;
        window.setTimeout(() => openLuckyWheelForLudoFinish(latestStudent), 900);
      }
    }, 600);
  };

  const handleMakeGroups = () => {
    const shuffled = [...presentStudents].sort(() => 0.5 - Math.random());
    const result: Student[][] = [];
    for (let i = 0; i < shuffled.length; i += groupSize) {
      result.push(shuffled.slice(i, i + groupSize));
    }
    setGeneratedGroups(result);
    setShowGroupModal(true);
  };

  const startTimer = (seconds: number) => {
    setTimerTime(seconds);
    setTimerRunning(true);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = window.setInterval(() => {
      setTimerTime(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current!);
          setTimerRunning(false);
          new Audio(timerSoundUrl).play().catch(() => {});
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleAvatarUpload = (gender: Gender, rankId: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      const updater = (prev: RankInfo[]) => prev.map(r => r.id === rankId ? { ...r, avatar: base64 } : r);
      if (gender === Gender.MALE) setRanksMale(updater); else setRanksFemale(updater);
    };
    reader.readAsDataURL(file);
  };

  // Skill Sidebar Logic
  const getSidebarData = () => {
    if (selectedStudentIds.length !== 1) return null;
    const student = students.find(s => s.id === selectedStudentIds[0]);
    if (!student) return null;

    const rank = getRank(student.points, student.gender);
    const nextThreshold = (Math.floor(student.points / 50) + 1) * 50;
    const pointsToNext = nextThreshold - student.points;
    const demoteThreshold = Math.floor(student.points / 50) * 50 - 1;
    const pointsToDemote = student.points - demoteThreshold;

    return { student, rank, pointsToNext, pointsToDemote };
  };

  const sidebarData = getSidebarData();

  const updateSkill = (id: string, field: keyof Skill, value: any) => {
    setSkills(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const updatePetSkill = (id: string, field: keyof PetSkill, value: any) => {
    setPetSkills(prev => prev.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  const addPetSkill = () => {
    const newSkill: PetSkill = {
      id: `sk_custom_${Date.now()}`,
      name: 'Tuyệt chiêu mới',
      icon: '✨',
      cost: 20,
      description: 'Mô tả quyền năng Pokémon mới.'
    };
    setPetSkills(prev => [...prev, newSkill]);
  };

  const updateLuckyWheelReward = (id: string, field: keyof LuckyWheelReward, value: any) => {
    setLuckyWheelRewards(prev => prev.map(reward => reward.id === id ? { ...reward, [field]: value } : reward));
  };

  const addLuckyWheelReward = (type: LuckyWheelRewardType = 'points') => {
    const amountByType = type === 'pokemon' || type === 'skill' ? undefined : type === 'ludo_rolls' ? 1 : 1;
    const nextReward: LuckyWheelReward = {
      id: `wheel_custom_${Date.now()}`,
      label: type === 'ludo_rolls' ? 'Lắc Cá Ngựa 1 lần' : 'Phần thưởng mới',
      icon: type === 'ludo_rolls' ? '🎲' : '✨',
      type,
      amount: amountByType,
      color: '#d946ef'
    };
    setLuckyWheelRewards(prev => [...prev, nextReward]);
  };

  const toggleSettingsSection = (section: string) => {
    setSettingsCollapsed(prev => ({ ...prev, [section]: !prev[section] }));
  };

  const handleBossEncounterFrequencyChange = (frequency: BossEncounterFrequency) => {
    setBossEncounterFrequency(frequency);
    localStorage.setItem(BOSS_ENCOUNTER_FREQUENCY_KEY, frequency);
    setBossStatesByClass(prev => {
      const timestamp = Date.now();
      return Object.fromEntries(
        Object.entries(prev).map(([className, state]) => [
          className,
          recalibrateBossEncounterFrequency(
            normalizeClassBossState(state, className, frequency),
            frequency,
            timestamp
          )
        ])
      );
    });
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-[#5d4037] flex flex-col items-center justify-center text-white font-sans">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#D4AF37] mb-4"></div>
        <p className="font-royal uppercase tracking-widest text-xs text-[#D4AF37]">Đang kết nối Trainer Hub...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#FDF3E7] flex items-center justify-center p-4 sm:p-8 font-sans bg-[radial-gradient(#e0d0b0_1px,transparent_1px)] [background-size:16px_16px]">
        {/* Decorative Golden Corner Frames */}
        <div className="fixed top-8 left-8 w-16 h-16 border-t-4 border-l-4 border-red-800 opacity-60 rounded-tl-xl pointer-events-none" />
        <div className="fixed top-8 right-8 w-16 h-16 border-t-4 border-r-4 border-red-800 opacity-60 rounded-tr-xl pointer-events-none" />
        <div className="fixed bottom-8 left-8 w-16 h-16 border-b-4 border-l-4 border-red-800 opacity-60 rounded-bl-xl pointer-events-none" />
        <div className="fixed bottom-8 right-8 w-16 h-16 border-b-4 border-r-4 border-red-800 opacity-60 rounded-br-xl pointer-events-none" />

        <div className="w-full max-w-lg bg-white rounded-[40px] border-8 border-red-800 shadow-2xl p-8 sm:p-12 text-center relative overflow-hidden flex flex-col items-center space-y-6">
          {/* Trainer Hub Icon */}
          <div className="w-24 h-24 bg-red-800 rounded-full flex items-center justify-center text-5xl shadow-lg border-4 border-amber-400 select-none animate-bounce duration-1000">
            ◉
          </div>

          <div className="space-y-2">
            <h1 className="text-4xl font-royal text-red-800 font-extrabold uppercase tracking-tight">Pokemon Trainer Hub</h1>
            <p className="text-[11px] font-black uppercase tracking-[0.2em] text-amber-600">Classroom Adventure System</p>
          </div>

          <div className="w-full h-px bg-gradient-to-r from-transparent via-amber-400 to-transparent my-6" />

          <p className="text-sm font-sans text-stone-600 leading-relaxed max-w-sm">
            Đăng nhập để quản lý trainer, đồng bộ dữ liệu lớp học,
            theo dõi Pokémon đồng hành và tổ chức các hoạt động học tập.
          </p>

          <div className="pt-2 w-full">
            <AuthLoginForm />
          </div>

          <div className="pt-2 w-full border-t border-stone-200">
            <button
              onClick={signInWithGoogle}
              className="w-full text-stone-500 hover:text-stone-800 text-xs font-bold py-2 px-4 rounded-xl transition-all flex items-center justify-center gap-2 border border-stone-200 hover:bg-stone-50"
            >
              <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                <path d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114-3.41 0-6.177-2.767-6.177-6.177S10.58 6.16 13.99 6.16c1.55 0 2.96.57 4.05 1.51l3.07-3.07C19.22 2.82 16.78 1.8 13.99 1.8 8.16 1.8 3.42 6.54 3.42 12.37s4.74 10.57 10.57 10.57c6.14 0 10.23-4.31 10.23-10.4 0-.7-.08-1.2-.18-1.57H12.24z" />
              </svg>
              Đăng nhập bằng Google (Dự phòng)
            </button>
          </div>

          <div className="pt-6 space-y-3">
            <p className="text-[10px] text-stone-400 font-mono italic max-w-xs leading-normal">
              💡 Lưu ý: Nếu nút đăng nhập bị chặn hoặc không phản hồi do cơ chế bảo mật sandbox iFrame, vui lòng bấm nút <strong>"Open in new tab"</strong> ở góc phải phía trên của thanh công cụ AI Studio.
            </p>
          </div>
        </div>
      </div>
    );
  }

  const releaseStudent = pokemonReleaseEvent ? students.find(s => s.id === pokemonReleaseEvent.studentId) : undefined;
  const releaseEggCost = 10;
  const releaseEggShortfall = Math.max(0, releaseEggCost - (releaseStudent?.points || 0));

  return (
    <div className="min-h-screen bg-[radial-gradient(circle_at_50%_0%,#fffbf2_0%,#f5ebe0_100%)] pb-32">
      <PokemonReactionToast
        events={pokemonReactionEvents}
        title={pokemonReactionTitle}
        onClose={() => {
          if (pokemonReactionTimerRef.current) {
            window.clearTimeout(pokemonReactionTimerRef.current);
            pokemonReactionTimerRef.current = null;
          }
          setPokemonReactionEvents([]);
        }}
      />

      {levelUpAnnouncement && (
        <div
          className="fixed inset-0 z-[330] flex items-center justify-center bg-black/55 p-4 backdrop-blur-sm animate-in fade-in duration-200"
          onMouseDown={event => {
            if (event.target === event.currentTarget) setLevelUpAnnouncement(null);
          }}
        >
          <div className="relative w-full max-w-lg overflow-hidden rounded-[36px] border-4 border-amber-300 bg-white p-8 text-center shadow-[0_30px_90px_rgba(245,158,11,0.45)] animate-in zoom-in-95 duration-200">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,rgba(251,191,36,0.35),transparent_42%)] pointer-events-none" />
            <button
              onClick={() => setLevelUpAnnouncement(null)}
              className="absolute right-4 top-4 z-10 grid h-9 w-9 place-items-center rounded-full border border-amber-200 bg-white text-sm font-black text-amber-900 hover:bg-amber-50"
              aria-label="Tắt thông báo level up"
            >
              ×
            </button>
            <div className="relative z-10 space-y-4">
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-full bg-amber-100 text-5xl ring-8 ring-amber-200/60">⭐</div>
              <p className="text-[10px] font-black uppercase tracking-[0.28em] text-amber-700">{levelUpAnnouncement.title}</p>
              <h2 className="font-royal text-4xl uppercase text-amber-950">Level Up!</h2>
              <div className="space-y-2">
                {levelUpAnnouncement.events.map((event, index) => (
                  <p key={`${event.message}-${index}`} className="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-black text-amber-950">
                    {event.message}
                  </p>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* LEFT NAV DOCK */}
      <div className="fixed left-0 top-1/2 z-50 h-40 w-5 -translate-y-1/2 group/nav">
        <nav
          className="absolute left-0 top-1/2 flex -translate-y-1/2 -translate-x-[calc(100%-18px)] flex-col items-center gap-3 rounded-r-[28px] border-2 border-white/90 bg-red-950/80 px-3 py-4 shadow-[0_25px_60px_-10px_rgba(120,20,20,0.3)] backdrop-blur-2xl transition-transform duration-300 ease-out group-hover/nav:translate-x-0 focus-within:translate-x-0"
          style={{
            boxShadow: '0 20px 50px -10px rgba(120,20,20,0.28), 0 0 35px rgba(212,175,55,0.22), inset 0 2px 3px 0 rgba(255,255,255,0.35)'
          }}
        >
          {[
            { id: 'plaza', screen: 'plaza' as Screen, icon: '🏞️', label: 'Trainer Plaza' },
            { id: 'class', screen: 'class' as Screen, icon: '📚', label: 'Lớp Học' },
            { id: 'giftPokemon', icon: '🎁', label: 'Tặng Pokémon' },
            { id: 'settings', screen: 'settings' as Screen, icon: '⚙️', label: 'Cài Đặt' }
          ].map(item => (
            <button
              key={item.id}
              type="button"
              onClick={() => item.screen ? setCurrentScreen(item.screen) : openGiftPokemonModal()}
              title={item.label}
              className={`grid h-14 w-14 place-items-center rounded-2xl border text-2xl shadow-lg transition-all active:scale-95 ${
                item.screen && currentScreen === item.screen
                  ? 'border-amber-200 bg-gradient-to-br from-amber-300 via-amber-400 to-amber-600 text-red-950 ring-4 ring-amber-200/35'
                  : item.id === 'giftPokemon'
                    ? 'border-white/50 bg-gradient-to-br from-emerald-300 via-amber-300 to-fuchsia-400 text-white hover:scale-110 hover:shadow-[0_0_28px_rgba(251,191,36,0.45)]'
                  : 'border-white/30 bg-white/12 text-amber-100 hover:scale-110 hover:bg-white/20'
              }`}
            >
              {item.icon}
            </button>
          ))}
          <button
            type="button"
            onClick={() => setShowUserModal(true)}
            title="Tài khoản giáo viên"
            className="grid h-14 w-14 place-items-center overflow-hidden rounded-2xl border border-amber-200 bg-gradient-to-br from-amber-300 to-amber-600 shadow-lg transition-all hover:scale-110 active:scale-95"
          >
            <img
              src={profile?.photoURL || 'https://api.dicebear.com/7.x/bottts/svg'}
              className="h-10 w-10 rounded-xl border border-white/80 object-cover"
              alt="Avatar"
              referrerPolicy="no-referrer"
            />
          </button>
        </nav>
      </div>

      <StatusDock
        user={user}
        isSyncing={isSyncing}
        lastSyncedTime={lastSyncedTime}
        onBackup={handleBackupToCloud}
        onRestore={handleRestoreFromCloud}
      />

      {showGiftPokemonModal && (
        <div className="fixed inset-0 z-[280] flex items-center justify-center overflow-y-auto bg-slate-950/80 p-4 backdrop-blur-xl animate-in fade-in duration-200">
          <div className="relative my-auto w-full max-w-5xl overflow-hidden rounded-[42px] border border-white/70 bg-white/18 shadow-[0_35px_120px_rgba(15,23,42,0.48)] backdrop-blur-2xl">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_18%_15%,rgba(52,211,153,0.45),transparent_28%),radial-gradient(circle_at_88%_12%,rgba(217,70,239,0.35),transparent_25%),radial-gradient(circle_at_55%_100%,rgba(251,191,36,0.42),transparent_36%)] pointer-events-none" />
            <div className="relative z-10 grid min-h-[620px] grid-cols-1 lg:grid-cols-[0.9fr_1.1fr]">
              <aside className="border-b border-white/30 bg-white/55 p-6 backdrop-blur-2xl lg:border-b-0 lg:border-r">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.28em] text-emerald-700">Gift Pokémon</p>
                    <h2 className="mt-2 font-royal text-3xl uppercase text-slate-950">Tặng Pokémon</h2>
                    <p className="mt-2 text-xs font-bold leading-relaxed text-slate-600">
                      Chọn học sinh trong {filterClass === 'Tất cả' ? 'tất cả lớp' : `lớp ${filterClass}`}. Quà sẽ nở trứng ngay và không trừ Hào Quang.
                    </p>
                  </div>
                  <button
                    type="button"
                    onClick={closeGiftPokemonModal}
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-2xl border border-white/70 bg-white/60 text-2xl font-black text-slate-500 shadow-sm transition-colors hover:text-red-800"
                    aria-label="Đóng tặng Pokémon"
                  >
                    ×
                  </button>
                </div>

                <div className="mt-5 rounded-[28px] border border-white/70 bg-white/60 p-3 shadow-inner">
                  <p className="px-2 pb-2 text-[10px] font-black uppercase tracking-wider text-slate-500">Danh sách lớp hiện tại</p>
                  <div className="max-h-[390px] space-y-2 overflow-y-auto pr-1 custom-scrollbar">
                    {giftPokemonRoster.length === 0 ? (
                      <div className="rounded-3xl border border-dashed border-slate-300 bg-white/70 p-6 text-center text-xs font-black text-slate-400">
                        Chưa có học sinh trong lớp này
                      </div>
                    ) : giftPokemonRoster.map(student => {
                      const selected = giftStudentId === student.id;
                      const eggLabel = student.egg?.status === 'egg'
                        ? `${student.egg.progress || 0}/${getEggRequiredProgress(student.egg)}`
                        : 'Quà mới';
                      return (
                        <button
                          key={student.id}
                          type="button"
                          disabled={giftAnimationPhase === 'hatching'}
                          onClick={() => setGiftStudentId(student.id)}
                          className={`flex w-full items-center gap-3 rounded-3xl border p-3 text-left transition-all ${
                            selected
                              ? 'border-emerald-300 bg-emerald-50 shadow-[0_16px_40px_rgba(16,185,129,0.18)] ring-2 ring-emerald-200'
                              : 'border-white/70 bg-white/65 hover:border-amber-200 hover:bg-amber-50/80'
                          } disabled:cursor-not-allowed disabled:opacity-60`}
                        >
                          <StudentAvatar student={student} className="h-12 w-12 shrink-0 rounded-2xl border-2 border-white shadow" />
                          <div className="min-w-0 flex-1">
                            <p className="truncate text-sm font-black text-slate-950">{student.name}</p>
                            <p className="mt-0.5 truncate text-[10px] font-bold text-slate-500">{student.className} · {student.points}đ Hào Quang</p>
                          </div>
                          <span className={`rounded-full px-3 py-1 text-[10px] font-black ${selected ? 'bg-emerald-600 text-white' : 'bg-white text-amber-700'}`}>
                            {eggLabel}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </aside>

              <section className="relative flex min-h-[620px] items-center justify-center overflow-hidden p-6 sm:p-8">
                <div className="absolute inset-0 bg-[linear-gradient(135deg,rgba(255,255,255,0.25),rgba(255,255,255,0.05))]" />
                {giftAnimationPhase === 'revealed' && Array.from({ length: 34 }).map((_, index) => (
                  <motion.span
                    key={index}
                    className="absolute h-2.5 w-2.5 rounded-full"
                    style={{
                      left: `${8 + (index * 17) % 84}%`,
                      top: `${8 + (index * 29) % 76}%`,
                      backgroundColor: ['#34d399', '#fbbf24', '#f472b6', '#60a5fa', '#fb7185'][index % 5]
                    }}
                    initial={{ y: -80, opacity: 0, scale: 0.4, rotate: 0 }}
                    animate={{ y: [0, 120 + (index % 5) * 22], opacity: [0, 1, 0], scale: [0.6, 1, 0.7], rotate: 260 + index * 11 }}
                    transition={{ duration: 2.1 + (index % 4) * 0.2, delay: (index % 7) * 0.045, repeat: Infinity, repeatDelay: 1.25 }}
                  />
                ))}

                <div className="relative z-10 w-full max-w-xl rounded-[38px] border border-white/70 bg-white/58 p-6 text-center shadow-[inset_0_1px_0_rgba(255,255,255,0.85),0_28px_80px_rgba(15,23,42,0.22)] backdrop-blur-2xl">
                  {giftAnimationPhase === 'select' && (
                    <div className="space-y-6">
                      <div className="mx-auto grid h-24 w-24 place-items-center rounded-[30px] border border-white/70 bg-gradient-to-br from-amber-100 via-white to-emerald-100 text-6xl shadow-xl">
                        🥚
                      </div>
                      <div>
                        <h3 className="font-royal text-4xl uppercase text-slate-950">Trứng quà tặng</h3>
                        <p className="mx-auto mt-2 max-w-sm text-sm font-bold leading-relaxed text-slate-600">
                          {giftStudentId
                            ? `${giftPokemonRoster.find(student => student.id === giftStudentId)?.name || 'Học sinh'} sẽ nhận Pokémon ngay khi trứng nở.`
                            : 'Chọn một học sinh để bắt đầu nghi thức nở trứng.'}
                        </p>
                      </div>
                      <button
                        type="button"
                        disabled={!giftStudentId || giftPokemonRoster.length === 0}
                        onClick={handleGiftPokemon}
                        className="w-full rounded-[26px] bg-gradient-to-r from-emerald-500 via-amber-500 to-fuchsia-500 py-4 text-sm font-black uppercase tracking-wider text-white shadow-[0_20px_48px_rgba(217,70,239,0.28)] transition-all hover:brightness-110 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-45"
                      >
                        Tặng và cho trứng nở ngay
                      </button>
                    </div>
                  )}

                  {giftAnimationPhase === 'hatching' && giftPokemonResult && (
                    <div className="space-y-6">
                      <div className="relative mx-auto h-56 w-56">
                        <motion.div
                          className="absolute inset-0 rounded-full bg-amber-300/40 blur-3xl"
                          animate={{ scale: [0.8, 1.22, 0.9], opacity: [0.35, 0.75, 0.45] }}
                          transition={{ duration: 0.9, repeat: Infinity }}
                        />
                        <motion.div
                          className="absolute inset-5 grid place-items-center rounded-full bg-gradient-to-br from-amber-100 via-white to-emerald-100 text-9xl shadow-[0_28px_70px_rgba(245,158,11,0.35)]"
                          animate={{ rotate: [-6, 7, -5, 6, 0], y: [0, -8, 5, -6, 0], scale: [1, 1.04, 0.98, 1.06, 1] }}
                          transition={{ duration: 0.55, repeat: Infinity }}
                        >
                          🥚
                        </motion.div>
                        <motion.div
                          className="absolute left-1/2 top-8 h-32 w-1 -translate-x-1/2 rounded-full bg-white/80"
                          animate={{ opacity: [0, 1, 0.2], scaleY: [0.2, 1, 0.5] }}
                          transition={{ duration: 0.5, repeat: Infinity }}
                        />
                      </div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.28em] text-amber-700">Đang nở trứng</p>
                        <h3 className="mt-2 font-royal text-4xl uppercase text-slate-950">{giftPokemonResult.student.name}</h3>
                        <p className="mt-2 text-sm font-bold text-slate-600">Ánh sáng đang tràn ra từ quả trứng...</p>
                      </div>
                    </div>
                  )}

                  {giftAnimationPhase === 'revealed' && giftPokemonResult && (
                    <div className="space-y-5">
                      <motion.div
                        initial={{ y: 80, opacity: 0, scale: 0.65 }}
                        animate={{ y: [80, -18, 0], opacity: 1, scale: [0.65, 1.12, 1] }}
                        transition={{ duration: 0.9, ease: [0.2, 0.9, 0.2, 1] }}
                        className="relative mx-auto grid h-64 w-64 place-items-center"
                      >
                        <div className="absolute inset-2 rounded-full bg-[radial-gradient(circle,rgba(251,191,36,0.55),rgba(52,211,153,0.18),transparent_70%)] blur-xl" />
                        <img
                          referrerPolicy="no-referrer"
                          src={getPokemonArtworkUrl(giftPokemonResult.pet)}
                          onError={event => handlePokemonArtworkError(event, giftPokemonResult.pet)}
                          className={`relative z-10 h-56 w-56 object-contain drop-shadow-2xl ${giftPokemonResult.pet.isShiny ? 'rounded-[34px] bg-amber-100/80 ring-4 ring-amber-300' : ''}`}
                          alt={getPokemonDisplayName(giftPokemonResult.pet)}
                        />
                      </motion.div>
                      <div>
                        <p className="text-[10px] font-black uppercase tracking-[0.28em] text-emerald-700">Chúc mừng</p>
                        <h3 className="mt-2 font-royal text-4xl uppercase text-slate-950">{giftPokemonResult.student.name}</h3>
                        <p className="mt-2 text-2xl font-black text-fuchsia-900">
                          nhận được {giftPokemonResult.pet.isShiny ? 'Shiny ' : ''}{getPokemonDisplayName(giftPokemonResult.pet)}
                        </p>
                        <p className="mt-2 text-xs font-bold text-slate-500">
                          {giftPokemonResult.hadExistingEgg ? 'Trứng đang ấp đã nở ngay.' : 'Một trứng quà tặng đặc biệt đã nở ngay.'}
                        </p>
                      </div>
                      <div className="flex flex-col gap-2 sm:flex-row">
                        <button
                          type="button"
                          onClick={resetGiftPokemonFlow}
                          className="flex-1 rounded-2xl border border-white/70 bg-white/65 py-3 text-xs font-black uppercase tracking-wider text-slate-700 shadow-sm transition-colors hover:bg-white"
                        >
                          Tặng tiếp
                        </button>
                        <button
                          type="button"
                          onClick={closeGiftPokemonModal}
                          className="flex-1 rounded-2xl bg-slate-950 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg transition-colors hover:bg-slate-800"
                        >
                          Hoàn tất
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </section>
            </div>
          </div>
        </div>
      )}

      {/* MAIN CONTENT */}
      <main className="max-w-7xl mx-auto p-6">
        {currentScreen === 'plaza' && (
          <div className="py-8 animate-in fade-in duration-500">
            {(() => {
              const mood = getWeatherMood(trainerWeather);
              const plazaStudents = students;
              const campusZones = [
                {
                  id: 'battle',
                  title: 'Battle Court',
                  subtitle: 'Trainer đang luyện phản xạ và thi đấu nhanh.',
                  icon: '⚔️',
                  tone: 'from-rose-100/95 via-orange-50/95 to-amber-100/95 border-rose-200',
                  students: plazaStudents.filter((_, index) => index % 4 === 0)
                },
                {
                  id: 'training',
                  title: 'Training Lawn',
                  subtitle: 'Khu cỏ luyện tập cùng Pokémon đồng hành.',
                  icon: '🌿',
                  tone: 'from-emerald-100/95 via-lime-50/95 to-teal-100/95 border-emerald-200',
                  students: plazaStudents.filter((_, index) => index % 4 === 1)
                },
                {
                  id: 'lake',
                  title: 'Lake Walk',
                  subtitle: 'Nơi trainer trò chuyện, hồi phục và trao đổi.',
                  icon: '💧',
                  tone: 'from-sky-100/95 via-cyan-50/95 to-indigo-100/95 border-sky-200',
                  students: plazaStudents.filter((_, index) => index % 4 === 2)
                },
                {
                  id: 'market',
                  title: 'Shop Plaza',
                  subtitle: 'Khu mua trứng, skill và chuẩn bị cho buổi học.',
                  icon: '🛒',
                  tone: 'from-violet-100/95 via-fuchsia-50/95 to-amber-100/95 border-violet-200',
                  students: plazaStudents.filter((_, index) => index % 4 === 3)
                }
              ];
              const activityLabels = ['Battle ready', 'Training', 'Chatting', 'Trading tips', 'Resting'];

              return (
                <section className={`relative overflow-hidden rounded-[40px] border-2 border-white/80 shadow-2xl ${
                  mood === 'night'
                    ? 'bg-gradient-to-b from-slate-950 via-indigo-950 to-emerald-950'
                    : mood === 'rain'
                      ? 'bg-gradient-to-b from-slate-500 via-sky-700 to-emerald-800'
                      : mood === 'fog'
                        ? 'bg-gradient-to-b from-slate-200 via-sky-100 to-emerald-200'
                        : 'bg-gradient-to-b from-sky-300 via-cyan-100 to-emerald-300'
                }`}>
                  <div className="absolute inset-x-0 top-0 h-72 bg-[radial-gradient(circle_at_78%_18%,rgba(253,224,71,0.82),transparent_12%),radial-gradient(circle_at_22%_18%,rgba(255,255,255,0.55),transparent_14%)]" />
                  <div className="absolute inset-x-0 bottom-0 h-[70%] bg-[radial-gradient(ellipse_at_50%_100%,rgba(34,197,94,0.95)_0%,rgba(16,185,129,0.86)_40%,rgba(20,83,45,0.7)_100%)]" />
                  <div className="absolute left-1/2 top-[18%] h-[84%] w-24 -translate-x-1/2 bg-stone-100/70 shadow-inner" />
                  <div className="absolute left-[8%] right-[8%] top-[47%] h-24 rounded-full bg-stone-100/70 shadow-inner" />
                  <div className="absolute bottom-[9%] right-[6%] h-40 w-56 rounded-[50%] bg-sky-300/70 shadow-[inset_0_8px_28px_rgba(14,116,144,0.35)]" />
                  <div className="absolute bottom-[14%] right-[9%] h-24 w-36 rounded-[50%] bg-cyan-100/60 blur-sm" />
                  {mood === 'night' && <div className="absolute inset-0 bg-slate-950/45" />}
                  {mood === 'rain' && (
                    <div className="absolute inset-0 opacity-45 [background-image:linear-gradient(115deg,rgba(255,255,255,0.45)_0_1px,transparent_1px_12px)] [background-size:18px_36px] animate-pulse" />
                  )}
                  {mood === 'fog' && <div className="absolute inset-0 bg-white/35 backdrop-blur-[1px]" />}
                  <div className="relative z-10 flex flex-wrap items-start justify-between gap-4 p-6">
                    <div>
                      <p className="text-[10px] font-black uppercase tracking-[0.28em] text-white/80">Trainer Plaza</p>
                      <h2 className="font-royal text-4xl text-white drop-shadow">Pokémon Trainer Campus</h2>
                      <p className="mt-1 max-w-xl text-sm font-bold text-white/85">
                        Một bản đồ sống của lớp học: toàn bộ trainer và Pokémon được chia vào các khu battle, luyện tập, hồ nước và shop plaza.
                      </p>
                    </div>
                    <div className="rounded-2xl border border-white/50 bg-white/25 px-4 py-3 text-right text-white shadow-lg backdrop-blur-md">
                      <p className="text-[10px] font-black uppercase tracking-wider">{trainerLocation?.label || 'Weather location'}</p>
                      <p className="mt-1 text-2xl font-black">{trainerWeather ? `${trainerWeather.temperature}°C` : '--°C'}</p>
                      <p className="text-xs font-bold">{trainerWeather ? trainerWeather.label : weatherLoading ? 'Đang tải thời tiết' : 'Chưa có dữ liệu thời tiết'}</p>
                    </div>
                  </div>

                  {plazaStudents.length === 0 ? (
                    <div className="relative z-10 mx-auto my-40 max-w-md rounded-[32px] border border-white/70 bg-white/80 p-8 text-center shadow-xl backdrop-blur-xl">
                      <p className="text-sm font-black text-teal-900">Chưa có trainer nào trong lớp.</p>
                    </div>
                  ) : (
                    <div className="relative z-10 grid gap-5 p-5 pt-2 lg:grid-cols-2">
                      {campusZones.map(zone => (
                        <div key={zone.id} className={`min-h-[260px] rounded-[32px] border-2 bg-gradient-to-br ${zone.tone} p-4 shadow-xl backdrop-blur-xl`}>
                          <div className="mb-4 flex items-start justify-between gap-3">
                            <div>
                              <h3 className="flex items-center gap-2 text-lg font-black text-slate-950">
                                <span className="grid h-9 w-9 place-items-center rounded-2xl bg-white/80 text-xl shadow-sm">{zone.icon}</span>
                                {zone.title}
                              </h3>
                              <p className="mt-1 text-xs font-bold text-slate-600">{zone.subtitle}</p>
                            </div>
                            <span className="rounded-full bg-white/80 px-3 py-1 text-[10px] font-black uppercase text-slate-500 shadow-sm">
                              {zone.students.length}/{plazaStudents.length} trainer
                            </span>
                          </div>

                          {zone.students.length === 0 ? (
                            <div className="grid min-h-[170px] place-items-center rounded-[24px] border border-dashed border-slate-300/70 bg-white/40 text-xs font-bold text-slate-400">
                              Khu này đang trống
                            </div>
                          ) : (
                            <div className="flex flex-wrap gap-3">
                              {zone.students.map((student, index) => {
                                const pet = student.pet;
                                return (
                                  <button
                                    key={student.id}
                                    type="button"
                                    onClick={() => {
                                      setEditingStudent(student);
                                      setCurrentScreen('profile');
                                    }}
                                    className="group/trainer relative flex w-[150px] items-center gap-2 rounded-3xl border border-white/80 bg-white/80 p-2.5 text-left shadow-md backdrop-blur transition-all hover:-translate-y-1 hover:bg-white hover:ring-2 hover:ring-amber-300/70 hover:shadow-[0_18px_45px_rgba(14,116,144,0.28),0_0_35px_rgba(250,204,21,0.25)]"
                                  >
                                    <div className="relative shrink-0">
                                      <StudentAvatar student={student} className="h-12 w-12 rounded-2xl border-2 border-white shadow" />
                                      {pet && (
                                        <img
                                          src={getPokemonArtworkUrl(pet)}
                                          onError={event => handlePokemonArtworkError(event, pet)}
                                          className="absolute -right-4 -top-4 h-8 w-8 object-contain drop-shadow-lg transition-transform group-hover/trainer:scale-125"
                                          alt={getPokemonDisplayName(pet)}
                                          referrerPolicy="no-referrer"
                                        />
                                      )}
                                    </div>
                                    <div className="min-w-0 flex-1">
                                      <p className="truncate text-xs font-black text-slate-950">{student.name}</p>
                                      <p className="truncate text-[9px] font-bold uppercase text-teal-700">{student.className}</p>
                                      <p className="mt-1 truncate text-[9px] font-black text-slate-400">
                                        {pet ? `${getPokemonDisplayName(pet)} · Lv.${pet.level || 1}` : 'Đang ấp trứng'}
                                      </p>
                                    </div>
                                    <span className="absolute -bottom-2 left-4 hidden rounded-full border border-white bg-slate-950 px-2 py-0.5 text-[8px] font-black text-white shadow-md group-hover/trainer:block">
                                      {activityLabels[(index + zone.id.length) % activityLabels.length]}
                                    </span>
                                  </button>
                                );
                              })}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="relative z-10 px-6 pb-6">
                    <div className="rounded-[28px] border border-white/70 bg-white/70 p-4 text-xs font-bold text-slate-600 shadow-lg backdrop-blur-xl">
                      Campus Map đang hiển thị toàn bộ {plazaStudents.length} trainer trong lớp. Thời tiết lấy từ vị trí đã cài ở Settings và tự đổi mood mưa/nắng/tối cho toàn cảnh.
                    </div>
                  </div>
                </section>
              );
            })()}
          </div>
        )}

        {currentScreen === 'class' && (
          <div className="animate-in fade-in duration-300">
            <div className="flex flex-wrap gap-4 mb-8 bg-gray-50 p-4 rounded-2xl border items-center">
              <input type="text" placeholder="Tìm kiếm trainer..." className="flex-1 p-3 rounded-xl border outline-none focus:ring-2 ring-red-800/20" value={searchQuery} onChange={e => setSearchQuery(e.target.value)} />

              <div className="relative">
                <select
                  value={filterClass}
                  onChange={e => setFilterClass(e.target.value)}
                  className="bg-white text-red-950 border-2 border-amber-200 px-4 py-3 pr-9 rounded-xl outline-none font-black text-xs appearance-none hover:border-amber-400 transition-all cursor-pointer shadow-sm"
                >
                  <option value="Tất cả">Tất cả trainer</option>
                  {classes.filter(c => c !== 'Tất cả').map(c => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3 text-amber-700">
                  <span className="text-[10px]">▼</span>
                </div>
              </div>
              
              <button
                onClick={openAttendanceCheck}
                className="bg-sky-700 text-white px-5 py-3 rounded-xl font-black shadow-lg hover:bg-sky-800 transition-all uppercase text-xs tracking-wider"
              >
                🧭 Check đi học
              </button>

              <button
                onClick={openHomeworkCheck}
                className="bg-emerald-700 text-white px-5 py-3 rounded-xl font-black shadow-lg hover:bg-emerald-800 transition-all uppercase text-xs tracking-wider"
              >
                📚 Check Homework
              </button>

              <button onClick={() => {
                const name = prompt("Họ tên trainer:");
                if (!name) return;
                const gender = confirm("Nhấn OK cho Nam, Cancel cho Nữ") ? Gender.MALE : Gender.FEMALE;
                const cls = prompt("Lớp:", filterClass !== 'Tất cả' ? filterClass : 'Mới');
                setStudents(prev => [...prev, { 
                  id: Date.now().toString(), 
                  name, 
                  gender, 
                  className: cls || 'Pokemon Class', 
                  points: 0, 
                  history: [],
                  egg: createEgg('normal')
                }]);
              }} className="bg-red-800 text-white px-6 py-3 rounded-xl font-bold shadow-lg hover:bg-red-900 transition-all">+ Thêm Trainer</button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {currentClassStudents.map(s => (
                <div key={s.id} className="relative group">
                  <StudentCard 
                    student={s} 
                    getRank={getRank} 
                    petSkills={petSkills}
                    isSelected={selectedStudentIds.includes(s.id)}
                    isDimmed={!!hoveredStudentCardId && hoveredStudentCardId !== s.id}
                    onHoverChange={setHoveredStudentCardId}
                    onSelect={(st) => {
                      if (isMultiSelectMode) {
                        setSelectedStudentIds(prev => prev.includes(st.id) ? prev.filter(id => id !== st.id) : [...prev, st.id]);
                      } else {
                        setEditingStudent(st);
                        setCurrentScreen('profile');
                      }
                    }} 
                  />
                  <div className="absolute top-3 left-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={(e) => { e.stopPropagation(); toggleAttendance(s.id); }} className="bg-white/95 p-2 rounded-lg border shadow-sm text-[10px] font-bold">VẮNG/CÓ</button>
                  </div>
                  <div className="absolute bottom-3 right-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity z-10">
                    <button onClick={(e) => { e.stopPropagation(); setSelectedStudentIds([s.id]); setActiveTab('positive'); setFeedbackSource('manual'); setShowSkillModal(true); }} className="bg-green-500 text-white w-10 h-10 rounded-full shadow-lg font-bold text-xl">+</button>
                    <button onClick={(e) => { e.stopPropagation(); setSelectedStudentIds([s.id]); setActiveTab('negative'); setFeedbackSource('manual'); setShowSkillModal(true); }} className="bg-red-500 text-white w-10 h-10 rounded-full shadow-lg font-bold text-xl">-</button>
                  </div>
                </div>
              ))}
            </div>

            {/* CLASS BOTTOM TOOLS - LIQUID GLASS FLOATING DOCK WITH MAGNIFICATION */}
            <LiquidDock
              onRandom={handleRandom}
              onLudo={() => openLudoForClass()}
              onLuckyWheel={handleOpenLuckyWheel}
              onShop={handleOpenShop}
              onGroup={() => setShowGroupModal(true)}
              onTimer={() => setShowTimerModal(true)}
              onClaimAllRewards={handleClaimAllRewards}
              onSelectAll={handleToggleSelectAll}
              isMultiSelectMode={isMultiSelectMode}
              onToggleMultiSelect={() => { setIsMultiSelectMode(!isMultiSelectMode); setSelectedStudentIds([]); }}
              onResetAura={handleResetSelectedAura}
              selectedCount={selectedStudentIds.length}
              isSyncing={isSyncing}
              lastSyncedTime={lastSyncedTime}
              onOpenFeedback={() => { setFeedbackSource('manual'); setShowSkillModal(true); }}
              onDeleteSelected={handleDeleteStudents}
            />
          </div>
        )}

        {currentScreen === 'profile' && editingStudent && (
          <div className="bg-white p-6 sm:p-10 rounded-3xl border shadow-2xl max-w-4xl mx-auto space-y-8 animate-in slide-in-from-right-4 duration-500">
            <div className="flex justify-between items-center border-b pb-4">
              <h2 className="text-2xl sm:text-3xl font-royal text-red-800">Hồ Sơ Trainer</h2>
              <button 
                onClick={() => setCurrentScreen('class')} 
                className="text-sm font-black uppercase text-gray-400 hover:text-red-800 transition-colors"
              >
                ← Quay lại lớp
              </button>
            </div>

            {/* Profile Tab Selector */}
            <div className="flex border-b border-gray-100 shrink-0">
              <button 
                onClick={() => setProfileTab('info')} 
                className={`flex-1 py-3 text-xs sm:text-sm font-black border-b-4 transition-all tracking-wider ${profileTab === 'info' ? 'text-red-800 border-red-800' : 'text-gray-400 border-transparent hover:text-gray-600'}`}
              >
                📜 TIỂU SỬ & CÔNG TRẠNG
              </button>
              <button 
                onClick={() => setProfileTab('pet')} 
                className={`flex-1 py-3 text-xs sm:text-sm font-black border-b-4 transition-all tracking-wider flex items-center justify-center gap-2 ${profileTab === 'pet' ? 'text-amber-600 border-amber-600' : 'text-gray-400 border-transparent hover:text-gray-600'}`}
              >
                <span>{editingStudent.pet ? '🔥' : '🥚'}</span>
                <span>{editingStudent.pet ? 'LINH THÚ HỘ MỆNH' : 'ẤP TRỨNG POKÉMON'}</span>
              </button>
              <button 
                onClick={() => {
                  setProfileTab('fusion');
                  setSelectedFusionPetDexIds([]);
                }} 
                className={`flex-1 py-3 text-xs sm:text-sm font-black border-b-4 transition-all tracking-wider flex items-center justify-center gap-2 ${profileTab === 'fusion' ? 'text-purple-700 border-purple-700' : 'text-gray-400 border-transparent hover:text-gray-600'}`}
              >
                <span>🔮</span>
                <span>HỢP NHẤT LINH THÚ</span>
              </button>
            </div>

            {profileTab === 'info' ? (
              <div className="space-y-8 animate-in fade-in duration-300">
                {(() => {
                  const trainerProgress = normalizeTrainerProgress(editingStudent);
                  const trainerTitle = getTrainerTitleDefinition(trainerProgress.titleId);
                  const trainerXpPct = getTrainerLevelPercent(trainerProgress);
                  const earnedBadgeViews = (editingStudent.earnedBadges || [])
                    .map(badge => ({ badge, definition: getBadgeDefinition(badge.badgeId) }))
                    .filter(item => item.definition);
                  return (
                    <div className="rounded-[32px] border border-red-100 bg-gradient-to-br from-red-50 to-amber-50 p-5 shadow-sm">
                      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-[0.24em] text-red-700">Trainer Journey</p>
                          <h3 className="mt-1 text-2xl font-royal text-red-950">
                            Lv.{trainerProgress.level} · {trainerTitle.icon} {trainerTitle.name}
                          </h3>
                          <p className="mt-1 text-xs font-bold text-stone-500">{trainerTitle.description}</p>
                        </div>
                        <div className="min-w-[180px] rounded-2xl bg-white p-3">
                          <div className="mb-1 flex justify-between text-[10px] font-black text-red-900">
                            <span>Trainer XP</span>
                            <span>{trainerProgress.xp}/{trainerXpNeededForNextLevel(trainerProgress.level)}</span>
                          </div>
                          <div className="h-2 overflow-hidden rounded-full bg-stone-100">
                            <div className="h-full rounded-full bg-red-700" style={{ width: `${trainerXpPct}%` }} />
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 grid gap-3 sm:grid-cols-2">
                        <div className="rounded-2xl bg-white p-3">
                          <p className="mb-2 text-[10px] font-black uppercase tracking-wider text-stone-400">Unlocked Titles</p>
                          <div className="flex flex-wrap gap-2">
                            {(trainerProgress.unlockedTitleIds || ['rookie']).map(titleId => {
                              const title = getTrainerTitleDefinition(titleId);
                              return (
                                <button
                                  key={title.id}
                                  onClick={() => {
                                    const updatedStudent = {
                                      ...editingStudent,
                                      trainerProgress: {
                                        ...trainerProgress,
                                        titleId: title.id
                                      }
                                    };
                                    setEditingStudent(updatedStudent);
                                    setStudents(prev => prev.map(student => student.id === editingStudent.id ? updatedStudent : student));
                                  }}
                                  className={`rounded-full border px-3 py-1 text-[10px] font-black ${trainerProgress.titleId === title.id ? 'border-red-700 bg-red-700 text-white' : 'border-amber-200 bg-amber-50 text-amber-900'}`}
                                >
                                  {title.icon} {title.name}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                        <div className="rounded-2xl bg-white p-3">
                          <p className="mb-2 text-[10px] font-black uppercase tracking-wider text-stone-400">Gym Badges</p>
                          {earnedBadgeViews.length > 0 ? (
                            <div className="flex flex-wrap gap-2">
                              {earnedBadgeViews.map(({ badge, definition }) => (
                                <span key={badge.badgeId} className="rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-[10px] font-black text-amber-900" title={definition!.description}>
                                  {definition!.icon} {definition!.name}
                                </span>
                              ))}
                            </div>
                          ) : (
                            <p className="text-xs font-bold text-stone-400">Chưa có huy hiệu.</p>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {editingStudent.adventureJournal && editingStudent.adventureJournal.length > 0 && (
                  <div className="rounded-[32px] border border-stone-200 bg-stone-50 p-5">
                    <h3 className="font-royal text-xl text-stone-900">📖 Adventure Journal</h3>
                    <div className="mt-4 max-h-56 space-y-2 overflow-y-auto pr-2 custom-scrollbar">
                      {editingStudent.adventureJournal.slice(0, 12).map(entry => (
                        <div key={entry.id} className="rounded-2xl bg-white p-3 text-sm shadow-sm">
                          <p className="font-bold text-stone-800">{entry.text}</p>
                          <p className="mt-1 text-[10px] font-bold text-stone-400">{new Date(entry.timestamp).toLocaleDateString()}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-8 items-center sm:items-start">
                  <div className="relative shrink-0 flex flex-col items-center gap-2">
                    <StudentAvatar student={editingStudent} className="w-32 h-32 rounded-full border-4 border-[#D4AF37] shadow-lg" />
                    <div className="flex flex-col items-center gap-1.5 w-full">
                      <label className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-[10px] px-3 py-1.5 rounded-xl cursor-pointer shadow-sm transition-all text-center w-full uppercase">
                        📷 Đổi Ảnh Riêng
                        <input 
                          type="file" 
                          accept="image/*" 
                          onChange={(e) => handleStudentCustomAvatarUpload(editingStudent.id, e)} 
                          className="hidden" 
                        />
                      </label>
                      {editingStudent.customAvatar && (
                        <button 
                          onClick={() => handleRemoveStudentCustomAvatar(editingStudent.id)}
                          className="text-[9px] font-bold text-red-600 hover:underline uppercase"
                        >
                          Xoá ảnh riêng (Dùng Avatar cấp bậc)
                        </button>
                      )}
                    </div>
                  </div>
                  <div className="flex-1 w-full space-y-4">
                    <div>
                      <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">Họ Tên</label>
                      <input className="w-full border p-3 rounded-xl bg-gray-50 focus:ring-2 ring-red-800/10 outline-none text-sm font-bold" value={editingStudent.name} onChange={e => setEditingStudent({...editingStudent, name: e.target.value})} />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">Lớp / Team</label>
                      <input className="w-full border p-3 rounded-xl bg-gray-50 focus:ring-2 ring-red-800/10 outline-none text-sm font-bold" value={editingStudent.className} onChange={e => setEditingStudent({...editingStudent, className: e.target.value})} />
                    </div>
                    <div>
                      <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">Điểm Hiện Tại</label>
                      <input type="number" className="w-full border p-3 rounded-xl bg-gray-50 font-black text-2xl text-red-800 outline-none" value={editingStudent.points} onChange={e => setEditingStudent({...editingStudent, points: parseInt(e.target.value) || 0})} />
                    </div>
                  </div>
                </div>
                
                <div className="flex flex-col sm:flex-row gap-4 pt-4 border-t">
                  <button onClick={() => { 
                    setStudents(prev => prev.map(s => s.id === editingStudent.id ? editingStudent : s)); 
                    alert("Đã lưu ý chỉ!");
                    setCurrentScreen('class');
                  }} className="flex-1 bg-green-600 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-green-700 hover:scale-[1.01] transition-all">Lưu Thông Tin</button>
                  <button onClick={() => { 
                    setSelectedStudentIds([editingStudent.id]); 
                    setFeedbackSource('manual');
                    setShowSkillModal(true); 
                  }} className="flex-1 bg-red-800 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-red-900 hover:scale-[1.01] transition-all">Ban Thưởng / Phạt</button>
                  <button onClick={() => {
                    if (window.confirm("Xóa trainer này?")) {
                      setStudents(prev => prev.filter(s => s.id !== editingStudent.id));
                      setCurrentScreen('class');
                    }
                  }} className="bg-gray-100 text-red-800 px-6 py-4 rounded-xl font-bold hover:bg-gray-200 transition-all">Xóa</button>
                </div>

                <div className="pt-8 border-t">
                  <h3 className="text-xl font-royal mb-6 text-gray-800">Biên Niên Sử</h3>
                  <div className="space-y-3 h-80 overflow-y-auto pr-2 custom-scrollbar">
                    {editingStudent.history.map(h => (
                      <div key={h.id} className="bg-gray-50 p-4 rounded-2xl border border-gray-100 flex justify-between items-center group hover:border-red-800/20">
                        <div>
                          <p className="font-bold text-gray-800 text-sm">{h.reason}</p>
                          <p className="text-[10px] opacity-40">{new Date(h.timestamp).toLocaleString()}</p>
                        </div>
                        <span className={`text-xl font-black ${h.amount >= 0 ? 'text-green-600' : 'text-red-600'}`}>{h.amount > 0 ? '+' : ''}{h.amount}</span>
                      </div>
                    ))}
                    {editingStudent.history.length === 0 && <p className="text-center py-20 opacity-20 italic">Chưa có ghi chép nào...</p>}
                  </div>
                </div>
              </div>
            ) : profileTab === 'pet' ? (
              <div className="space-y-10 animate-in fade-in duration-300">
                {!editingStudent.pet ? (
                  /* EGG SCREEN WITH OWNED PETS SELECTION */
                  <div className="space-y-10">
                    <div className="text-center py-6 space-y-6 bg-gradient-to-b from-amber-50/30 to-transparent p-8 rounded-[40px] border border-amber-100/50">
                      <div className="relative inline-block">
                        <div className={`absolute inset-0 bg-amber-400/20 rounded-full blur-2xl transition-all duration-1000 ${editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.7) ? 'animate-ping scale-75' : ''}`} />
                        
                        <div className={`text-9xl select-none inline-block transform transition-transform ${editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.7) ? 'animate-bounce cursor-pointer' : 'hover:scale-105 duration-300'}`}>
                          {editingStudent.egg && editingStudent.egg.progress >= getEggRequiredProgress(editingStudent.egg) ? '🐣' : editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.7) ? '🥚💥' : editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.4) ? '🥚⚡' : '🥚'}
                        </div>
                      </div>
                      
                      <div className="max-w-md mx-auto bg-white border border-amber-200/60 p-6 rounded-3xl shadow-sm space-y-4">
                        <div className="flex justify-between items-center text-sm">
                          <span className="font-black text-amber-950">Tiến Trình Ấp Quả Trứng</span>
                          <span className="font-black text-amber-600 bg-amber-100 px-3 py-1 rounded-full text-xs">{(editingStudent.egg ? editingStudent.egg.progress : 0)}/{getEggRequiredProgress(editingStudent.egg)}đ</span>
                        </div>
                        <div className="w-full bg-gray-100 h-3.5 rounded-full overflow-hidden shadow-inner border animate-pulse">
                          <div 
                            className="bg-amber-500 h-full rounded-full transition-all duration-1000"
                            style={{ width: `${Math.min(100, Math.max(0, ((editingStudent.egg ? editingStudent.egg.progress : 0) / getEggRequiredProgress(editingStudent.egg)) * 100))}%` }}
                          />
                        </div>
                        <p className="text-xs text-gray-400 italic font-sans leading-relaxed">
                          {editingStudent.egg && editingStudent.egg.progress >= getEggRequiredProgress(editingStudent.egg)
                            ? 'Chúc mừng! Có sinh mệnh sắp vươn mình ra khỏi lớp vỏ mỏng manh!'
                            : editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.7)
                              ? 'Lớp vỏ trứng nứt sâu rộn ràng! Chỉ 1 vài nét khích lệ hào quang từ giáo sĩ là nở trứng ngay!'
                              : editingStudent.egg && editingStudent.egg.progress >= Math.ceil(getEggRequiredProgress(editingStudent.egg) * 0.4)
                                ? 'Vỏ trứng bắt đầu xuất hiện rạn xước lấp lánh sinh lực.'
                                : 'Trứng nguyên sơ đang chờ đợi được nạp năng lượng bằng các phản hồi tích cực.'}
                        </p>

                        <div className="pt-2 flex flex-col gap-3">
                          <button 
                            onClick={() => {
                              const currentEgg = editingStudent.egg || createEgg('normal');
                              const requiredProgress = getEggRequiredProgress(currentEgg);
                              const nextProg = currentEgg.progress + 1;
                              const isHatching = nextProg >= requiredProgress;
                              
                              let updatedEgg = { ...currentEgg, requiredProgress, progress: Math.min(requiredProgress, nextProg) };
                              let updatedPet = editingStudent.pet;
                              let nextPokemonProgress = { ...normalizeStudentPokemonData(editingStudent).pokemonProgress! };

                              let historyItem: HistoryItem = { id: Date.now().toString(), amount: 1, reason: "Ủng hộ Hào Quang ấp trứng", timestamp: Date.now() };

                              if (isHatching && updatedEgg.status === 'egg') {
                                updatedEgg.status = 'hatched';
                                updatedPet = createPokemonPetFromDexId(currentEgg.assignedDexId);
                                nextPokemonProgress = {
                                  ...nextPokemonProgress,
                                  hatchedEggs: (nextPokemonProgress.hatchedEggs || 0) + 1
                                };
                                showHatchAnnouncement(
                                  [{ studentId: editingStudent.id, studentName: editingStudent.name, pet: updatedPet }],
                                  `Tuyệt vời! Trứng của ${editingStudent.name} đã nở ra ${getPokemonDisplayName(updatedPet)}.`
                                );
                              }

                              let currentMerged: Student = {
                                ...editingStudent,
                                points: editingStudent.points + 1,
                                egg: updatedEgg,
                                pet: updatedPet,
                                pokemonProgress: nextPokemonProgress,
                                pets: updatedPet ? updatePetInCollection(editingStudent, updatedPet) : editingStudent.pets,
                                history: [historyItem, ...editingStudent.history].slice(0, 50)
                              };
                              const journeyEvents: PokemonUiEvent[] = [];
                              currentMerged = applyTrainerJourneyProgress(currentMerged, 0, Date.now(), journeyEvents);
                              if (isHatching && updatedPet) {
                                currentMerged = appendAdventureJournal(currentMerged, {
                                  type: 'pokemon-hatched',
                                  text: `${getPokemonDisplayName(updatedPet)} hatched for ${editingStudent.name}.`,
                                  petInstanceId: updatedPet.instanceId
                                });
                              }
                              if (isHatching && updatedPet?.isShiny) {
                                currentMerged = appendAdventureJournal(currentMerged, {
                                  type: 'shiny-acquired',
                                  text: `${editingStudent.name} discovered Shiny ${getPokemonDisplayName(updatedPet)}.`,
                                  petInstanceId: updatedPet.instanceId
                                });
                              }
                              setEditingStudent(currentMerged);
                              setStudents(prev => prev.map(s => s.id === editingStudent.id ? currentMerged : s));
                            }}
                            className="w-full bg-amber-500 text-white font-bold py-3.5 rounded-2xl shadow-md hover:bg-amber-600 active:scale-95 transition-all text-xs uppercase"
                          >
                            🧪 Ủng Hộ +1đ Hào Quang Ấp Trứng
                          </button>

                          {editingStudent.egg?.status === 'egg' && (() => {
                            const requiredProgress = getEggRequiredProgress(editingStudent.egg);
                            const remainingProgress = Math.max(0, requiredProgress - (editingStudent.egg.progress || 0));
                            return (
                              <button
                                disabled={remainingProgress <= 0 || editingStudent.points < remainingProgress}
                                onClick={() => handleSpendAuraToHatchEgg(editingStudent.id)}
                                className="w-full rounded-2xl bg-emerald-700 py-3.5 text-xs font-black uppercase tracking-wider text-white shadow-md transition-all hover:bg-emerald-800 active:scale-95 disabled:bg-stone-200 disabled:text-stone-500"
                              >
                                🎁 Đổi {remainingProgress}đ Hào Quang để ấp nhanh
                              </button>
                            );
                          })()}

                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                            <button
                              onClick={() => handleBuyNewEgg(editingStudent.id, 'normal')}
                              className="w-full bg-red-800 hover:bg-red-950 text-white font-bold py-3.5 rounded-2xl shadow-md active:scale-95 transition-all text-xs uppercase"
                            >
                              🥚 Trứng thường (10đ)
                            </button>
                            <button
                              onClick={() => handleBuyNewEgg(editingStudent.id, 'special')}
                              className="w-full bg-purple-700 hover:bg-purple-900 text-white font-bold py-3.5 rounded-2xl shadow-md active:scale-95 transition-all text-xs uppercase"
                            >
                              ✨ Trứng đặc biệt (20đ)
                            </button>
                          </div>

                          {editingStudent.egg && editingStudent.egg.progress >= getEggRequiredProgress(editingStudent.egg) && (
                             <button 
                               onClick={() => {
                                 const currentEgg = editingStudent.egg!;
                                 const requiredProgress = getEggRequiredProgress(currentEgg);
                                 const updatedEgg = { ...currentEgg, status: 'hatched' as const, requiredProgress, progress: requiredProgress };
                                 const updatedPet = createPokemonPetFromDexId(currentEgg.assignedDexId);
                                 const nextPokemonProgress = {
                                   ...normalizeStudentPokemonData(editingStudent).pokemonProgress!,
                                   hatchedEggs: (editingStudent.pokemonProgress?.hatchedEggs || 0) + 1
                                 };
                                 
                                 let currentMerged: Student = {
                                   ...editingStudent,
                                   egg: updatedEgg,
                                   pet: updatedPet,
                                   pokemonProgress: nextPokemonProgress,
                                   pets: updatePetInCollection(editingStudent, updatedPet)
                                 };
                                 const journeyEvents: PokemonUiEvent[] = [];
                                 currentMerged = applyTrainerJourneyProgress(currentMerged, 0, Date.now(), journeyEvents);
                                 currentMerged = appendAdventureJournal(currentMerged, {
                                   type: 'pokemon-hatched',
                                   text: `${getPokemonDisplayName(updatedPet)} hatched for ${editingStudent.name}.`,
                                   petInstanceId: updatedPet.instanceId
                                 });
                                 if (updatedPet.isShiny) {
                                   currentMerged = appendAdventureJournal(currentMerged, {
                                     type: 'shiny-acquired',
                                     text: `${editingStudent.name} discovered Shiny ${getPokemonDisplayName(updatedPet)}.`,
                                     petInstanceId: updatedPet.instanceId
                                   });
                                 }

                                 setEditingStudent(currentMerged);
                                 setStudents(prev => prev.map(s => s.id === editingStudent.id ? currentMerged : s));
                                 showHatchAnnouncement(
                                   [{ studentId: editingStudent.id, studentName: editingStudent.name, pet: updatedPet }],
                                   `Tin vui! ${getPokemonDisplayName(updatedPet)} đã nở từ trứng và sẵn sàng đồng hành cùng ${editingStudent.name}.`
                                 );
                               }}
                               className="w-full bg-green-600 text-white font-bold py-4 rounded-2xl shadow-xl hover:bg-green-700 animate-bounce transition-all uppercase text-xs"
                             >
                               🐣 TIẾN HÀNH GÕ VỎ - NỞ TRỨNG NGAY! 🐣
                             </button>
                          )}
                        </div>
                      </div>
                    </div>

                    {renderEggInventory(editingStudent)}
                    {renderExpeditionPanel(editingStudent)}
                    {renderWeeklyChestPanel(editingStudent)}

                    {/* OWNED PORTFOLIO SELECTION IN EGG SCREEN (WHEN WAITING FOR HATCH) */}
                    {editingStudent.pets && editingStudent.pets.length > 0 && (
                      <div className="bg-amber-50/30 p-6 rounded-[32px] border border-amber-200/30 space-y-4">
                        <div className="text-left font-sans">
                          <h4 className="font-royal text-lg text-amber-900 flex items-center gap-2">
                            <span>🦁</span>
                            <span>Danh Sách Pokémon Sở Hữu ({editingStudent.pets.length})</span>
                          </h4>
                          <p className="text-xs text-amber-950/60 font-sans mt-0.5">Chọn Pokémon đã nở trước đó để tiếp tục đồng hành.</p>
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
                          {editingStudent.pets.map(p => (
                            <div key={p.instanceId || `${p.dexId}-${p.name}`} className="p-3 bg-white border border-gray-100 rounded-2xl flex items-center justify-between gap-3 shadow-xs font-sans">
                              <div className="flex items-center gap-2 min-w-0">
                                <img 
                                  src={getPokemonArtworkUrl(p)}
	                                  onError={event => handlePokemonArtworkError(event, p)}
                                  className="w-10 h-10 object-contain shrink-0" 
                                />
                                <div className="min-w-0">
                                  <h5 className="font-extrabold text-xs text-gray-800 truncate">{p.isShiny ? '✨ ' : ''}{getPokemonDisplayName(p)}</h5>
                                  <span className="text-[8px] bg-amber-100 text-amber-900 border border-amber-200 px-1.5 py-0.5 rounded font-black uppercase tracking-tight">{p.types.join('/')}</span>
                                  <p className="mt-1 text-[9px] font-black text-gray-400">Lv.{p.level || 1} · HP {p.hp ?? 100} · Bond {p.bond || 0}</p>
                                </div>
                              </div>
                              <button 
                                onClick={() => handleSelectActivePet(editingStudent.id, p)}
                                className="bg-amber-500 hover:bg-amber-600 text-white text-[9px] font-bold px-3 py-1.5 rounded-xl uppercase tracking-wider shadow-sm transition-all shrink-0"
                              >
                                Chọn Đồng Hành ⚔️
                              </button>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  /* PET CORNER DETAILED STORE & CUSTOMIZATION */
                  <div className="space-y-8 animate-in fade-in duration-300">
                    {renderEggInventory(editingStudent)}
                    {renderExpeditionPanel(editingStudent)}
                    {renderWeeklyChestPanel(editingStudent)}

                    <div className="bg-amber-50/50 rounded-3xl border border-amber-200/50 p-6 flex flex-col md:flex-row gap-6 items-center">
                      <div className="shrink-0 w-44 h-44 bg-white rounded-2xl border-4 border-amber-300 p-4 flex items-center justify-center relative shadow-lg overflow-hidden group">
                        <div className="absolute inset-0 bg-radial-gradient from-amber-200/50 via-transparent to-transparent opacity-60 group-hover:scale-125 transition-transform" />
                        <img 
                          referrerPolicy="no-referrer"
                          src={getPokemonArtworkUrl(editingStudent.pet)}
	                          onError={event => handlePokemonArtworkError(event, editingStudent.pet)}
                          className={`w-full h-full object-contain relative z-10 drop-shadow-xl animate-in duration-500 hover:rotate-6 transition-transform ${editingStudent.pet.isShiny ? 'rounded-2xl bg-amber-100/70 ring-4 ring-amber-300' : ''}`}
                          alt={getPokemonDisplayName(editingStudent.pet)}
                        />
                        
                        {/* Type Badges on bottom corner */}
                        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 flex gap-1 z-20">
                          {editingStudent.pet.types.map(t => (
                            <span key={t} className="bg-amber-500 text-white font-black text-[7px] px-1.5 py-0.5 rounded uppercase tracking-tighter shadow-sm border border-white">
                              {t}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div className="flex-1 w-full space-y-4">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-amber-100 pb-3">
                          <div>
                            <span className="bg-amber-100 text-amber-900 font-black text-[9px] px-2.5 py-0.5 rounded-full uppercase tracking-wider block w-max">Pokémon Đồng Hành</span>
                            <h3 className="text-2xl font-black text-amber-950 mt-1">{getPokemonDisplayName(editingStudent.pet)}</h3>
                            <p className="text-xs font-bold text-amber-900/60">
                              {editingStudent.pet.speciesName || editingStudent.pet.name} · Lv.{editingStudent.pet.level || 1}
                            </p>
                            {editingStudent.pet.isShiny && (
                              <span className="mt-1 inline-flex w-max items-center rounded-full border border-amber-300 bg-amber-100 px-2.5 py-1 text-[9px] font-black uppercase tracking-wider text-amber-800">
                                ✨ Shiny
                              </span>
                            )}
                          </div>
                          
                          <div className="text-right sm:text-right">
                            <p className="text-[9px] uppercase font-bold text-gray-400">Tài chính của bạn</p>
                            <p className="text-xl font-black text-red-800">{editingStudent.points}đ Hào Quang</p>
                          </div>
                        </div>

                        {/* Nicknaming support */}
                        <div>
                          <label className="text-[10px] uppercase font-bold text-gray-400 block mb-1">Đặt Biệt Danh Thú Cưng</label>
                          <input 
                            className="w-full border p-2.5 rounded-xl bg-white focus:ring-2 ring-amber-500/30 outline-none text-sm font-bold text-amber-950 border-amber-200" 
                            value={editingStudent.pet.nickname || ''} 
                            onChange={e => handleRenamePet(editingStudent.id, e.target.value)}
                            placeholder="Biệt danh mới cho pet..."
                          />
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 font-sans">
                          <div className="bg-white border border-amber-100 rounded-2xl p-3">
                            <p className="text-[9px] uppercase font-black text-gray-400">Level</p>
                            <p className="text-sm font-black text-amber-950">Lv.{editingStudent.pet.level || 1}</p>
                          </div>
                          <div className="bg-white border border-amber-100 rounded-2xl p-3">
                            <p className="text-[9px] uppercase font-black text-gray-400">HP</p>
                            <p className="text-sm font-black text-emerald-700">{editingStudent.pet.hp ?? 100}/100</p>
                          </div>
                          <div className="bg-white border border-amber-100 rounded-2xl p-3">
                            <p className="text-[9px] uppercase font-black text-gray-400">{(editingStudent.pet.level || 1) >= 30 ? 'Mastery XP' : 'XP'}</p>
                            <p className="text-sm font-black text-amber-950">
                              {(editingStudent.pet.level || 1) >= 30
                                ? `${editingStudent.pet.masteryXp || 0}/${getNextMasteryTarget(editingStudent.pet.masteryStars || 0) || 'MAX'}`
                                : `${editingStudent.pet.xp || 0}/${xpNeededForNextLevel(editingStudent.pet.level || 1)}`}
                            </p>
                          </div>
                          <div className="bg-white border border-amber-100 rounded-2xl p-3">
                            <p className="text-[9px] uppercase font-black text-gray-400">Bond</p>
                            <p className="text-sm font-black text-pink-700">{editingStudent.pet.bond || 0}/100</p>
                          </div>
                          <div className="bg-white border border-amber-100 rounded-2xl p-3">
                            <p className="text-[9px] uppercase font-black text-gray-400">Charge</p>
                            <p className="text-sm font-black text-indigo-700">{editingStudent.pet.charge || 0}/5</p>
                          </div>
                          <div className="bg-white border border-amber-100 rounded-2xl p-3 min-w-0">
                            <p className="text-[9px] uppercase font-black text-gray-400">Passive</p>
                            <div className="mt-1 min-w-0">
                              <PokemonPassiveBadge passiveId={editingStudent.pet.passiveId} compact className="max-w-full" />
                              {!editingStudent.pet.passiveId && <span className="text-[10px] font-black text-gray-400">Chưa có</span>}
                            </div>
                          </div>
                        </div>

                        <div className="rounded-2xl border border-amber-200 bg-white p-3 font-sans">
                          <p className="text-[9px] uppercase font-black text-gray-400">Evolution Preview</p>
                          <p className="text-sm font-black text-amber-950">
                            {editingPetEvolutionPreview.isFinal
                              ? 'Final Evolution Reached'
                              : `Next Evolution: Lv. ${editingPetEvolutionPreview.nextLevel} · ${editingPetEvolutionPreview.nextSpeciesName}`}
                          </p>
                        </div>

                        <div className="rounded-2xl border border-indigo-200 bg-gradient-to-br from-indigo-50 via-white to-amber-50 p-4 font-sans shadow-sm">
                          <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                            <div>
                              <p className="text-[9px] uppercase font-black text-indigo-500">Passive & Quà tự động</p>
                              {(() => {
                                const passive = getPassiveDefinition(editingStudent.pet.passiveId);
                                return passive ? (
                                  <div className="mt-2">
                                    <p className="text-sm font-black text-indigo-950">
                                      {getPassiveIcon(passive.id)} {passive.name}
                                    </p>
                                    <p className="mt-1 text-xs font-bold leading-relaxed text-indigo-900/70">{passive.description}</p>
                                  </div>
                                ) : (
                                  <p className="mt-2 text-xs font-bold text-gray-400">Pokémon này chưa có passive.</p>
                                );
                              })()}
                            </div>
                            <div className="rounded-2xl border border-white bg-white/80 p-3 text-[10px] font-black text-amber-950 shadow-inner sm:w-72">
                              <p>Lv.5 / Lv.12 / Lv.20 / Lv.30: kiểm tra tiến hóa theo loài.</p>
                              <p className="mt-1">Mỗi lần lên level: Bond +1 và thông báo Level Up ở giữa màn hình.</p>
                              <p className="mt-1">Charge 5/5: câu trả lời Solo tích cực kế tiếp được tăng XP.</p>
                              <p className="mt-1">Sau Lv.30: XP chuyển thành Mastery XP để nhận sao Mastery.</p>
                            </div>
                          </div>
                        </div>

                        {(editingStudent.pet.level || 1) >= 30 && (
                          <div className="rounded-2xl border border-amber-200 bg-white p-3 font-sans">
                            <p className="text-[9px] uppercase font-black text-gray-400">Mastery</p>
                            <p className="text-xl font-black text-amber-700 tracking-widest">
                              {(editingStudent.pet.masteryStars || 0) > 0 ? '⭐'.repeat(editingStudent.pet.masteryStars || 0) : 'Chưa có sao'}
                            </p>
                            <p className="mt-1 text-[10px] font-bold text-amber-900/60">
                              XP sau Lv.30 sẽ chuyển thành Mastery XP cho danh hiệu đồng hành lâu dài.
                            </p>
                          </div>
                        )}

                        <div className="flex flex-wrap justify-end gap-3 pt-1">
                          <button 
                            onClick={() => handleBuyNewEgg(editingStudent.id, 'normal')}
                            className="bg-red-800 hover:bg-red-950 text-white font-bold text-xs p-3 px-5 rounded-2xl flex items-center gap-2 shadow-md transition-all active:translate-y-px font-sans"
                          >
                            <span>🥚🌟</span>
                            <span>Trứng thường (10đ)</span>
                          </button>
                          <button 
                            onClick={() => handleBuyNewEgg(editingStudent.id, 'special')}
                            className="bg-purple-700 hover:bg-purple-900 text-white font-bold text-xs p-3 px-5 rounded-2xl flex items-center gap-2 shadow-md transition-all active:translate-y-px font-sans"
                          >
                            <span>✨🥚</span>
                            <span>Trứng đặc biệt (20đ)</span>
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* OWNED PETS SELECTION INTERFACE (ACTIVE COMPANION SWAP) */}
                    {editingStudent.pets && editingStudent.pets.length > 0 && (
                      <div className="bg-amber-50/10 p-6 rounded-3xl border border-amber-200/20 space-y-4">
                        <div className="text-left border-b pb-2 font-sans">
                          <h4 className="font-royal text-lg text-amber-900 flex items-center gap-2">
                            <span>🦁</span>
                            <span>Pokémon Đã Sở Hữu ({editingStudent.pets.length})</span>
                          </h4>
                          <p className="text-xs text-amber-950/60 mt-0.5">Lựa chọn một Pokémon trong bộ sưu tập để đồng hành cùng trainer.</p>
                          {getSynergyLabel(editingStudent) && (
                            <p className="mt-2 inline-flex rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-800">
                              {getSynergyLabel(editingStudent)}
                            </p>
                          )}
                        </div>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-[190px] overflow-y-auto pr-2 custom-scrollbar font-sans">
                          {editingStudent.pets.map(p => {
                            const isActive = isSamePokemon(editingStudent.pet, p);
                            const isSupport = editingStudent.supportPetInstanceId === p.instanceId;
                            return (
                              <div key={p.instanceId || `${p.dexId}-${p.name}`} className={`p-3 bg-white border rounded-2xl flex items-center justify-between gap-3 shadow-xs transition-all ${isActive ? 'border-amber-400 ring-2 ring-amber-100' : 'border-gray-100'}`}>
                                <div className="flex items-center gap-2 min-w-0">
                                  <img 
                                    src={getPokemonArtworkUrl(p)}
	                                    onError={event => handlePokemonArtworkError(event, p)}
                                    className="w-10 h-10 object-contain shrink-0" 
                                  />
                                  <div className="min-w-0">
                                    <h5 className="font-extrabold text-xs text-gray-800 truncate">{p.isShiny ? '✨ ' : ''}{getPokemonDisplayName(p)}</h5>
                                    <span className="text-[8px] bg-amber-100 text-amber-900 border border-amber-200 px-1.5 py-0.5 rounded font-black uppercase tracking-tight">{p.types.join('/')}</span>
                                    <p className="mt-1 text-[9px] font-black text-gray-400">Lv.{p.level || 1} · HP {p.hp ?? 100} · Bond {p.bond || 0}</p>
                                  </div>
                                </div>
                                {isActive ? (
                                  <span className="text-[9px] bg-amber-500 text-white font-extrabold px-2.5 py-1.5 rounded-full uppercase tracking-tighter shrink-0">ĐANG ĐỒNG HÀNH</span>
                                ) : (
                                  <div className="flex shrink-0 flex-col gap-1.5">
                                    <button 
                                      onClick={() => handleSelectActivePet(editingStudent.id, p)}
                                      className="bg-gray-100 hover:bg-amber-100 text-amber-950 text-[9px] font-bold px-3 py-1.5 rounded-xl border border-amber-200 uppercase tracking-wider shadow-xs transition-all"
                                    >
                                      Active ⚔️
                                    </button>
                                    <button
                                      disabled={!p.instanceId}
                                      onClick={() => handleSelectSupportPet(editingStudent.id, isSupport ? undefined : p)}
                                      className={`text-[9px] font-bold px-3 py-1.5 rounded-xl border uppercase tracking-wider shadow-xs transition-all ${isSupport ? 'bg-emerald-600 text-white border-emerald-600' : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200'}`}
                                    >
                                      {isSupport ? 'Support ✓' : 'Support'}
                                    </button>
                                  </div>
                                )}
                              </div>
                            );
                          })}
                        </div>

                      </div>
                    )}
                    {/* SECTION: YOUR NEW DIRECT PET ACTIVE SKILLS (LIMIT 2 USES) */}
                    {editingStudent.pet.skills && editingStudent.pet.skills.length > 0 && (
                      <div className="space-y-4 pt-4">
                        <h4 className="font-royal text-xl text-indigo-900 border-b pb-2 flex items-center gap-2">
                          <span>⚡</span>
                          <span>Bảo Bối Tuyệt Chiêu Hữu Dụng</span>
                        </h4>
                        <p className="text-xs text-indigo-950/70 font-sans">Kích hoạt trực tiếp quyền năng thần bí để lật ngược thế cờ kiểm tra! Mật tịch bốc hơi ngay sau 2 lần sử dụng.</p>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {editingStudent.pet.skills.map(skId => {
                            const sk = petSkills.find(x => x.id === skId);
                            if (!sk) return null;
                            const currentUses = editingStudent.pet?.skillUses?.[skId] || 0;
                            const remainingUses = Math.max(0, 2 - currentUses);
                            return (
                              <div key={skId} className="bg-indigo-50/40 p-4 border border-indigo-200 rounded-3xl flex items-center justify-between gap-4 shadow-sm hover:bg-indigo-50/80 transition-all font-sans text-left">
                                <div className="w-10 h-10 shrink-0 bg-indigo-100 rounded-2xl flex items-center justify-center text-2xl border border-indigo-200">
                                  {sk.icon}
                                </div>
                                <div className="flex-1 min-w-0 text-left">
                                  <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded border ${remainingUses <= 1 ? 'bg-red-50 text-red-600 border-red-200' : 'bg-green-50 text-green-600 border-green-200'}`}>
                                    Trạng thái: Chỉ còn {remainingUses}/2 lượt dùng
                                  </span>
                                  <h5 className="font-extrabold text-sm text-gray-800 mt-1">{sk.name}</h5>
                                  <p className="text-xs text-gray-400 mt-0.5 italic leading-tight">{sk.description}</p>
                                </div>
                                <button
                                  onClick={() => handleUsePetSkill(editingStudent.id, skId, sk.name)}
                                  className="bg-red-800 hover:bg-red-950 text-white font-black text-[9px] px-3.5 py-2.5 rounded-2xl uppercase tracking-tight shadow active:translate-y-px transition-all shrink-0 font-sans"
                                >
                                  Kích Hoạt
                                </button>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* SECTION: PET SKILLS DOJO */}
                    <div className="space-y-4 pt-4">
                      <h4 className="font-royal text-xl text-purple-900 border-b pb-2 flex items-center gap-2">
                        <span>🎓</span>
                        <span>Pokémon Skill Lab</span>
                      </h4>
                      <p className="text-xs text-purple-800/70 font-sans">Huấn luyện skill cho Pokémon để hỗ trợ trainer trong các hoạt động học tập.</p>
                      
                      <div className="space-y-2 max-h-[420px] overflow-y-auto pr-2 custom-scrollbar font-sans font-[Inter]">
                        {petSkills.map(sk => {
                          const isLearned = editingStudent.pet?.skills.includes(sk.id);
                          return (
                            <div key={sk.id} className="bg-white p-4 border border-gray-100 rounded-3xl flex items-center justify-between gap-4 shadow-sm hover:border-purple-200 hover:bg-purple-50/10 transition-all font-[Inter]">
                              <div className="w-10 h-10 shrink-0 bg-purple-50 rounded-2xl flex items-center justify-center text-2xl border border-purple-100">
                                {sk.icon}
                              </div>
                              <div className="flex-1 min-w-0 text-left">
                                <span className="text-[8px] tracking-widest font-black uppercase text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-100">Trainer skill</span>
                                <h5 className="font-extrabold text-sm text-gray-800 mt-1">{sk.name}</h5>
                                <p className="text-xs text-gray-400 mt-0.5 italic leading-relaxed">{sk.description}</p>
                              </div>
                              <div className="shrink-0 text-right font-[Inter]">
                                {isLearned ? (
                                  <span className="bg-purple-100 text-purple-800 font-extrabold border border-purple-200 text-[10px] px-4 py-2 rounded-2xl uppercase tracking-tighter">
                                    ☘️ Đã Giác Ngộ
                                  </span>
                                ) : (
                                  <button
                                    onClick={() => handleBuySkill(editingStudent.id, sk.id, sk.cost, sk.name)}
                                    className="bg-purple-700 hover:bg-purple-800 text-white font-extrabold text-[10px] px-4 py-2 rounded-2xl uppercase tracking-tight shadow active:translate-y-px transition-all"
                                  >
                                    Rèn ({sk.cost}đ)
                                  </button>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-8 animate-in fade-in duration-300">
                <div className="bg-purple-50/70 border-2 border-purple-200 rounded-[32px] p-6 space-y-4">
                  <div className="flex items-center justify-between gap-4 border-b border-purple-200 pb-4">
                    <div>
                      <h3 className="text-2xl font-royal text-purple-900 uppercase tracking-wider">🔮 Hợp nhất Pokémon</h3>
                      <p className="text-xs text-purple-950/70 mt-1">Chọn đúng 2 Pokémon để hợp nhất thành 1 Pokémon mới. Hai Pokémon cũ sẽ biến mất, còn các skills đã mua và vẫn còn hiệu lực sẽ được giữ lại.</p>
                    </div>
                    <span className="shrink-0 bg-white text-purple-900 border border-purple-200 px-3 py-1.5 rounded-full text-xs font-black">
                      Đã chọn {selectedFusionPetDexIds.length}/2
                    </span>
                  </div>

                  {getFusionCandidates(editingStudent).length < 2 ? (
                    <div className="bg-white border border-purple-100 rounded-3xl p-8 text-center space-y-3">
                      <div className="text-5xl">🥚</div>
                      <p className="text-sm font-black text-purple-900">Cần tối thiểu 2 Pokémon để hợp nhất.</p>
                      <p className="text-xs text-purple-700/70">Hãy ấp thêm trứng hoặc chọn lại Pokémon sở hữu trước khi dung hợp.</p>
                    </div>
                  ) : (
                    <>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {getFusionCandidates(editingStudent).map((p, index) => {
                          const isSelected = selectedFusionPetDexIds.includes(index);
                          const skillNames = (p.skills || [])
                            .map(skillId => petSkills.find(skill => skill.id === skillId)?.name || skillId)
                            .slice(0, 3);
                          return (
                            <button
                              type="button"
                              key={`${p.dexId}-${p.name}-${index}`}
                              onClick={() => {
                                if (isSelected) {
                                  setSelectedFusionPetDexIds(prev => prev.filter(x => x !== index));
                                  return;
                                }
                                if (selectedFusionPetDexIds.length >= 2) {
                                  alert("Chỉ được chọn tối đa 2 Pokémon để hợp nhất!");
                                  return;
                                }
                                setSelectedFusionPetDexIds(prev => [...prev, index]);
                              }}
                              className={`text-left bg-white p-4 rounded-3xl border-2 transition-all flex items-center gap-4 ${isSelected ? 'border-purple-700 ring-4 ring-purple-100 shadow-lg' : 'border-purple-100 hover:border-purple-300'}`}
                            >
                              <img
                                src={getPokemonArtworkUrl(p)}
	                                onError={event => handlePokemonArtworkError(event, p)}
                                className="w-16 h-16 object-contain shrink-0"
                              />
                              <div className="min-w-0 flex-1">
                                <div className="flex items-center gap-2">
                                  <h4 className="font-black text-sm text-purple-950 truncate">{p.isShiny ? '✨ ' : ''}{getPokemonDisplayName(p)}</h4>
                                  {isSelected && <span className="text-[9px] bg-purple-700 text-white px-2 py-0.5 rounded-full font-black">CHỌN</span>}
                                </div>
                                <p className="text-[9px] font-black text-purple-600 uppercase mt-1">{p.types.join(' / ')}</p>
                                <p className="text-[10px] text-stone-500 mt-2 line-clamp-2">
                                  {skillNames.length > 0 ? `Skills: ${skillNames.join(', ')}` : 'Chưa có skill đã mua'}
                                </p>
                              </div>
                            </button>
                          );
                        })}
                      </div>

                      <button
                        disabled={selectedFusionPetDexIds.length !== 2}
                        onClick={() => handleFuseSelectedPokemons(editingStudent.id)}
                        className="w-full bg-purple-700 hover:bg-purple-800 disabled:opacity-40 disabled:hover:bg-purple-700 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg transition-all"
                      >
                        🔮 Hợp Nhất 2 Pokémon Đã Chọn
                      </button>
                    </>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {currentScreen === 'settings' && (
          <div className="animate-in slide-in-from-bottom-4 duration-500 space-y-8 pb-12">
            <h2 className="text-3xl font-royal text-teal-800 text-center uppercase">Trainer Settings</h2>

            <SettingsSection id="weather" icon="☀️" title="Weather Plaza" subtitle="Cài vị trí để Trainer Plaza đổi nắng, mưa hoặc trời tối theo thời tiết thật." collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="grid grid-cols-1 gap-4 rounded-[32px] border border-sky-100 bg-sky-50/60 p-5 md:grid-cols-[1fr_auto_auto]">
                <input
                  value={weatherLocationInput}
                  onChange={event => {
                    setWeatherLocationInput(event.target.value);
                    localStorage.setItem('trainer_weather_location_input', event.target.value);
                  }}
                  placeholder="Nhập thành phố hoặc địa chỉ, ví dụ: Hanoi"
                  className="rounded-2xl border border-sky-200 bg-white px-4 py-3 text-sm font-bold text-sky-950 outline-none focus:ring-4 focus:ring-sky-100"
                />
                <button
                  onClick={refreshWeatherByAddress}
                  disabled={weatherLoading}
                  className="rounded-2xl bg-sky-700 px-5 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg hover:bg-sky-800 disabled:opacity-50"
                >
                  Update Weather
                </button>
                <button
                  onClick={refreshWeatherByBrowserLocation}
                  disabled={weatherLoading}
                  className="rounded-2xl border border-sky-200 bg-white px-5 py-3 text-xs font-black uppercase tracking-wider text-sky-800 shadow-sm hover:bg-sky-50 disabled:opacity-50"
                >
                  Auto Location
                </button>
                <div className="md:col-span-3 text-xs font-bold text-sky-900/70">
                  {weatherLoading
                    ? 'Đang cập nhật thời tiết...'
                    : weatherError
                      ? weatherError
                      : trainerWeather
                        ? `${trainerLocation?.label || 'Vị trí'} · ${trainerWeather.label} · ${trainerWeather.temperature}°C · cập nhật ${new Date(trainerWeather.updatedAt).toLocaleTimeString('vi-VN')}`
                        : 'Chưa có dữ liệu thời tiết.'}
                </div>
              </div>
            </SettingsSection>

            <SettingsSection id="bossRaid" icon="👹" title="Boss Raid" subtitle="Cài tần suất Boss xuất hiện sau các lượt Random Solo/Battle." collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="rounded-[32px] border border-red-100 bg-gradient-to-br from-red-50 via-white to-amber-50 p-5 text-left shadow-sm">
                <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                  {BOSS_ENCOUNTER_FREQUENCY_OPTIONS.map(option => {
                    const active = bossEncounterFrequency === option.id;
                    return (
                      <button
                        key={option.id}
                        onClick={() => handleBossEncounterFrequencyChange(option.id)}
                        className={`rounded-3xl border-2 p-4 text-left transition-all ${
                          active
                            ? 'border-red-700 bg-red-800 text-white shadow-xl shadow-red-900/20'
                            : 'border-red-100 bg-white text-red-950 hover:border-red-300 hover:bg-red-50'
                        }`}
                      >
                        <p className="text-sm font-black uppercase tracking-wider">{option.label}</p>
                        <p className={`mt-2 text-xs font-bold leading-relaxed ${active ? 'text-red-50' : 'text-red-700'}`}>
                          {option.description}
                        </p>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-4 grid grid-cols-1 gap-3 rounded-3xl border border-amber-200 bg-white/80 p-4 text-xs font-black text-amber-950 md:grid-cols-3">
                  <div>
                    <p className="uppercase tracking-[0.18em] text-amber-500">Đang chọn</p>
                    <p className="mt-1 text-base text-red-900">{currentBossFrequencyOption.label}</p>
                  </div>
                  <div>
                    <p className="uppercase tracking-[0.18em] text-amber-500">Khoảng xuất hiện</p>
                    <p className="mt-1 text-base text-red-900">{currentBossFrequencyOption.minGap}-{currentBossFrequencyOption.maxGap} Random</p>
                  </div>
                  <div>
                    <p className="uppercase tracking-[0.18em] text-amber-500">Lớp hiện tại</p>
                    <p className="mt-1 text-base text-red-900">
                      {currentBossState
                        ? `${currentBossState.randomsSinceLastEncounter}/${currentBossState.nextEncounterAt} lượt`
                        : 'Chọn một lớp'}
                    </p>
                  </div>
                </div>
              </div>
            </SettingsSection>

            <SettingsSection id="sound" icon="🔊" title="Cài Đặt Âm Thanh" subtitle="Youtube hoặc audio URL cho cộng điểm, trừ điểm, timer và vòng quay may mắn." collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-6">
                {[
                  ['Cộng Điểm (Tích cực)', posSoundUrl, setPosSoundUrl],
                  ['Trừ Điểm (Cần cố gắng)', negSoundUrl, setNegSoundUrl],
                  ['Timer Hết Giờ', timerSoundUrl, setTimerSoundUrl],
                  ['Vòng Quay Đang Quay', wheelSpinSoundUrl, setWheelSpinSoundUrl],
                  ['Vòng Quay Kết Thúc', wheelFinishSoundUrl, setWheelFinishSoundUrl]
                ].map(([label, value, setter]) => (
                  <div key={label as string} className="space-y-2">
                    <label className="text-[10px] font-black uppercase text-gray-400">{label as string}</label>
                    <input
                      className="w-full border p-3 rounded-xl text-xs outline-none focus:ring-2 ring-red-800/20"
                      value={value as string}
                      onChange={e => (setter as React.Dispatch<React.SetStateAction<string>>)(e.target.value)}
                      placeholder="Link âm thanh..."
                    />
                  </div>
                ))}
              </div>
              <button
                onClick={() => {
                  localStorage.setItem('imperial_sound_pos', posSoundUrl);
                  localStorage.setItem('imperial_sound_neg', negSoundUrl);
                  localStorage.setItem('imperial_sound_tim', timerSoundUrl);
                  localStorage.setItem(WHEEL_SPIN_SOUND_KEY, wheelSpinSoundUrl);
                  localStorage.setItem(WHEEL_FINISH_SOUND_KEY, wheelFinishSoundUrl);
                  alert("Đã lưu cài đặt âm thanh!");
                }}
                className="bg-red-800 text-white px-8 py-3 rounded-xl font-bold shadow-lg hover:bg-red-900 transition-all uppercase text-xs"
              >
                Lưu Âm Thanh
              </button>
            </SettingsSection>

            <SettingsSection id="skills" icon="✨" title="Công Trạng" subtitle="Tùy chỉnh điểm cộng/trừ trong bảng feedback." collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="flex justify-end">
                <button onClick={() => {
                  const type = activeTab;
                  const newSkill: Skill = { id: Date.now().toString(), name: "Skill mới", icon: "✨", points: type === 'positive' ? 1 : -1, type };
                  setSkills(prev => [...prev, newSkill]);
                }} className="bg-purple-800 text-white px-6 py-2 rounded-xl font-bold text-xs">+ Thêm Skill</button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {['positive', 'negative'].map(type => (
                  <div key={type} className="space-y-4">
                    <h4 className="font-bold text-sm uppercase tracking-[0.2em] opacity-40 text-purple-800">{type === 'positive' ? 'Tích Cực' : 'Cần Cố Gắng'}</h4>
                    {skills.filter(s => s.type === type).map(sk => (
                      <div key={sk.id} className="bg-white p-4 rounded-2xl border flex items-center gap-3 group shadow-sm">
                        <input value={sk.icon} onChange={e => updateSkill(sk.id, 'icon', e.target.value)} className="w-10 h-10 text-xl text-center bg-gray-50 rounded-lg outline-none focus:ring-2 ring-purple-100" />
                        <input value={sk.name} onChange={e => updateSkill(sk.id, 'name', e.target.value)} className="flex-1 min-w-0 font-bold text-sm outline-none bg-transparent border-b border-transparent focus:border-purple-200" placeholder="Tên skill..." />
                        <input type="number" value={sk.points} onChange={e => updateSkill(sk.id, 'points', parseInt(e.target.value) || 0)} className="w-14 text-center font-black text-xs p-1 bg-gray-50 rounded outline-none focus:ring-2 ring-purple-100" />
                        <button onClick={() => { if(confirm('Xóa skill này?')) setSkills(prev => prev.filter(x => x.id !== sk.id)); }} className="text-gray-300 hover:text-red-500 transition-colors p-2">🗑️</button>
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            </SettingsSection>

            <SettingsSection id="petSkills" icon="⚡" title="Skills Pokémon" subtitle="Tùy chỉnh skill Pokémon, giá mua và mô tả hiển thị trong hồ sơ trainer." collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="flex flex-wrap justify-end gap-3">
                <button onClick={addPetSkill} className="bg-indigo-700 text-white px-6 py-2 rounded-xl font-bold text-xs">+ Thêm Pokémon Skill</button>
                <button onClick={() => { if(confirm('Khôi phục danh sách Pokémon skills mặc định?')) setPetSkills(DEFAULT_PET_SKILLS); }} className="bg-indigo-100 text-indigo-900 px-6 py-2 rounded-xl font-bold text-xs border border-indigo-200">Khôi Phục Mặc Định</button>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                {petSkills.map(sk => (
                  <div key={sk.id} className="bg-white p-4 rounded-3xl border border-indigo-100 shadow-sm space-y-3">
                    <div className="grid grid-cols-[48px_1fr_86px_auto] gap-3 items-center">
                      <input value={sk.icon} onChange={e => updatePetSkill(sk.id, 'icon', e.target.value)} className="w-12 h-12 text-2xl text-center bg-indigo-50 rounded-2xl outline-none focus:ring-2 ring-indigo-100" />
                      <input value={sk.name} onChange={e => updatePetSkill(sk.id, 'name', e.target.value)} className="min-w-0 font-black text-sm border-b border-transparent focus:border-indigo-200 outline-none" />
                      <input type="number" value={sk.cost} onChange={e => updatePetSkill(sk.id, 'cost', parseInt(e.target.value) || 0)} className="w-full text-center font-black text-xs p-2 bg-indigo-50 rounded-xl outline-none focus:ring-2 ring-indigo-100" />
                      <button onClick={() => { if(confirm('Xóa Pokémon skill này?')) setPetSkills(prev => prev.filter(x => x.id !== sk.id)); }} className="text-gray-300 hover:text-red-500 transition-colors p-2">🗑️</button>
                    </div>
                    <textarea value={sk.description} onChange={e => updatePetSkill(sk.id, 'description', e.target.value)} className="w-full min-h-20 border border-indigo-100 rounded-2xl p-3 text-xs outline-none focus:ring-2 ring-indigo-100 resize-y" />
                  </div>
                ))}
              </div>
            </SettingsSection>

            <SettingsSection id="pokemonReset" icon="🧬" title="Reset Pokémon" subtitle="Đưa toàn bộ Pokémon hiện có về Level 1 mà vẫn giữ Hào Quang, HP, kỹ năng và phụ kiện." className="bg-emerald-50 p-6 sm:p-10 rounded-[40px] border-4 border-emerald-200 text-left space-y-6 my-8" collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="bg-white p-6 rounded-3xl border border-emerald-100 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
                <div className="text-left space-y-1">
                  <h4 className="font-black text-emerald-950 text-sm uppercase">Reset Level Pokémon</h4>
                  <p className="text-xs text-emerald-800/80 font-sans">Tất cả Pokémon của trainer sẽ trở về Level 1, XP/Mastery về 0.</p>
                </div>
                <button
                  onClick={handleResetPokemonLevels}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-wider shadow-lg active:scale-95 transition-all"
                >
                  Reset Level
                </button>
              </div>
            </SettingsSection>

            <SettingsSection id="ludo" icon="🐴" title="Customize Cá Ngựa" subtitle="Thêm, chỉnh sửa hoặc xóa ô đặc biệt trên bàn cờ 0-49." className="bg-amber-50 p-6 sm:p-10 rounded-[40px] border-4 border-amber-300 text-left space-y-6 my-8" collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="flex justify-end">
                <button onClick={() => setCustomLudoTiles(DEFAULT_LUDO_TILES)} className="bg-amber-200 hover:bg-amber-300 text-amber-950 px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all">
                  Khôi Phục Mặc Định 🔄
                </button>
              </div>
              <div className="bg-white p-5 rounded-3xl border-2 border-amber-200 space-y-4">
                <h4 className="font-black text-amber-950 text-sm uppercase">{editingTileIndex !== null ? `Chỉnh Sửa Ô Số ${editingTileIndex}` : 'Thêm/Sửa Ô Đặc Biệt Mới'}</h4>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <input type="number" min={0} max={49} value={tileFormIndex} onChange={e => setTileFormIndex(parseInt(e.target.value) || 0)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50" />
                  <input type="text" placeholder="Tên ô đặc biệt" value={tileFormTitle} onChange={e => setTileFormTitle(e.target.value)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50" />
                  <input type="text" placeholder="🚀" value={tileFormIcon} onChange={e => setTileFormIcon(e.target.value)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50" />
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <select value={tileFormType} onChange={e => setTileFormType(e.target.value as any)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50">
                    <option value="portal">🌀 Dịch Chuyển Tiến Bước</option>
                    <option value="curse">📜 Bùa Chú Đẩy Lùi</option>
                    <option value="monster">👹 Quái Vật Chặn Đường</option>
                    <option value="treasure">💎 Rương Báu Cộng Điểm</option>
                    <option value="restart">🌀 Lùi Về Xuất Phát</option>
                  </select>
                  <input type="number" value={tileFormValue} onChange={e => setTileFormValue(parseInt(e.target.value) || 0)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50" />
                </div>
                <input type="text" placeholder="Mô tả khi dẫm vào ô..." value={tileFormDesc} onChange={e => setTileFormDesc(e.target.value)} className="w-full border-2 border-amber-200 p-2.5 rounded-xl font-bold text-xs bg-amber-50/50" />
                <div className="flex gap-2">
                  <button onClick={handleSaveCustomTile} className="bg-amber-600 hover:bg-amber-700 text-white font-black px-6 py-2.5 rounded-xl text-xs uppercase tracking-wider shadow">{editingTileIndex !== null ? 'Cập Nhật Ô' : 'Lưu Ô Đặc Biệt'}</button>
                  {editingTileIndex !== null && <button onClick={resetTileForm} className="bg-gray-200 hover:bg-gray-300 text-gray-700 font-bold px-4 py-2.5 rounded-xl text-xs uppercase">Hủy</button>}
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 max-h-60 overflow-y-auto pr-1 custom-scrollbar">
                {Object.values(customLudoTiles).sort((a, b) => a.tileIndex - b.tileIndex).map(tile => (
                  <div key={tile.tileIndex} className="bg-white p-3 rounded-2xl border border-amber-200 shadow-xs flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 min-w-0">
                      <span className="text-xl shrink-0">{tile.icon}</span>
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-amber-950 truncate">Ô {tile.tileIndex}: {tile.title}</p>
                        <p className="text-[9px] text-amber-800 truncate">{tile.desc}</p>
                      </div>
                    </div>
                    <div className="flex gap-1 shrink-0">
                      <button onClick={() => editCustomTile(tile)} className="text-amber-700 hover:bg-amber-100 p-1 rounded font-bold text-xs">✏️</button>
                      <button onClick={() => deleteCustomTile(tile.tileIndex)} className="text-red-600 hover:bg-red-100 p-1 rounded font-bold text-xs">🗑️</button>
                    </div>
                  </div>
                ))}
              </div>
            </SettingsSection>

            <SettingsSection id="luckyWheel" icon="🎡" title="Customize Vòng Quay May Mắn" subtitle="Tùy chỉnh phần thưởng, hình phạt, HP, Pokémon skill và lượt lắc Cá Ngựa." className="bg-fuchsia-50 p-6 sm:p-10 rounded-[40px] border-4 border-fuchsia-200 text-left space-y-6 my-8" collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="flex flex-wrap justify-end gap-3">
                <button onClick={() => addLuckyWheelReward('points')} className="bg-fuchsia-700 hover:bg-fuchsia-800 text-white px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all">
                  + Thêm Mục Quay
                </button>
                <button onClick={() => addLuckyWheelReward('ludo_rolls')} className="bg-blue-700 hover:bg-blue-800 text-white px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all">
                  + Thêm Lượt Cá Ngựa
                </button>
                <button onClick={() => { if(confirm('Khôi phục danh sách Vòng quay may mắn mặc định?')) setLuckyWheelRewards(DEFAULT_LUCKY_WHEEL_REWARDS); }} className="bg-fuchsia-100 hover:bg-fuchsia-200 text-fuchsia-950 px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all border border-fuchsia-200">
                  Khôi Phục Mặc Định
                </button>
              </div>

              <div className="space-y-3 max-h-[520px] overflow-y-auto pr-1 custom-scrollbar">
                {luckyWheelRewards.map(reward => {
                  const needsAmount = reward.type === 'points' || reward.type === 'hp' || reward.type === 'ludo_rolls';
                  return (
                    <div key={reward.id} className="bg-white p-4 rounded-3xl border border-fuchsia-100 shadow-sm space-y-3">
                      <div className="grid grid-cols-1 md:grid-cols-[56px_1fr_150px_100px_80px_auto] gap-3 items-center">
                        <input value={reward.icon} onChange={e => updateLuckyWheelReward(reward.id, 'icon', e.target.value)} className="w-14 h-14 text-2xl text-center bg-fuchsia-50 rounded-2xl outline-none focus:ring-2 ring-fuchsia-100" />
                        <input value={reward.label} onChange={e => updateLuckyWheelReward(reward.id, 'label', e.target.value)} className="min-w-0 font-black text-sm border-b border-transparent focus:border-fuchsia-200 outline-none" />
                        <select value={reward.type} onChange={e => updateLuckyWheelReward(reward.id, 'type', e.target.value as LuckyWheelRewardType)} className="w-full bg-fuchsia-50 border border-fuchsia-100 rounded-xl p-2.5 text-xs font-black outline-none">
                          <option value="points">Điểm</option>
                          <option value="pokemon">Tặng Pokémon</option>
                          <option value="skill">Tặng Skill Pokémon</option>
                          <option value="hp">HP Pokémon</option>
                          <option value="ludo_rolls">Lượt Cá Ngựa</option>
                        </select>
                        <input
                          type="number"
                          min={reward.type === 'ludo_rolls' ? 1 : undefined}
                          max={reward.type === 'ludo_rolls' ? 5 : undefined}
                          disabled={!needsAmount}
                          value={reward.amount ?? 0}
                          onChange={e => {
                            const raw = parseInt(e.target.value) || 0;
                            const value = reward.type === 'ludo_rolls' ? Math.min(5, Math.max(1, raw)) : raw;
                            updateLuckyWheelReward(reward.id, 'amount', value);
                          }}
                          className="w-full text-center font-black text-xs p-2.5 bg-fuchsia-50 rounded-xl outline-none focus:ring-2 ring-fuchsia-100 disabled:opacity-30"
                        />
                        <input type="color" value={reward.color} onChange={e => updateLuckyWheelReward(reward.id, 'color', e.target.value)} className="w-20 h-11 bg-white border border-fuchsia-100 rounded-xl p-1" />
                        <button onClick={() => { if(confirm('Xóa mục vòng quay này?')) setLuckyWheelRewards(prev => prev.filter(x => x.id !== reward.id)); }} className="text-gray-300 hover:text-red-500 transition-colors p-2">🗑️</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </SettingsSection>

            <SettingsSection id="data" icon="☁️" title="Dữ liệu" subtitle="Import/export danh sách trainer và JSON backup toàn bộ hệ thống." className="bg-red-50 p-6 sm:p-12 rounded-[50px] border-4 border-red-100 text-center space-y-8" collapsedSections={settingsCollapsed} onToggle={toggleSettingsSection}>
              <div className="bg-white p-6 rounded-3xl border border-red-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-left space-y-1">
                  <h4 className="font-bold text-red-950 text-sm">Danh Sách Trainer (CSV / Excel)</h4>
                  <p className="text-xs text-red-800/80 font-sans">Nhập danh sách trainer từ bảng CSV.</p>
                </div>
                <div className="flex flex-wrap justify-center gap-4 shrink-0 font-sans">
                  <button onClick={() => {
                    const BOM = '\uFEFF';
                    const csv = "Họ tên, Lớp, Số điểm hiện tại, Giới tính (Nam/Nữ)\nNguyễn Văn A, 10A1, 100, Nam\nTrần Thị B, 10A1, 80, Nữ";
                    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8;' });
                    const link = document.createElement("a");
                    link.href = URL.createObjectURL(blob);
                    link.setAttribute("download", "mau_csv_trainer.csv");
                    link.click();
                  }} className="bg-white border-2 border-red-800 text-red-800 p-3 px-6 rounded-2xl font-bold hover:bg-red-800 hover:text-white transition-all text-xs shadow-md">Mẫu Excel 📥</button>
                  <label className="bg-red-800 hover:bg-red-950 text-white p-3 px-6 rounded-2xl font-bold cursor-pointer transition-all text-xs shadow-md">
                    Tải Lên Danh Sách 📤
                    <input type="file" accept=".csv" onChange={e => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      const reader = new FileReader();
                      reader.onload = (event) => {
                        const text = event.target?.result as string;
                        const lines = text.split('\n').filter(l => l.trim());
                        const newItems: Student[] = lines.slice(1).map(line => {
                          const [name, cls, pts, gender] = line.split(',').map(v => v.trim());
                          return { id: Math.random().toString(36).substr(2, 9), name: name || 'Ẩn danh', className: cls || 'Pokemon Class', points: parseInt(pts) || 0, gender: gender === 'Nữ' ? Gender.FEMALE : Gender.MALE, history: [], egg: createEgg('normal') };
                        });
                        setStudents(prev => [...prev, ...newItems]);
                        alert("Đã tiếp nhận!");
                      };
                      reader.readAsText(file);
                    }} className="hidden" />
                  </label>
                </div>
              </div>
              <div className="bg-white p-6 rounded-3xl border border-red-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="text-left space-y-1">
                  <h4 className="font-bold text-red-950 text-sm">Sao Lưu Toàn Bộ Hệ Thống (JSON Backup)</h4>
                  <p className="text-xs text-red-800/80 font-sans">Bao gồm trainer, điểm, lịch sử, Pokémon, công trạng, Pokémon skills và âm thanh.</p>
                </div>
                <div className="flex flex-wrap justify-center gap-4 shrink-0 font-sans">
                  <button onClick={handleExportJSON} className="bg-[#D4AF37] hover:bg-amber-600 text-white p-3 px-6 rounded-2xl font-bold transition-all text-xs shadow-md">Export JSON Backup 📦</button>
                  <label className="bg-teal-700 hover:bg-teal-900 text-white p-3 px-6 rounded-2xl font-bold cursor-pointer transition-all text-xs shadow-md">
                    Import JSON Restore 📥
                    <input type="file" accept=".json" onChange={handleImportJSON} className="hidden" />
                  </label>
                </div>
              </div>
            </SettingsSection>
          </div>
        )}
      </main>

      {/* MODAL: SKILL POINT BOARD */}
      {showSkillModal && (
        <div className="fixed inset-0 z-[220] flex items-center justify-center bg-black/80 p-0 sm:p-4 backdrop-blur-md">
          <div className="bg-white w-full max-w-5xl rounded-3xl h-full sm:h-auto sm:max-h-[90vh] overflow-hidden flex flex-col md:flex-row animate-in zoom-in duration-300 shadow-2xl">
            
            {/* Sidebar Profile details from screenshot request */}
            <div className="bg-gray-50 border-r w-full md:w-80 shrink-0 p-8 flex flex-col items-center">
              {sidebarData ? (
                <>
                  <div className="flex items-center justify-center gap-4 mb-6">
                    <div className="relative">
                      <StudentAvatar student={sidebarData.student} className="w-28 h-28 rounded-full border-4 border-white shadow-xl" />
                      <div className="absolute top-0 right-0 bg-green-600 text-white w-8 h-8 rounded-full flex items-center justify-center font-bold border-2 border-white shadow-md text-xs">
                        {sidebarData.student.points}
                      </div>
                    </div>

                    {sidebarData.student.pet && (
                      <div className="flex flex-col items-center bg-amber-50 p-2 rounded-2xl border border-amber-200 shadow-sm relative">
                        <div className="absolute -top-2 -right-2 bg-emerald-600 text-white text-[9px] font-black px-2 py-0.5 rounded-full border border-white shadow">
                          ❤️ {sidebarData.student.pet.hp ?? 100}/100
                        </div>
                        <img 
                          referrerPolicy="no-referrer"
                          src={getPokemonArtworkUrl(sidebarData.student.pet)}
	                          onError={event => handlePokemonArtworkError(event, sidebarData.student.pet)}
                          className="w-20 h-20 object-contain drop-shadow"
                          alt={getPokemonDisplayName(sidebarData.student.pet)}
                        />
                        <span className="text-[9px] font-black text-amber-900 truncate max-w-[80px]">{getPokemonDisplayName(sidebarData.student.pet)}</span>
                        <div className="w-full bg-gray-200 h-1.5 rounded-full overflow-hidden mt-1">
                          <div 
                            className={`h-full rounded-full transition-all duration-300 ${(sidebarData.student.pet.hp ?? 100) > 50 ? 'bg-emerald-500' : (sidebarData.student.pet.hp ?? 100) > 20 ? 'bg-amber-500' : 'bg-red-500'}`}
                            style={{ width: `${Math.min(100, Math.max(0, sidebarData.student.pet.hp ?? 100))}%` }}
                          />
                        </div>
                      </div>
                    )}
                  </div>

                  <h3 className="text-2xl font-bold text-gray-800 mb-1 text-center">{sidebarData.student.name}</h3>
                  <p className="text-xs font-black uppercase text-gray-400 mb-4">{sidebarData.student.className}</p>
                  
                  <div className="w-full space-y-4 pt-6 border-t border-gray-200">
                    <div className="text-center">
                      <p className="text-[10px] font-black uppercase text-gray-400">Level Hiện Tại</p>
                      <p className={`text-sm font-bold uppercase tracking-widest ${sidebarData.rank.color}`}>{sidebarData.rank.title}</p>
                    </div>
                    <div className="bg-green-100 p-4 rounded-2xl text-center border border-green-200">
                      <p className="text-[10px] font-black uppercase text-green-700">Điểm lên Level</p>
                      <p className="text-xl font-black text-green-800">+{sidebarData.pointsToNext}</p>
                    </div>
                    <div className="bg-red-100 p-4 rounded-2xl text-center border border-red-200">
                      <p className="text-[10px] font-black uppercase text-red-700">Điểm xuống Level</p>
                      <p className="text-xl font-black text-red-800">-{sidebarData.pointsToDemote}</p>
                    </div>
                  </div>
                </>
              ) : (
                <div className="text-center py-20 opacity-20 italic">Chọn 1 trainer để xem chi tiết...</div>
              )}
            </div>

            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="p-6 border-b flex justify-between items-center bg-gray-50/50">
                <div className="flex-1 flex items-center gap-4">
                  <h2 className="text-xl font-bold text-gray-800 shrink-0">
                    Feedback for {selectedStudentIds.length === 1 ? sidebarData?.student.name : `${selectedStudentIds.length} students`}
                  </h2>
                  <div className="flex items-center gap-2 bg-white border p-1 pl-3 rounded-full flex-1 max-w-[280px]">
                    <input 
                      type="number" 
                      placeholder="Gõ điểm..." 
                      className="bg-transparent text-sm font-bold flex-1 outline-none" 
                      value={manualPoints} 
                      onChange={e => setManualPoints(e.target.value)}
                    />
                    <button 
                      onClick={() => handleUpdatePoints(selectedStudentIds, parseInt(manualPoints), "Điều chỉnh thủ công", feedbackSource)}
                      className="bg-purple-600 text-white text-[10px] px-4 py-2 rounded-full font-bold hover:bg-purple-700 transition-all uppercase"
                    >
                      Lưu điểm
                    </button>
                  </div>
                </div>
                <button onClick={() => { setFeedbackSource('manual'); setShowSkillModal(false); }} className="ml-4 text-4xl text-gray-300 hover:text-red-800 transition-colors">&times;</button>
              </div>

              <div className="flex border-b px-6 bg-white shrink-0 overflow-x-auto">
                <button onClick={() => setActiveTab('positive')} className={`px-8 py-5 font-bold transition-all whitespace-nowrap ${activeTab === 'positive' ? 'text-purple-600 border-b-4 border-purple-600' : 'opacity-40 hover:opacity-100'}`}>Positive</button>
                <button onClick={() => setActiveTab('negative')} className={`px-8 py-5 font-bold transition-all whitespace-nowrap ${activeTab === 'negative' ? 'text-purple-600 border-b-4 border-purple-600' : 'opacity-40 hover:opacity-100'}`}>Needs work</button>
              </div>

              <div className="flex-1 overflow-y-auto p-8 custom-scrollbar bg-white">
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-6 pb-20">
                  {skills.filter(s => s.type === (activeTab === 'positive' ? 'positive' : 'negative')).map(sk => (
                    <button 
                      key={sk.id} 
                      onClick={() => handleUpdatePoints(selectedStudentIds, sk.points, sk.name, feedbackSource)} 
                      className="flex flex-col items-center justify-center gap-3 p-6 rounded-3xl border-2 border-gray-100 hover:border-purple-200 hover:bg-purple-50 transition-all group relative aspect-square"
                    >
                      <div className="text-5xl group-hover:scale-125 transition-transform duration-300">{sk.icon}</div>
                      <span className="text-xs font-bold text-center text-gray-600 uppercase tracking-tight leading-tight px-2">{sk.name}</span>
                      <span className={`absolute top-2 right-2 w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${sk.points > 0 ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {sk.points > 0 ? '+' : ''}{sk.points}
                      </span>
                    </button>
                  ))}
                  <button onClick={() => setCurrentScreen('settings')} className="flex flex-col items-center justify-center gap-3 p-6 rounded-3xl border-2 border-dashed border-gray-200 opacity-40 hover:opacity-100 transition-all aspect-square">
                     <div className="w-12 h-12 rounded-full border-2 border-purple-600 flex items-center justify-center text-3xl text-purple-600">+</div>
                     <span className="text-[10px] font-bold uppercase text-purple-600">Add skills</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: RANDOM */}
      {showRandomModal && (
        <div 
          onClick={(e) => { if (e.target === e.currentTarget) setShowRandomModal(false); }}
          className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md overflow-y-auto"
        >
          <div className="bg-white p-6 sm:p-8 rounded-[40px] w-full max-w-5xl text-center shadow-2xl animate-in zoom-in duration-300 relative border-4 border-red-800 my-auto">
            <button 
              onClick={() => setShowRandomModal(false)} 
              className="absolute top-5 right-5 text-3xl text-gray-400 hover:text-red-800 transition-colors z-20"
            >
              &times;
            </button>

            {/* MODE SWITCHER TABS */}
            <div className="flex items-center justify-center gap-2 mb-6 bg-red-50 p-1.5 rounded-full border border-red-200 w-fit mx-auto">
              <button 
                onClick={() => handleRandom('solo')} 
                className={`px-5 py-2 rounded-full font-bold text-xs transition-all uppercase tracking-wider ${randomMode === 'solo' ? 'bg-red-800 text-white shadow-md' : 'text-red-900 hover:bg-red-100'}`}
              >
                👤 Chế độ Solo
              </button>
              <button 
                onClick={() => handleRandom('battle')} 
                className={`px-5 py-2 rounded-full font-bold text-xs transition-all uppercase tracking-wider ${randomMode === 'battle' ? 'bg-red-800 text-white shadow-md' : 'text-red-900 hover:bg-red-100'}`}
              >
                ⚔️ Chế độ Battle
              </button>
              <button
                onClick={() => handleRandom('boss')}
                className={`px-5 py-2 rounded-full font-bold text-xs transition-all uppercase tracking-wider ${randomMode === 'boss' ? 'bg-red-800 text-white shadow-md' : 'text-red-900 hover:bg-red-100'}`}
              >
                👹 Boss
              </button>
            </div>

            {/* BOSS MODE */}
            {randomMode === 'boss' && (
              <>
                {activeBossRound && currentBossState && activeBossParty.length === BOSS_PARTY_SIZE ? (
                  <BossBattlePanel
                    boss={currentBossState.boss}
                    party={activeBossParty}
                    topContributors={currentBossTopContributors}
                    randomsSinceLastEncounter={currentBossState.randomsSinceLastEncounter}
                    nextEncounterAt={currentBossState.nextEncounterAt}
                    frequencyLabel={currentBossFrequencyOption.label}
                    resolving={bossRoundResolving}
                    visualResult={bossRoundVisualResult}
                    onSuccess={() => handleResolveBossRound('success')}
                    onFailure={() => handleResolveBossRound('failure')}
                  />
                ) : (
                  <div className="mx-auto max-w-2xl rounded-[32px] border-2 border-red-100 bg-red-50 p-8 text-center">
                    <div className="text-6xl">👹</div>
                    <h2 className="mt-4 text-3xl font-royal text-red-900">Boss đang ẩn nấp</h2>
                    <p className="mt-3 text-sm font-bold text-red-800">
                      Boss vẫn đang ở đâu đó. Tiếp tục Random Solo/Battle để tìm Boss.
                    </p>
                    <p className="mt-4 rounded-2xl bg-white px-4 py-3 text-xs font-black uppercase tracking-wider text-red-700">
                      {currentBossState
                        ? `Boss Frequency: ${currentBossFrequencyOption.label} · ${currentBossState.randomsSinceLastEncounter}/${currentBossState.nextEncounterAt} Random`
                        : 'Chọn một lớp cụ thể để kích hoạt Boss Raid per-class.'}
                    </p>
                    {currentBossState && (
                      <div className="mt-5 rounded-2xl border border-amber-200 bg-white p-4 text-left">
                        <p className="text-xs font-black text-amber-950">
                          Boss hiện tại: {currentBossState.boss.icon} {currentBossState.boss.name}
                        </p>
                        <div className="mt-2 h-3 overflow-hidden rounded-full bg-stone-100">
                          <div
                            className="h-full rounded-full bg-amber-500"
                            style={{ width: `${Math.max(0, Math.min(100, (currentBossState.boss.currentHp / currentBossState.boss.maxHp) * 100))}%` }}
                          />
                        </div>
                        <p className="mt-1 text-[10px] font-black text-stone-500">
                          HP {currentBossState.boss.currentHp}/{currentBossState.boss.maxHp}
                        </p>
                      </div>
                    )}
                    <button
                      onClick={() => handleRandom()}
                      className="mt-5 w-full rounded-2xl bg-amber-500 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg hover:bg-amber-600"
                    >
                      🎲 Random Tiếp
                    </button>
                  </div>
                )}
              </>
            )}

            {/* SOLO MODE */}
            {randomMode === 'solo' && randomStudent && (
              <>
                <h2 className="text-2xl font-royal text-red-800 mb-6 uppercase tracking-wider">Kén Chọn Ngẫu Nhiên (Solo)</h2>

                <div className="flex items-center justify-center gap-6 mb-6">
                  <div className="relative">
                    <StudentAvatar student={randomStudent} className="w-28 h-28 sm:w-32 sm:h-32 rounded-full border-4 border-red-800 shadow-xl" />
                    <div className="absolute top-0 right-0 bg-red-800 text-white w-9 h-9 rounded-full flex items-center justify-center font-bold border-2 border-white shadow text-sm">
                      {randomStudent.points}
                    </div>
                  </div>

                  <PokemonMiniStatus
                    pet={randomStudent.pet}
                    progress={randomStudent.pokemonProgress}
                    tone="amber"
                    className="w-64 max-w-[58vw]"
                  />
                </div>

                <div className="mb-6">
                  <h3 className="text-2xl sm:text-3xl font-bold text-gray-800">{randomStudent.name}</h3>
                  <p className="opacity-50 font-black uppercase tracking-widest text-xs mt-1">{randomStudent.className}</p>
                </div>

                {/* SKILLS BOUGHT FOR POKEMON DISPLAY & USE DIRECTLY */}
                {randomStudent.pet?.skills && randomStudent.pet.skills.length > 0 && (
                  <div className="mb-6 p-4 bg-indigo-50/60 rounded-3xl border border-indigo-100 text-left">
                    <p className="text-[10px] font-black uppercase text-indigo-900 tracking-wider mb-2">⚡ Tuyệt Chiêu Pokémon Có Thể Kích Hoạt (Tối Đa 2 Lần):</p>
                    <div className="space-y-2 max-h-36 overflow-y-auto pr-1 custom-scrollbar">
                      {randomStudent.pet.skills.map(skId => {
                        const sk = petSkills.find(x => x.id === skId);
                        if (!sk) return null;
                        const currentUses = randomStudent.pet?.skillUses?.[skId] || 0;
                        const remainingUses = Math.max(0, 2 - currentUses);
                        return (
                          <div key={skId} className="flex items-center justify-between bg-white p-2.5 rounded-2xl border border-indigo-200 gap-2">
                            <div className="flex items-center gap-2 min-w-0">
                              <span className="text-xl">{sk.icon}</span>
                              <div className="min-w-0">
                                <p className="text-xs font-bold text-gray-800 truncate">{sk.name}</p>
                                <span className="text-[9px] text-indigo-600 font-semibold">Còn {remainingUses}/2 lượt</span>
                              </div>
                            </div>
                            <button
                              disabled={remainingUses <= 0}
                              onClick={() => {
                                handleUsePetSkill(randomStudent.id, skId, sk.name);
                                const updated = students.find(s => s.id === randomStudent.id);
                                if (updated) setRandomStudent(updated);
                              }}
                              className="bg-indigo-600 hover:bg-indigo-700 disabled:opacity-40 text-white font-black text-[9px] px-3 py-1.5 rounded-xl uppercase tracking-wider shrink-0"
                            >
                              Sử Dụng
                            </button>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="flex flex-col sm:flex-row gap-3">
                  <button 
                    onClick={() => { setFeedbackSource('solo'); setShowSkillModal(true); }} 
                    className="flex-1 bg-red-800 text-white py-3.5 rounded-2xl font-bold text-sm shadow-lg hover:bg-red-900 uppercase tracking-wider"
                  >
                    Ban Thưởng / Phạt
                  </button>
                  <button 
                    onClick={() => handleRandom()} 
                    className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3.5 rounded-2xl font-bold text-sm shadow-lg uppercase tracking-wider flex items-center justify-center gap-2"
                  >
                    <span>🎲</span> Random Tiếp
                  </button>
                </div>
                <button 
                  onClick={() => setShowRandomModal(false)} 
                  className="mt-3 text-gray-400 font-bold py-1 uppercase text-xs hover:text-gray-600"
                >
                  Đóng lại
                </button>
              </>
            )}

            {/* BATTLE MODE */}
            {randomMode === 'battle' && battleStudentA && battleStudentB && (
              <>
                <h2 className="text-2xl font-royal text-red-800 mb-2 uppercase tracking-wider">⚡ Trận Quyết Đấu (Battle) ⚡</h2>
                <p className="text-xs text-gray-500 mb-6 italic">Nhập điểm hoặc bấm nút cộng điểm cho mỗi trainer. Người thắng được cộng HP theo điểm chênh lệch, người thua bị trừ HP chênh lệch!</p>

                {battleResultSummary ? (
                  <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-6 rounded-3xl border-4 border-amber-400 space-y-6 shadow-xl animate-in zoom-in-95 duration-200 text-left">
                    <div className="text-center space-y-2">
                      <span className="text-4xl">🏆</span>
                      <h3 className="text-2xl font-black text-amber-950 uppercase tracking-wide">
                        {battleResultSummary.winner ? `Chiến Thắng: ${battleResultSummary.winner.name}` : 'Trận Đấu Hòa!'}
                      </h3>
                      <p className="text-sm font-bold text-amber-900 whitespace-pre-line bg-white/90 p-4 rounded-2xl border border-amber-200 shadow-xs">
                        {battleResultSummary.resultMsg}
                      </p>
                    </div>

                    {/* Ordered Cá Ngựa turns after Battle */}
                    <div className="bg-white p-4 rounded-2xl border-2 border-amber-300 space-y-3">
                      <p className="text-xs font-black uppercase text-amber-950 tracking-wider text-center">
                        🎲 Thứ Tự Lắc Cá Ngựa Sau Battle:
                      </p>
                      {battleResultSummary.ludoTurns.length > 0 ? (
                        <>
                          <div className="space-y-2">
                            {battleResultSummary.ludoTurns.map((turn, index) => {
                              const turnStudent = [battleResultSummary.studentA, battleResultSummary.studentB].find(s => s.id === turn.studentId);
                              if (!turnStudent) return null;
                              return (
                                <div key={`${turn.studentId}-${index}`} className="flex items-center justify-between rounded-xl border border-amber-200 bg-amber-50 px-3 py-2">
                                  <span className="text-xs font-black text-amber-950">{index + 1}. {turnStudent.name}</span>
                                  <span className="text-[10px] font-black uppercase text-amber-700">
                                    {turn.role === 'winner' ? 'Thắng - lắc trước' : turn.role === 'loser' ? 'Thua - lắc sau' : 'Hòa'}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                          <button
                            onClick={() => {
                              setShowRandomModal(false);
                              openBattleLudoTurns(battleResultSummary.ludoTurns);
                            }}
                            className="w-full bg-amber-600 hover:bg-amber-700 text-white p-3 rounded-xl font-black text-xs uppercase tracking-wider shadow-md flex items-center justify-center gap-2 transition-all border-2 border-amber-400"
                          >
                            <span>🎲</span> Mở Cá Ngựa Theo Thứ Tự
                          </button>
                        </>
                      ) : (
                        <p className="rounded-xl bg-rose-50 p-3 text-center text-xs font-black text-rose-700">
                          Không có lượt Cá Ngựa hợp lệ vì điểm Battle không lớn hơn 0.
                        </p>
                      )}
                    </div>

                    <div className="flex gap-3">
                      <button 
                        onClick={() => handleRandom('battle')} 
                        className="flex-1 bg-red-800 text-white py-3 rounded-xl font-black text-xs uppercase tracking-wider hover:bg-red-900 shadow"
                      >
                        ⚔️ Quyết Đấu Trận Mới
                      </button>
                      <button 
                        onClick={() => setShowRandomModal(false)} 
                        className="px-5 bg-gray-200 text-gray-700 font-bold py-3 rounded-xl text-xs uppercase hover:bg-gray-300"
                      >
                        Đóng
                      </button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
                      {/* STUDENT A CARD */}
                      <div className="bg-amber-50/80 p-4 rounded-3xl border-2 border-amber-300 flex flex-col items-center">
                        <span className="bg-amber-500 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-2">
                          Trainer A
                        </span>
                        <StudentAvatar student={battleStudentA} className="w-20 h-20 rounded-full border-4 border-amber-400 shadow-md mb-2" />
                        <h4 className="font-extrabold text-gray-800 text-base">{battleStudentA.name}</h4>
                        <p className="text-[10px] text-gray-500 font-bold mb-2">Hào quang: {battleStudentA.points}đ</p>

                        <PokemonMiniStatus
                          pet={battleStudentA.pet}
                          progress={battleStudentA.pokemonProgress}
                          tone="amber"
                          showImage
                          streakLabel="Battle"
                          streakValue={battleStudentA.pokemonProgress?.battleWinStreak || 0}
                          className="mb-3 w-full"
                        />

                        <div className="w-full">
                          <p className="text-[10px] font-black uppercase text-amber-800 mb-1">Điểm Battle Vòng Này:</p>
                          <div className="flex items-center justify-center gap-1 mb-2">
                            {[-1, +1, +2, +3, +5].map(pts => (
                              <button
                                key={pts}
                                onClick={() => setBattleScoreA(prev => Math.max(-10, prev + pts))}
                                className={`px-2 py-1 rounded-lg text-xs font-black ${pts > 0 ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}
                              >
                                {pts > 0 ? `+${pts}` : pts}
                              </button>
                            ))}
                          </div>
                          <input 
                            type="number"
                            value={battleScoreA}
                            onChange={e => setBattleScoreA(parseInt(e.target.value) || 0)}
                            className="w-20 mx-auto text-center font-black text-lg border-2 border-amber-400 rounded-xl py-1 bg-white"
                          />
                        </div>
                      </div>

                      {/* STUDENT B CARD */}
                      <div className="bg-purple-50/80 p-4 rounded-3xl border-2 border-purple-300 flex flex-col items-center">
                        <span className="bg-purple-600 text-white text-[10px] font-black px-2.5 py-0.5 rounded-full uppercase tracking-wider mb-2">
                          Trainer B
                        </span>
                        <StudentAvatar student={battleStudentB} className="w-20 h-20 rounded-full border-4 border-purple-400 shadow-md mb-2" />
                        <h4 className="font-extrabold text-gray-800 text-base">{battleStudentB.name}</h4>
                        <p className="text-[10px] text-gray-500 font-bold mb-2">Hào quang: {battleStudentB.points}đ</p>

                        <PokemonMiniStatus
                          pet={battleStudentB.pet}
                          progress={battleStudentB.pokemonProgress}
                          tone="purple"
                          showImage
                          streakLabel="Battle"
                          streakValue={battleStudentB.pokemonProgress?.battleWinStreak || 0}
                          className="mb-3 w-full"
                        />

                        <div className="w-full">
                          <p className="text-[10px] font-black uppercase text-purple-800 mb-1">Điểm Battle Vòng Này:</p>
                          <div className="flex items-center justify-center gap-1 mb-2">
                            {[-1, +1, +2, +3, +5].map(pts => (
                              <button
                                key={pts}
                                onClick={() => setBattleScoreB(prev => Math.max(-10, prev + pts))}
                                className={`px-2 py-1 rounded-lg text-xs font-black ${pts > 0 ? 'bg-emerald-600 text-white' : 'bg-red-600 text-white'}`}
                              >
                                {pts > 0 ? `+${pts}` : pts}
                              </button>
                            ))}
                          </div>
                          <input 
                            type="number"
                            value={battleScoreB}
                            onChange={e => setBattleScoreB(parseInt(e.target.value) || 0)}
                            className="w-20 mx-auto text-center font-black text-lg border-2 border-purple-400 rounded-xl py-1 bg-white"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3">
                      <button 
                        onClick={handleResolveBattle} 
                        className="flex-1 bg-red-800 text-white py-3.5 rounded-2xl font-black text-sm shadow-xl hover:bg-red-900 uppercase tracking-wider flex items-center justify-center gap-2"
                      >
                        <span>⚔️</span> Chốt Trận & Trao Thưởng
                      </button>
                      <button 
                        onClick={() => handleRandom()} 
                        className="flex-1 bg-amber-500 hover:bg-amber-600 text-white py-3.5 rounded-2xl font-bold text-sm shadow-lg uppercase tracking-wider flex items-center justify-center gap-2"
                      >
                        <span>🎲</span> Random Tiếp
                      </button>
                    </div>
                  </>
                )}
                <button 
                  onClick={() => setShowRandomModal(false)} 
                  className="mt-3 text-gray-400 font-bold py-1 uppercase text-xs hover:text-gray-600"
                >
                  Đóng lại
                </button>
              </>
            )}
          </div>
        </div>
      )}

      {/* MODAL: LUCKY WHEEL */}
      {showLuckyWheelModal && (
        <div
          onClick={(e) => {
            if (e.target === e.currentTarget && !isLuckyWheelSpinning) {
              setLuckyWheelMode('normal');
              setShowLuckyWheelModal(false);
            }
          }}
          className="fixed inset-0 z-[220] flex items-center justify-center bg-black/90 p-4 backdrop-blur-md overflow-y-auto"
        >
          <div className="bg-[#17051f] w-full max-w-5xl rounded-[40px] shadow-[0_0_80px_rgba(217,70,239,0.55)] overflow-hidden animate-in zoom-in duration-300 relative border-4 border-fuchsia-500 my-auto">
            <button
              onClick={() => {
                if (!isLuckyWheelSpinning) {
                  setLuckyWheelMode('normal');
                  setShowLuckyWheelModal(false);
                }
              }}
              disabled={isLuckyWheelSpinning}
              className="absolute top-5 right-5 text-3xl text-white/70 hover:text-white disabled:opacity-30 transition-colors z-20"
            >
              &times;
            </button>

            <div className="bg-gradient-to-r from-red-950 via-fuchsia-900 to-purple-950 text-white p-6 sm:p-8 relative overflow-hidden">
              <div className="absolute inset-0 opacity-40 bg-[radial-gradient(circle_at_20%_30%,rgba(250,204,21,0.45),transparent_24%),radial-gradient(circle_at_80%_20%,rgba(34,211,238,0.35),transparent_24%),radial-gradient(circle_at_50%_90%,rgba(217,70,239,0.45),transparent_30%)]" />
              <div className="flex items-center gap-4 relative z-10">
                <div className="w-14 h-14 rounded-3xl bg-white/15 border border-white/30 flex items-center justify-center text-4xl shadow-inner">
                  🎡
                </div>
                <div>
                  <h2 className="text-2xl sm:text-3xl font-royal uppercase tracking-wider text-amber-200">Vòng Quay May Mắn</h2>
                  <p className="text-xs sm:text-sm text-fuchsia-100 font-bold mt-1">
                    {isLuckyWheelSpinning
                      ? 'Đang quay trong 10 giây...'
                      : luckyWheelMode === 'ludo-finish'
                        ? 'Cán đích Cá Ngựa: 60% quà tốt, 40% quà thử thách.'
                        : 'Bấm quay để bắt đầu chọn trainer và phần thưởng ngẫu nhiên.'}
                  </p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_0.9fr] gap-8 p-6 sm:p-8 bg-[radial-gradient(circle_at_top,rgba(250,204,21,0.22),transparent_34%),linear-gradient(135deg,#3b0764,#701a75_45%,#111827)]">
              <div className="flex flex-col items-center justify-center gap-6">
                <div className="relative w-[min(82vw,380px)] aspect-square">
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 z-30 w-0 h-0 border-l-[16px] border-r-[16px] border-t-[34px] border-l-transparent border-r-transparent border-t-red-800 drop-shadow-lg" />
                  <div
                    ref={luckyWheelRef}
                    className="absolute inset-0 rounded-full border-[10px] border-amber-300 shadow-[0_0_45px_rgba(250,204,21,0.85),0_0_90px_rgba(217,70,239,0.5)] overflow-hidden"
                    style={{
                      background: luckyWheelBackground,
                      transform: `rotate(${luckyWheelRotation}deg)`
                    }}
                  >
                    {(luckyWheelDisplayRewards.length > 0 ? luckyWheelDisplayRewards : luckyWheelRewards).map((reward, idx, arr) => {
                      const angle = idx * (360 / arr.length) + (180 / arr.length);
                      const label = reward.type === 'points' || reward.type === 'hp'
                        ? `${reward.icon}${reward.amount && reward.amount > 0 ? '+' : ''}${reward.amount}`
                        : reward.type === 'ludo_rolls'
                          ? `${reward.icon}x${Math.min(5, Math.max(1, reward.amount || 1))}`
                        : reward.icon;
                      return (
                        <span
                          key={reward.id}
                          className="absolute left-1/2 top-1/2 text-sm sm:text-base font-black text-white drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] select-none"
                          style={{
                            transform: `translate(-50%, -50%) rotate(${angle}deg) translateY(calc(-1 * min(34vw, 150px))) rotate(${-angle}deg)`
                          }}
                        >
                          {label}
                        </span>
                      );
                    })}
                  </div>
                  <div className="absolute inset-[35%] rounded-full bg-white border-8 border-amber-300 shadow-xl flex items-center justify-center text-5xl z-20">
                    {isLuckyWheelSpinning ? '🎲' : (luckyWheelResult?.reward.icon || luckyWheelPendingResult?.reward.icon || '🎡')}
                  </div>
                  <div className="absolute -inset-6 rounded-full border border-amber-300/30 shadow-[0_0_60px_rgba(250,204,21,0.55)] pointer-events-none" />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 w-full max-w-xl text-xs font-black uppercase tracking-wide">
                  <div className="bg-emerald-100 text-emerald-800 rounded-2xl px-3 py-2 text-center">+ Điểm tối đa 10</div>
                  <div className="bg-red-100 text-red-800 rounded-2xl px-3 py-2 text-center">- Điểm tối đa 10</div>
                  <div className="bg-amber-100 text-amber-900 rounded-2xl px-3 py-2 text-center">Tặng Pokemon</div>
                  <div className="bg-purple-100 text-purple-900 rounded-2xl px-3 py-2 text-center">Tặng Skill</div>
                  <div className="bg-teal-100 text-teal-900 rounded-2xl px-3 py-2 text-center">Cộng HP</div>
                  <div className="bg-blue-100 text-blue-900 rounded-2xl px-3 py-2 text-center">Lượt Cá Ngựa</div>
                </div>
              </div>

              <div className="space-y-5">
                <div className="bg-white/95 rounded-3xl border border-fuchsia-100 p-5 shadow-[0_0_24px_rgba(255,255,255,0.22)]">
                  <p className="text-[10px] font-black uppercase tracking-[0.25em] text-fuchsia-900 mb-3">Danh sách được quay</p>
                  <div className="flex flex-wrap gap-2 max-h-28 overflow-y-auto custom-scrollbar pr-1">
                    {luckyWheelCandidateIds.map(id => {
                      const candidate = students.find(s => s.id === id);
                      if (!candidate) return null;
                      return (
                        <span key={id} className="bg-fuchsia-50 border border-fuchsia-200 text-fuchsia-950 px-3 py-1.5 rounded-full text-xs font-black">
                          {candidate.name}
                        </span>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-white rounded-[32px] border-2 border-amber-200 p-6 min-h-[360px] flex flex-col items-center justify-center text-center shadow-[0_0_36px_rgba(250,204,21,0.35)]">
                  {!isLuckyWheelSpinning && !luckyWheelResult && (
                    <div className="w-full space-y-5 animate-in zoom-in-95 duration-300">
                      <div className="text-6xl drop-shadow">🎡</div>
                      <h3 className="text-3xl font-royal text-fuchsia-900 uppercase">Sẵn sàng quay</h3>
                      <p className="text-sm font-bold text-gray-500">
                        {luckyWheelMode === 'ludo-finish'
                          ? 'Lượt cán đích ưu tiên 60% phần quà tốt và 40% phần quà không tốt.'
                          : 'Kết quả sẽ được random sau khi bấm nút bên dưới.'}
                      </p>
                      <button
                        onClick={startLuckyWheelSpin}
                        className="w-full bg-gradient-to-r from-amber-500 via-fuchsia-600 to-cyan-500 hover:brightness-110 text-white py-4 rounded-2xl font-black uppercase tracking-wider shadow-[0_0_28px_rgba(217,70,239,0.6)] transition-all"
                      >
                        Bắt Đầu Quay
                      </button>
                    </div>
                  )}

                  {isLuckyWheelSpinning && (
                    <div className="space-y-4 animate-pulse">
                      <div className="text-6xl">🎡</div>
                      <h3 className="text-2xl font-royal text-fuchsia-900 uppercase">Đang quay...</h3>
                      <p className="text-sm font-bold text-gray-500">Bánh xe đang tăng tốc rồi chậm lại trong 3 giây cuối.</p>
                    </div>
                  )}

                  {!isLuckyWheelSpinning && luckyWheelResult && (
                    <div className="w-full space-y-5 animate-in zoom-in-95 duration-300">
                      <div className="flex flex-col items-center gap-3">
                        <StudentAvatar student={luckyWheelResult.student} className="w-24 h-24 rounded-full border-4 border-fuchsia-700 shadow-xl" />
                        <div>
                          <p className="text-[10px] font-black uppercase tracking-[0.25em] text-fuchsia-700">Trainer trúng thưởng</p>
                          <h3 className="text-3xl font-black text-gray-900">{luckyWheelResult.student.name}</h3>
                          <p className="text-xs font-bold text-gray-400 uppercase">{luckyWheelResult.student.className}</p>
                        </div>
                      </div>

                      <div className="bg-gradient-to-br from-amber-50 to-fuchsia-50 rounded-3xl border border-amber-200 p-5">
                        <div className="text-5xl mb-2">{luckyWheelResult.reward.icon}</div>
                        <p className="text-2xl font-black text-fuchsia-950">{luckyWheelResult.reward.label}</p>
                        <p className="mt-2 text-base font-black text-gray-700">{luckyWheelResult.message}</p>

                        {luckyWheelResult.pokemon && (
                          <img
                            referrerPolicy="no-referrer"
                            src={getPokemonArtworkUrl(luckyWheelResult.pokemon)}
	                            onError={event => handlePokemonArtworkError(event, luckyWheelResult.pokemon)}
                            className={`w-28 h-28 object-contain mx-auto mt-3 drop-shadow ${luckyWheelResult.pokemon.isShiny ? 'rounded-3xl bg-amber-100 ring-4 ring-amber-300' : ''}`}
                            alt={getPokemonDisplayName(luckyWheelResult.pokemon)}
                          />
                        )}
                        {luckyWheelResult.pokemon?.isShiny && (
                          <span className="mt-2 inline-flex rounded-full border border-amber-300 bg-amber-100 px-3 py-1 text-[10px] font-black uppercase tracking-wider text-amber-800">
                            ✨ Shiny
                          </span>
                        )}

                        {luckyWheelResult.skill && (
                          <div className="mt-3 inline-flex items-center gap-2 bg-white border border-purple-200 rounded-2xl px-4 py-2 text-purple-950 font-black text-sm">
                            <span className="text-2xl">{luckyWheelResult.skill.icon}</span>
                            <span>{luckyWheelResult.skill.name}</span>
                          </div>
                        )}

                        {luckyWheelResult.reward.type === 'ludo_rolls' && (
                          <button
                            onClick={() => {
                              setLuckyWheelMode('normal');
                              setShowLuckyWheelModal(false);
                              openLudoForClass(luckyWheelResult.student.className, luckyWheelResult.student);
                            }}
                            className="mt-4 bg-blue-700 hover:bg-blue-800 text-white px-5 py-2.5 rounded-2xl text-xs font-black uppercase tracking-wider shadow"
                          >
                            Mở Đường Đua Cá Ngựa
                          </button>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          setLuckyWheelMode('normal');
                          setShowLuckyWheelModal(false);
                        }}
                        className="w-full bg-fuchsia-800 hover:bg-fuchsia-900 text-white py-3.5 rounded-2xl font-black uppercase tracking-wider shadow-lg transition-all"
                      >
                        Hoàn tất
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: GROUP MAKER */}
      {showGroupModal && (
        <div className="fixed inset-0 z-[100] flex flex-col bg-white overflow-hidden animate-in fade-in duration-300">
           <div className="bg-red-800 text-white p-6 flex justify-between items-center shadow-lg shrink-0">
             <div className="flex items-center gap-3">
               <span className="text-3xl">👥</span>
               <h2 className="text-2xl font-royal uppercase tracking-wider">Chia Nhóm Tự Động</h2>
             </div>
             <button onClick={() => setShowGroupModal(false)} className="bg-white/20 hover:bg-white/30 text-white px-6 py-2 rounded-xl font-bold text-sm uppercase transition-all">← Quay Lại</button>
           </div>

           <div className="flex-1 p-6 sm:p-10 overflow-y-auto max-w-7xl mx-auto w-full space-y-8">
             <div className="bg-red-50 p-6 rounded-3xl border border-red-200 text-center space-y-4">
               <h3 className="text-xl font-bold text-red-900">Chọn Số Lượng Trainer Tối Đa Trong 1 Nhóm:</h3>
               <div className="flex flex-wrap justify-center gap-3">
                  {[2, 3, 4, 5, 6, 7, 8].map(n => (
                    <button 
                      key={n} 
                      onClick={() => setGroupSize(n)} 
                      className={`w-14 h-14 rounded-2xl border-2 text-xl font-black transition-all ${groupSize === n ? 'border-red-800 text-white bg-red-800 shadow-md scale-110' : 'border-gray-200 text-gray-700 bg-white hover:border-red-400'}`}
                    >
                      {n}
                    </button>
                  ))}
               </div>
               <button onClick={handleMakeGroups} className="bg-red-800 text-white p-4 px-10 rounded-2xl font-extrabold text-lg shadow-xl hover:bg-red-900 uppercase tracking-wider transition-all">Tạo Nhóm Ngay 🎲</button>
             </div>

             {generatedGroups.length > 0 && (
               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {generatedGroups.map((g, idx) => (
                    <div key={idx} className="p-6 rounded-3xl border-2 border-red-200 bg-gradient-to-b from-red-50/50 to-white shadow-md">
                       <p className="font-black text-red-800 text-lg mb-4 border-b-2 border-red-200 pb-2 flex justify-between items-center">
                         <span>NHÓM {idx+1}</span>
                         <span className="text-xs bg-red-800 text-white px-3 py-1 rounded-full font-sans">{g.length} Trainer</span>
                       </p>
                       <div className="space-y-2.5">
                         {g.map(s => (
                           <div key={s.id} className="flex items-center gap-3 bg-white p-3 rounded-2xl border border-gray-100 shadow-xs">
                             <StudentAvatar student={s} className="w-10 h-10 rounded-full border border-red-200" />
                             <span className="text-xl md:text-2xl font-bold text-gray-800">{s.name}</span>
                           </div>
                         ))}
                       </div>
                    </div>
                  ))}
               </div>
             )}
           </div>
        </div>
      )}

      {/* MODAL: TIMER */}
      {showTimerModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-md">
           <div className="bg-white w-full max-w-sm rounded-[36px] shadow-2xl overflow-hidden animate-in zoom-in relative border-4 border-purple-600">
              <button onClick={() => setShowTimerModal(false)} className="absolute top-4 right-4 text-white hover:text-amber-300 text-3xl font-bold z-10 transition-colors">&times;</button>
              <div className="bg-purple-600 p-8 text-center text-white relative">
                 <div className="text-5xl mb-2">⌛</div>
                 <h2 className="text-2xl font-black uppercase tracking-wider">Đồng Hồ Đếm Giờ</h2>
              </div>
              <div className="p-8 space-y-6">
                 <div className="text-6xl font-black text-center text-purple-950 tabular-nums bg-purple-50 p-4 rounded-3xl border border-purple-100 shadow-inner">
                   {Math.floor(timerTime / 60)}:{String(timerTime % 60).padStart(2, '0')}
                 </div>
                 
                 <div className="flex gap-2 items-center bg-gray-50 border p-2 rounded-2xl">
                    <input 
                      type="number" 
                      placeholder="Nhập số phút..." 
                      className="flex-1 bg-transparent p-2 text-sm font-bold outline-none" 
                      value={customMinutes}
                      onChange={e => setCustomMinutes(e.target.value)}
                    />
                    <button 
                      onClick={() => {
                        const mins = parseInt(customMinutes);
                        if (!isNaN(mins)) startTimer(mins * 60);
                        setCustomMinutes('');
                      }}
                      className="bg-purple-600 text-white px-5 py-2 rounded-xl font-bold text-xs uppercase"
                    >Cài Giờ</button>
                 </div>

                 <div className="grid grid-cols-3 gap-2">
                   {[15, 30, 60, 180, 300, 600].map(s => (
                     <button key={s} onClick={() => startTimer(s)} className="p-3 border-2 border-gray-100 rounded-2xl text-sm font-black text-gray-600 hover:border-purple-300 hover:text-purple-700 transition-all">
                       {s < 60 ? `${s}s` : `${s/60}p`}
                     </button>
                   ))}
                 </div>
                 <button onClick={() => { if(timerRunning) { setTimerRunning(false); clearInterval(timerRef.current!); } else { startTimer(timerTime); } }} className="w-full bg-purple-600 hover:bg-purple-700 text-white py-4 rounded-2xl font-bold text-lg shadow-xl uppercase tracking-wider transition-all">
                   {timerRunning ? 'Tạm Dừng ⏸️' : 'Bắt Đầu 🔴'}
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* MODAL: CÁ NGỰA BOARD GAME */}
      {showLudoModal && (
        <div className="fixed inset-0 z-[120] flex flex-col overflow-hidden bg-[radial-gradient(circle_at_20%_0%,rgba(250,204,21,0.28),transparent_30%),radial-gradient(circle_at_90%_20%,rgba(239,68,68,0.24),transparent_34%),linear-gradient(135deg,#1e1207,#451a03_48%,#111827)] backdrop-blur-md animate-in fade-in duration-300">
          <div className="border-b-4 border-amber-400/80 bg-black/45 p-4 px-6 text-amber-100 shadow-2xl backdrop-blur-xl shrink-0 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <span className="grid h-12 w-12 place-items-center rounded-2xl border border-amber-200/60 bg-amber-300 text-3xl shadow-[0_0_28px_rgba(251,191,36,0.55)]">🐴</span>
              <div>
                <h2 className="text-xl font-royal uppercase tracking-widest text-amber-300">Đường Đua Cá Ngựa (50 Ô)</h2>
                <p className="text-[10px] text-amber-100/85">Lớp {activeLudoClassName || 'Chưa chọn'} - 1 ô chỉ có 1 trainer đứng, trừ ô 0.</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                disabled={ludoRolling || battleLudoQueue.length > 0}
                onClick={handleRandomFromLudo}
                className="rounded-xl border border-emerald-300/70 bg-emerald-500/25 px-5 py-2 text-xs font-black uppercase tracking-wider text-white shadow-lg transition-all hover:bg-emerald-500/35 disabled:cursor-not-allowed disabled:opacity-45"
                title={battleLudoQueue.length > 0 ? 'Hoàn tất queue Cá Ngựa trước khi Random tiếp.' : 'Quay lại Random tiếp'}
              >
                🎲 Random Tiếp
              </button>
              <button onClick={() => { setBattleLudoQueue([]); setLudoReturnHint(null); setShowLudoModal(false); }} className="rounded-xl border border-amber-300/70 bg-amber-400/20 px-5 py-2 text-xs font-bold uppercase tracking-wider text-white shadow-lg transition-all hover:bg-amber-400/30">
                ← Quay Lại Lớp
              </button>
            </div>
          </div>

          <div className="flex-1 p-4 overflow-y-auto max-w-7xl mx-auto w-full flex flex-col lg:flex-row gap-6">
            {/* Left side: Interactive Board */}
            <div className="flex-1 rounded-[34px] border-4 border-amber-300/90 bg-white/88 p-5 shadow-[0_30px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl space-y-5">
              <div className="flex flex-col gap-3 border-b border-amber-200 pb-3 xl:flex-row xl:items-center xl:justify-between">
                <div>
                  <h3 className="font-extrabold text-amber-950 text-base">Battle Race Board - Ô 0 đến {LUDO_FINISH_TILE}</h3>
                  <p className="mt-1 text-[10px] font-bold uppercase tracking-wider text-amber-700">
                    Càng gần đích càng nhiều bẫy lùi, restart và quái vật giữ cổng.
                  </p>
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <select
                    value={activeLudoClassName}
                    onChange={e => {
                      setLudoClassName(e.target.value);
                      setLudoActiveStudent(null);
                      setBattleLudoQueue([]);
                      setLudoReturnHint(null);
                      setLudoDice(null);
                    }}
                    className="bg-amber-100 text-amber-950 border border-amber-300 px-3 py-1.5 rounded-xl text-xs font-black outline-none"
                  >
                    {classOptions.map(cls => (
                      <option key={cls} value={cls}>{cls}</option>
                    ))}
                  </select>
                  <span className="rounded-full bg-amber-100 px-3 py-1 text-xs font-bold text-amber-800">Tổng trainer: {ludoRaceStudents.length}</span>
                  <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-black text-red-800">
                    Ô đặc biệt: {ludoSpecialTileCount}/50 ({Math.round((ludoSpecialTileCount / 50) * 100)}%)
                  </span>
                  <span className="rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-800">Đích xong về ô 0</span>
                </div>
              </div>

              {/* Grid of 50 tiles */}
              <div className="grid grid-cols-5 gap-2 rounded-[30px] border-2 border-amber-200 bg-gradient-to-br from-amber-100 via-orange-50 to-red-100 p-3 shadow-inner sm:grid-cols-10">
                {Array.from({ length: 50 }).map((_, tileIdx) => {
                  const spec = effectiveLudoTiles[tileIdx];
                  const studentsOnTile = ludoRaceStudents.filter(s => (ludoPositions[s.id] || 0) === tileIdx);
                  const hasActiveStudent = studentsOnTile.some(st => st.id === ludoActiveStudent?.id);

                  return (
                    <div 
                      key={tileIdx} 
                      className={`relative flex min-h-[78px] flex-col items-center justify-between rounded-2xl border-2 p-1.5 shadow-sm transition-all hover:-translate-y-0.5 hover:shadow-lg sm:min-h-[88px] ${
                        tileIdx === 0 ? 'bg-gradient-to-b from-green-100 to-emerald-50 border-green-500' :
                        tileIdx === LUDO_FINISH_TILE ? 'bg-gradient-to-b from-yellow-200 via-amber-100 to-orange-100 border-yellow-500 shadow-[0_0_24px_rgba(250,204,21,0.45)]' :
                        spec?.type === 'monster' ? 'bg-gradient-to-b from-red-100 to-rose-50 border-red-500' :
                        spec?.type === 'curse' ? 'bg-gradient-to-b from-purple-100 to-fuchsia-50 border-purple-500' :
                        spec?.type === 'portal' ? 'bg-gradient-to-b from-blue-100 to-sky-50 border-blue-500' :
                        spec?.type === 'treasure' ? 'bg-gradient-to-b from-amber-100 to-yellow-50 border-amber-500' : 'bg-gradient-to-b from-stone-50 to-amber-50/30 border-stone-200 hover:border-amber-400'
                      } ${hasActiveStudent ? 'ring-4 ring-cyan-300/70 scale-[1.03]' : ''}`}
                    >
                      <div className="flex justify-between items-center w-full px-1">
                        <span className="text-[10px] font-black text-amber-950">{tileIdx}</span>
                        {spec && <span className="text-sm drop-shadow-xs">{spec.icon}</span>}
                        {tileIdx === 0 && <span className="text-[7px] font-black bg-green-700 text-white px-1 py-0.2 rounded uppercase tracking-wider">XUẤT PHÁT</span>}
                        {tileIdx === LUDO_FINISH_TILE && <span className="rounded bg-yellow-600 px-1 text-[7px] font-black uppercase tracking-wider text-white">ĐÍCH</span>}
                      </div>

                      <div className="flex flex-wrap justify-center gap-1 my-1 z-10">
                        {studentsOnTile.map(st => (
                          <motion.div 
                            key={st.id} 
                            layout 
                            initial={{ scale: 0.6, opacity: 0 }} 
                            animate={{ scale: 1, opacity: 1 }} 
                            transition={{ type: "spring", stiffness: 400, damping: 25 }}
                            className="relative group"
                          >
                            <StudentAvatar student={st} className="w-8 h-8 sm:w-9 sm:h-9 rounded-full border-2 border-amber-900 shadow-md ring-2 ring-amber-300 transform group-hover:scale-125 transition-transform duration-200" />
                            <div className="absolute -bottom-1 -right-1 bg-amber-900 text-amber-100 text-[8px] font-black px-1 rounded-full border border-white shadow-xs max-w-[36px] truncate">
                              {st.name.split(' ').pop()}
                            </div>
                          </motion.div>
                        ))}
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Logs area - High contrast & readable */}
              <div className="bg-gradient-to-br from-amber-50 to-orange-50 p-4 rounded-2xl border-2 border-amber-300 shadow-md space-y-2">
                <p className="text-amber-950 font-black text-xs uppercase tracking-wider border-b border-amber-200 pb-1 flex items-center gap-1.5">
                  <span>📜</span> Nhật ký đua cá ngựa:
                </p>
                <div className="max-h-48 overflow-y-auto space-y-1 pr-1 custom-scrollbar">
                  {ludoLogs.map((log, i) => (
                    <div key={i} className="text-xs font-bold text-amber-950 bg-white/90 p-2.5 rounded-xl border border-amber-200 shadow-2xs leading-snug">
                      {log}
                    </div>
                  ))}
                  {ludoLogs.length === 0 && <p className="text-amber-800/60 italic text-xs">Chưa có lượt lắc xí ngầu nào...</p>}
                </div>
              </div>
            </div>

            {/* Right side: Dice Roller Control */}
            <div className="flex w-full shrink-0 flex-col justify-between space-y-6 rounded-[34px] border-4 border-amber-300/90 bg-white/90 p-6 shadow-[0_30px_80px_rgba(0,0,0,0.35)] backdrop-blur-xl lg:w-[21rem] xl:w-[22rem]">
              <div>
                <h3 className="mb-4 border-b border-amber-200 pb-3 text-lg font-extrabold text-amber-950">Lượt Đua Tiếp Theo</h3>

                <div className="space-y-3">
                  {battleLudoQueue.length > 0 ? (
                    <div className="rounded-2xl border-2 border-amber-300 bg-gradient-to-br from-amber-50 to-orange-50 p-3 shadow-inner">
                      <p className="mb-2 text-[10px] font-black uppercase tracking-wider text-amber-900">
                        Queue {ludoReturnHint === 'boss' ? 'Boss' : ludoReturnHint === 'solo' ? 'Solo' : 'Battle'} tự động
                      </p>
                      <div className="space-y-1.5">
                        {battleLudoQueue.map((turn, index) => {
                          const queuedStudent = ludoRaceStudents.find(s => s.id === turn.studentId) || students.find(s => s.id === turn.studentId);
                          if (!queuedStudent) return null;
                          return (
                            <div key={`${turn.studentId}-${index}`} className={`flex items-center justify-between rounded-xl px-2.5 py-2 text-xs font-black ${index === 0 ? 'bg-amber-600 text-white' : 'bg-white text-amber-950 border border-amber-200'}`}>
                              <span>{index + 1}. {queuedStudent.name}</span>
                              <span className="text-[9px] uppercase">{turn.role === 'winner' ? 'Thắng' : turn.role === 'loser' ? 'Thua' : turn.role === 'boss' ? 'Boss' : 'Hòa'}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ) : (
                    <>
                      <label className="text-[10px] font-black uppercase text-amber-900 block">Chọn Trainer Trả Lời Đúng:</label>
                      <select
                        value={ludoActiveStudent?.id || ''}
                        onChange={e => {
                          const st = ludoRaceStudents.find(s => s.id === e.target.value) || null;
                          setLudoActiveStudent(st);
                        }}
                        className="w-full border-2 border-amber-300 p-3 rounded-2xl text-sm font-bold outline-none bg-amber-50/50"
                      >
                        <option value="">-- Chọn trainer lắc xí ngầu --</option>
                        {ludoRaceStudents.map(s => (
                          <option key={s.id} value={s.id}>{s.name} ({s.className}) - Ô {ludoPositions[s.id] || 0}</option>
                        ))}
                      </select>
                    </>
                  )}

                  {ludoActiveStudent && (
                    <div className="flex items-center gap-3 rounded-3xl border-2 border-amber-300 bg-gradient-to-br from-amber-100 via-white to-orange-100 p-4 shadow-lg">
                      <StudentAvatar student={ludoActiveStudent} className="h-14 w-14 rounded-2xl border-2 border-amber-600 shadow-md" />
                      <div className="min-w-0">
                        <h4 className="font-extrabold text-amber-950 text-sm">{ludoActiveStudent.name}</h4>
                        <p className="text-[10px] font-bold text-amber-800">Đang ở ô: {ludoPositions[ludoActiveStudent.id] || 0} / {LUDO_FINISH_TILE}</p>
                        {(ludoBonusRolls[ludoActiveStudent.id] || 0) > 0 && (
                          <span className="text-[9px] font-black text-blue-700 bg-blue-100 border border-blue-200 px-1.5 py-0.5 rounded">🎁 Còn {ludoBonusRolls[ludoActiveStudent.id]} lượt lắc bonus</span>
                        )}
                        {ludoMonsterStuck[ludoActiveStudent.id] && (
                          <span className="text-[9px] font-black text-red-600 bg-red-100 border border-red-200 px-1.5 py-0.5 rounded">👹 Đang bị Quái vật kẹt! Cần lắc xí ngầu 6</span>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Dice Box */}
              <div className="space-y-4 border-t border-amber-200 py-4 text-center">
                <div className={`mx-auto flex h-28 w-28 items-center justify-center rounded-[32px] border-4 border-amber-800 text-6xl font-black shadow-[inset_0_8px_18px_rgba(120,53,15,0.18),0_18px_40px_rgba(180,83,9,0.28)] transition-transform ${ludoRolling ? 'animate-spin bg-amber-200' : 'bg-gradient-to-br from-white via-amber-100 to-orange-200 text-amber-950'}`}>
                  {ludoRolling ? '🎲' : ludoDice !== null ? ludoDice : '🎲'}
                </div>

                <button 
                  disabled={!ludoActiveStudent || ludoRolling}
                  onClick={() => {
                    if (!ludoActiveStudent) return;
                    handleLudoRollDice(ludoActiveStudent, { isBonusRoll: (ludoBonusRolls[ludoActiveStudent.id] || 0) > 0 });
                  }}
                  className="w-full rounded-2xl bg-gradient-to-r from-red-700 via-amber-600 to-orange-600 py-4 text-sm font-black uppercase tracking-wider text-white shadow-xl transition-all hover:scale-[1.02] hover:shadow-[0_18px_45px_rgba(180,83,9,0.35)] disabled:scale-100 disabled:opacity-40"
                >
                  {ludoRolling
                    ? 'Đang Đổ Xí Ngầu...'
                    : ludoActiveStudent && (ludoBonusRolls[ludoActiveStudent.id] || 0) > 0
                      ? `🎁 Lắc Bonus (còn ${ludoBonusRolls[ludoActiveStudent.id]} lượt)`
                      : '🎲 Trả Lời Đúng & Lắc Xí Ngầu (+1đ)'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: LUDO EVENT ACTION POPUP */}
      {ludoEventPopup && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in zoom-in-95 duration-200">
          <div className="bg-gradient-to-br from-amber-50 to-orange-100 p-8 rounded-[40px] max-w-md w-full border-4 border-amber-500 shadow-2xl text-center space-y-6 relative overflow-hidden">
            <div className="text-6xl animate-bounce">{ludoEventPopup.icon || '🌟'}</div>
            
            <div className="space-y-2">
              <h3 className="text-2xl font-black text-amber-950 uppercase tracking-wide">
                {ludoEventPopup.title}
              </h3>
              <p className="text-sm font-bold text-amber-900 bg-white/90 p-4 rounded-2xl border border-amber-300 shadow-xs leading-relaxed">
                {ludoEventPopup.message}
              </p>
            </div>

            <div className="flex items-center justify-center gap-3 bg-white/70 p-3 rounded-2xl border border-amber-200 shadow-xs">
              <StudentAvatar student={ludoEventPopup.actor} className="w-12 h-12 rounded-full border-2 border-amber-600" />
              <div className="text-left">
                <p className="text-xs font-black text-amber-950">{ludoEventPopup.actor.name}</p>
                <p className="text-[10px] text-amber-800 font-bold">Vị trí hiện tại: Ô {ludoPositions[ludoEventPopup.actor.id] || 0}</p>
              </div>
            </div>

            {ludoEventPopup.type === 'kick' && ludoEventPopup.target && (
              <div className="relative mx-auto h-28 overflow-hidden rounded-3xl border-2 border-red-300 bg-gradient-to-r from-red-50 via-amber-50 to-emerald-50 p-3 shadow-inner">
                <div className="absolute left-4 top-3 rounded-full bg-red-700 px-2 py-1 text-[8px] font-black uppercase tracking-wider text-white">
                  Ô {ludoEventPopup.tileIndex}
                </div>
                <div className="absolute bottom-3 left-4 rounded-full bg-emerald-700 px-2 py-1 text-[8px] font-black uppercase tracking-wider text-white">
                  Ô 0
                </div>
                <div className="absolute left-1/2 top-1/2 flex -translate-x-1/2 -translate-y-1/2 items-center gap-6">
                  <StudentAvatar student={ludoEventPopup.actor} className="h-14 w-14 rounded-2xl border-2 border-amber-500 shadow-lg" />
                  <span className="text-3xl font-black text-red-700">➜</span>
                  <motion.div
                    initial={{ x: 0, y: 0, rotate: 0, scale: 1 }}
                    animate={{ x: -110, y: 18, rotate: -18, scale: 0.78 }}
                    transition={{ type: 'spring', stiffness: 170, damping: 12 }}
                    className="relative"
                  >
                    <StudentAvatar student={ludoEventPopup.target} className="h-14 w-14 rounded-2xl border-2 border-red-500 shadow-xl" />
                    <span className="absolute -right-2 -top-2 rounded-full bg-red-600 px-1.5 text-[9px] font-black text-white shadow">Bị đá!</span>
                  </motion.div>
                </div>
              </div>
            )}

            <button
              onClick={() => setLudoEventPopup(null)}
              className="w-full bg-amber-600 hover:bg-amber-700 text-white font-black py-3.5 rounded-2xl text-sm uppercase tracking-wider shadow-lg transition-all border-2 border-amber-400"
            >
              Đã Hiểu & Tiếp Tục 🎲
            </button>
          </div>
        </div>
      )}

      {/*聖旨 EDICT DISPLAY */}
      {edict && (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/95 p-6 animate-in fade-in duration-500">
          <div className="bg-[#fdf3e7] text-[#5d4037] p-12 max-w-xl w-full border-[12px] border-[#5d4037] relative shadow-[0_0_100px_rgba(255,215,0,0.4)]">
            <div className="absolute top-4 right-4 cursor-pointer text-4xl opacity-50 hover:opacity-100" onClick={() => setEdict(null)}>&times;</div>
            <div className="text-center mb-10">
               <h2 className="text-5xl font-royal font-bold border-b-8 border-[#5d4037] pb-6 inline-block uppercase tracking-[0.3em]">Thánh Chỉ</h2>
            </div>
            <div className="bg-white/50 p-8 rounded-lg mb-10 border border-[#5d4037]/20">
              <p className="text-3xl font-royal italic leading-relaxed text-center">"{edict}"</p>
            </div>
            <div className="flex justify-center">
              <button onClick={() => setEdict(null)} className="bg-[#5d4037] text-white px-16 py-5 rounded-full font-bold uppercase tracking-[0.2em] hover:scale-110 transition-transform shadow-2xl">Khấu Đầu Tuân Chỉ</button>
            </div>
            <div className="mt-12 text-center text-[10px] opacity-40 uppercase font-black tracking-widest">Trainer Hub Announcement</div>
          </div>
        </div>
      )}

      {/* MODAL: CHÚC MỪNG POKEMON NỞ */}
      {showHatchModal && (
        <div className="fixed inset-0 z-[250] flex items-center justify-center bg-black/90 p-4 backdrop-blur-xl animate-in fade-in duration-500">
          <div className="bg-amber-50/95 max-w-2xl w-full rounded-[45px] border-[10px] border-amber-400 p-8 shadow-[0_0_120px_rgba(245,158,11,0.6)] text-center space-y-6 relative overflow-hidden animate-in zoom-in-95 duration-500">
            {/* Ambient burst bg */}
            <div className="absolute inset-0 bg-radial-gradient from-amber-300/30 via-transparent to-transparent pointer-events-none" />
            
            <h3 className="text-3xl font-royal text-amber-800 uppercase tracking-widest">🐣 Pokémon Thức Giấc 🐣</h3>
            
            {!hatchAnnouncementItems && (
              <div className="relative inline-block py-6">
              <div className="absolute inset-0 bg-amber-400/20 rounded-full blur-3xl animate-pulse" />
              <div className="text-8xl select-none animate-bounce relative z-10">🦖🧬🔥</div>
              </div>
            )}

            <div className="bg-white/90 p-6 rounded-3xl border border-amber-200/50 relative z-10 shadow-inner">
              {hatchAnnouncementItems && hatchAnnouncementItems.length > 0 ? (
                <div className="space-y-4">
                  <p className="font-extrabold text-amber-950 text-sm leading-relaxed whitespace-pre-line">
                    {hatchSuccessMessage}
                  </p>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {hatchAnnouncementItems.map(item => {
                      const student = students.find(current => current.id === item.studentId);
                      return (
                        <div key={`${item.studentId}-${item.pet.instanceId || item.pet.dexId}`} className="rounded-3xl border border-amber-200 bg-amber-50 p-4 text-left shadow-sm">
                          <div className="flex items-center gap-3">
                            {student && <StudentAvatar student={student} className="h-12 w-12 rounded-2xl border-2 border-white shadow" />}
                            <div className="min-w-0">
                              <p className="truncate text-sm font-black text-amber-950">{item.studentName}</p>
                              <p className="truncate text-xs font-bold text-amber-700">nhận được {item.pet.isShiny ? 'Shiny ' : ''}{getPokemonDisplayName(item.pet)}</p>
                            </div>
                          </div>
                          <img
                            referrerPolicy="no-referrer"
                            src={getPokemonArtworkUrl(item.pet)}
                            onError={event => handlePokemonArtworkError(event, item.pet)}
                            className={`mx-auto mt-3 h-28 w-28 object-contain drop-shadow-xl ${item.pet.isShiny ? 'rounded-3xl bg-amber-100 ring-4 ring-amber-300' : ''}`}
                            alt={getPokemonDisplayName(item.pet)}
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>
              ) : (
                <p className="font-extrabold text-amber-950 text-sm leading-relaxed whitespace-pre-line">
                  {hatchSuccessMessage}
                </p>
              )}
            </div>

            <div className="relative z-10 pt-2">
              <button 
                onClick={() => {
                  setShowHatchModal(false);
                  setHatchAnnouncementItems(null);
                  new Audio(posSoundUrl).play().catch(() => {});
                }} 
                className="bg-amber-500 text-white px-10 py-4 rounded-xl font-bold uppercase tracking-wider hover:bg-amber-600 hover:scale-105 active:scale-95 transition-all shadow-xl hover:shadow-2xl border-b-4 border-amber-700"
              >
                Cực Kỳ Đáng Yêu
              </button>
            </div>
            
            <div className="text-[9px] uppercase font-bold text-amber-900/40 tracking-wider">Trainer Hub - Pokémon Companion</div>
          </div>
        </div>
      )}

      {claimAllRewardSummary && (
        <div className="fixed inset-0 z-[245] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in fade-in duration-200">
          <div className="flex max-h-[88vh] w-full max-w-3xl flex-col overflow-hidden rounded-[36px] border-4 border-amber-300 bg-white shadow-2xl">
            <div className="bg-gradient-to-r from-emerald-700 via-amber-600 to-red-800 p-6 text-white">
              <p className="text-[10px] font-black uppercase tracking-[0.28em] text-amber-100">Nhận quà cả lớp</p>
              <h3 className="mt-1 text-3xl font-royal uppercase">Tổng kết phần thưởng</h3>
              <p className="mt-1 text-xs font-bold text-white/80">
                {claimAllRewardSummary.length > 0
                  ? `${claimAllRewardSummary.length} học sinh có quà Expedition hoặc rương sẵn sàng.`
                  : 'Chưa có Expedition hoặc rương nào sẵn sàng trong lớp hiện tại.'}
              </p>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto bg-amber-50/60 p-5 custom-scrollbar">
              {claimAllRewardSummary.length === 0 ? (
                <div className="rounded-3xl border border-dashed border-amber-300 bg-white p-8 text-center">
                  <div className="text-5xl">🎁</div>
                  <p className="mt-3 text-sm font-black text-amber-950">Không có quà nào cần nhận lúc này.</p>
                </div>
              ) : claimAllRewardSummary.map(summary => {
                const summaryStudent = students.find(student => student.id === summary.studentId);
                return (
                  <div key={summary.studentId} className="flex gap-4 rounded-3xl border border-amber-200 bg-white p-4 shadow-sm">
                    {summaryStudent && (
                      <StudentAvatar student={summaryStudent} className="h-16 w-16 shrink-0 rounded-2xl border-2 border-amber-400 shadow" />
                    )}
                    <div className="min-w-0 flex-1">
                      <p className="text-base font-black text-amber-950">{summary.studentName}</p>
                      <div className="mt-2 space-y-2">
                        {summary.expeditionMessage && (
                          <p className="rounded-2xl border border-emerald-100 bg-emerald-50 p-3 text-xs font-bold text-emerald-900">
                            🧭 Expedition: {summary.expeditionMessage}
                          </p>
                        )}
                        {summary.chestMessage && (
                          <p className="rounded-2xl border border-sky-100 bg-sky-50 p-3 text-xs font-bold text-sky-900">
                            🎁 Rương: {summary.chestMessage}
                          </p>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="border-t border-amber-200 bg-white p-4">
              <button
                onClick={() => setClaimAllRewardSummary(null)}
                className="w-full rounded-2xl bg-amber-600 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg hover:bg-amber-700"
              >
                Hoàn tất
              </button>
            </div>
          </div>
        </div>
      )}

      {showAttendanceModal && (
        <AttendanceCheckModal
          students={currentClassStudents}
          statuses={attendanceStatuses}
          lessonDateKey={getLocalDateKey()}
          getRank={getRank}
          onSetStatus={setAttendanceStatus}
          onConfirm={handleConfirmAttendanceCheck}
          onClose={() => setShowAttendanceModal(false)}
        />
      )}

      {showShopModal && (
        <div
          className="fixed inset-0 z-[210] flex items-center justify-center bg-black/75 p-3 backdrop-blur-md animate-in fade-in duration-200"
          onMouseDown={event => {
            if (event.target === event.currentTarget) {
                setShowShopModal(false);
                setShopReview(null);
                setSelectedShopSkill(null);
              }
            }}
        >
          <div className="flex max-h-[92vh] w-full max-w-6xl flex-col overflow-hidden rounded-[34px] border-2 border-white/80 bg-white/90 shadow-[0_30px_90px_rgba(15,118,110,0.28)] backdrop-blur-2xl">
            <div className="flex flex-wrap items-center justify-between gap-4 border-b border-teal-100 bg-gradient-to-r from-teal-50 via-cyan-50 to-emerald-50 p-5">
              <div>
                <p className="text-[10px] font-black uppercase tracking-[0.28em] text-teal-600">Class Shop</p>
                <h2 className="font-royal text-3xl text-teal-950">Shop Pokémon & Skill</h2>
              </div>
              <button
                onClick={() => {
                  setShowShopModal(false);
                  setShopReview(null);
                  setSelectedShopSkill(null);
                }}
                className="grid h-10 w-10 place-items-center rounded-full border border-teal-200 bg-white text-lg font-black text-teal-900 hover:bg-teal-50"
                aria-label="Đóng Shop"
              >
                ×
              </button>
            </div>

            <div className="min-h-0 flex-1 overflow-auto p-4 custom-scrollbar">
              <table
                className="w-max min-w-full border-separate border-spacing-2 text-xs"
                style={{ minWidth: `${540 + Math.max(1, petSkills.length) * 150}px` }}
              >
                <thead>
                  <tr>
                    <th className="sticky left-0 top-0 z-40 w-[220px] min-w-[220px] rounded-2xl bg-teal-950 px-3 py-3 text-left font-black uppercase text-white shadow-[10px_0_22px_rgba(15,118,110,0.22)]">
                      Trainer
                    </th>
                    <th className="sticky top-0 z-20 w-[150px] min-w-[150px] rounded-2xl bg-teal-900 px-3 py-3 text-center font-black uppercase text-white">
                      Trứng thường
                    </th>
                    <th className="sticky top-0 z-20 w-[150px] min-w-[150px] rounded-2xl bg-teal-900 px-3 py-3 text-center font-black uppercase text-white">
                      Trứng đặc biệt
                    </th>
                    {petSkills.map(skill => (
                      <th key={skill.id} className="sticky top-0 z-20 w-[150px] min-w-[150px] rounded-2xl bg-teal-900 p-0 text-center font-black uppercase text-white">
                        <button
                          type="button"
                          onClick={() => setSelectedShopSkill(skill)}
                          className="h-full w-full rounded-2xl px-3 py-3 font-black uppercase text-white transition-all hover:bg-teal-700 focus:outline-none focus:ring-4 focus:ring-teal-200"
                          title={`Bấm để xem chi tiết ${skill.name}`}
                        >
                          <span>{skill.icon}</span> {skill.name}
                        </button>
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {currentClassStudents.map(student => {
                    const selection = shopSelections[student.id] || { skills: [] };
                    const ownedSkillIds = student.pet?.skills || [];
                    return (
                      <tr key={student.id}>
                        <td className="sticky left-0 z-30 w-[220px] min-w-[220px] rounded-2xl border border-teal-100 bg-white p-3 shadow-[10px_0_22px_rgba(15,118,110,0.16)]">
                          <div className="flex items-center gap-3">
                            <StudentAvatar student={student} className="h-10 w-10 shrink-0 rounded-xl border-2 border-white shadow-sm" />
                            <div className="min-w-0">
                              <p className="truncate font-black text-teal-950">{student.name}</p>
                              <p className="mt-0.5 truncate text-[10px] font-bold text-teal-700/70">{student.points}đ Hào Quang · {student.pet ? getPokemonDisplayName(student.pet) : 'Đang ấp trứng'}</p>
                            </div>
                          </div>
                        </td>
                        {(['normal', 'special'] as const).map(kind => (
                          <td key={kind} className="w-[150px] min-w-[150px]">
                            <label className={`flex min-h-[68px] cursor-pointer items-center justify-center rounded-2xl border p-3 font-black transition-all ${selection.egg === kind ? 'border-teal-500 bg-teal-50 text-teal-800 ring-2 ring-teal-100' : 'border-teal-100 bg-white text-stone-400 hover:border-teal-300'}`}>
                              <input
                                type="checkbox"
                                checked={selection.egg === kind}
                                onChange={() => toggleShopEgg(student.id, kind)}
                                className="mr-2 h-4 w-4 accent-teal-600"
                              />
                              {kind === 'special' ? '20đ' : '10đ'}
                            </label>
                          </td>
                        ))}
                        {petSkills.map(skill => {
                          const disabled = !student.pet || ownedSkillIds.includes(skill.id);
                          const checked = selection.skills.includes(skill.id);
                          return (
                            <td key={skill.id} className="w-[150px] min-w-[150px]">
                              <label
                                title={`${skill.name}: ${skill.description} · Giá ${skill.cost}đ${disabled ? student.pet ? ' · Đã sở hữu' : ' · Cần có Pokémon active' : ''}`}
                                className={`flex min-h-[68px] cursor-pointer items-center justify-center rounded-2xl border p-3 text-center font-black transition-all ${checked ? 'border-indigo-500 bg-indigo-50 text-indigo-800 ring-2 ring-indigo-100' : 'border-teal-100 bg-white text-stone-400 hover:border-indigo-300'} ${disabled ? 'cursor-not-allowed opacity-45' : ''}`}
                              >
                                <input
                                  type="checkbox"
                                  checked={checked}
                                  disabled={disabled}
                                  onChange={() => toggleShopSkill(student.id, skill.id)}
                                  className="mr-2 h-4 w-4 accent-indigo-600"
                                />
                                {skill.cost}đ
                              </label>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-teal-100 bg-white/80 p-5">
              <p className="text-xs font-bold text-teal-900/70">Trứng thường: 80% thường, 20% đặc biệt. Trứng đặc biệt: 100% đặc biệt/rare/legend.</p>
              <button
                onClick={handlePrepareShopPurchase}
                className="rounded-2xl bg-teal-700 px-8 py-3 text-xs font-black uppercase tracking-wider text-white shadow-lg transition-all hover:bg-teal-900 active:scale-95"
              >
                Mua
              </button>
            </div>
          </div>

          {selectedShopSkill && (
            <div
              className="fixed inset-0 z-[240] flex items-center justify-center bg-black/45 p-4 backdrop-blur-sm animate-in fade-in duration-150"
              onMouseDown={event => {
                if (event.target === event.currentTarget) setSelectedShopSkill(null);
              }}
            >
              <div className="w-full max-w-xl rounded-[32px] border-2 border-white/80 bg-white p-6 shadow-[0_30px_90px_rgba(49,46,129,0.35)]">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-[10px] font-black uppercase tracking-[0.28em] text-indigo-500">Skill Detail</p>
                    <h3 className="mt-1 flex items-center gap-2 font-royal text-3xl text-indigo-950">
                      <span>{selectedShopSkill.icon}</span>
                      <span>{selectedShopSkill.name}</span>
                    </h3>
                  </div>
                  <button
                    onClick={() => setSelectedShopSkill(null)}
                    className="grid h-10 w-10 place-items-center rounded-full border border-indigo-100 bg-indigo-50 text-lg font-black text-indigo-900 hover:bg-indigo-100"
                    aria-label="Đóng chi tiết skill"
                  >
                    ×
                  </button>
                </div>

                <div className="mt-5 space-y-4 font-sans">
                  <div className="rounded-2xl border border-indigo-100 bg-indigo-50 p-4">
                    <p className="text-[10px] font-black uppercase tracking-wider text-indigo-500">Chức năng</p>
                    <p className="mt-1 text-sm font-bold leading-relaxed text-indigo-950">{selectedShopSkill.description}</p>
                  </div>
                  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
                    <div className="rounded-2xl border border-amber-100 bg-amber-50 p-4">
                      <p className="text-[10px] font-black uppercase tracking-wider text-amber-600">Giá mua</p>
                      <p className="mt-1 text-2xl font-black text-amber-950">{selectedShopSkill.cost}đ Hào Quang</p>
                    </div>
                    <div className="rounded-2xl border border-emerald-100 bg-emerald-50 p-4">
                      <p className="text-[10px] font-black uppercase tracking-wider text-emerald-600">Lượt dùng</p>
                      <p className="mt-1 text-sm font-black text-emerald-950">Mỗi skill bắt đầu từ 0 lượt đã dùng và tuân theo giới hạn trong hệ thống skill hiện tại.</p>
                    </div>
                  </div>
                  <div className="rounded-2xl border border-slate-100 bg-slate-50 p-4">
                    <p className="text-[10px] font-black uppercase tracking-wider text-slate-500">Ví dụ</p>
                    <p className="mt-1 text-sm font-bold leading-relaxed text-slate-700">
                      Nếu trainer mua {selectedShopSkill.name}, skill sẽ được gắn vào Pokémon đang đồng hành. Khi đến lượt cần dùng, giáo viên mở hồ sơ Pokémon của trainer và kích hoạt skill đó theo mô tả ở trên.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {shopReview && (
        <div className="fixed inset-0 z-[230] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in fade-in duration-200">
          <div className="w-full max-w-2xl rounded-[32px] border-2 border-white/80 bg-white p-6 shadow-[0_30px_90px_rgba(15,118,110,0.32)]">
            <h3 className="font-royal text-2xl text-teal-950">Xác nhận đơn Shop</h3>
            <div className="mt-4 max-h-[50vh] space-y-3 overflow-y-auto pr-2 custom-scrollbar">
              {shopReview.map(item => (
                <div key={item.studentId} className={`rounded-2xl border p-4 ${item.canAfford ? 'border-teal-100 bg-teal-50/50' : 'border-red-200 bg-red-50'}`}>
                  <div className="flex items-center justify-between gap-3">
                    <p className="font-black text-teal-950">{item.studentName}</p>
                    <p className={`text-sm font-black ${item.canAfford ? 'text-red-700' : 'text-red-900'}`}>-{item.totalCost}đ</p>
                  </div>
                  <p className="mt-1 text-xs font-bold text-stone-600">{item.itemLabels.join(', ')}</p>
                  {!item.canAfford && <p className="mt-1 text-[10px] font-black uppercase text-red-700">Không đủ Hào Quang ({item.pointBalance}đ)</p>}
                </div>
              ))}
            </div>
            <div className="mt-6 flex flex-wrap justify-end gap-3">
              <button onClick={() => setShopReview(null)} className="rounded-2xl border border-stone-200 bg-white px-6 py-3 text-xs font-black uppercase text-stone-500 hover:bg-stone-50">Quay lại</button>
              <button onClick={handleConfirmShopPurchase} className="rounded-2xl bg-teal-700 px-6 py-3 text-xs font-black uppercase text-white shadow-lg hover:bg-teal-900">Xác nhận mua</button>
            </div>
          </div>
        </div>
      )}

      {showHomeworkModal && (
        <HomeworkCheckModal
          students={presentStudents}
          statuses={homeworkStatuses}
          lessonDateKey={homeworkLessonDateKey}
          getRank={getRank}
          onToggle={toggleHomeworkStatus}
          onSetStatus={setHomeworkStatus}
          onConfirm={handleConfirmHomeworkCheck}
          onClose={() => setShowHomeworkModal(false)}
        />
      )}

      {/* MODAL: POKEMON RELEASED WHEN HP REACHES 0 */}
      {pokemonReleaseEvent && (
        <div className="fixed inset-0 z-[260] flex items-center justify-center bg-black/92 p-4 backdrop-blur-xl animate-in fade-in duration-300">
          <div className="bg-rose-50 max-w-2xl w-full rounded-[36px] border-[8px] border-rose-700 p-6 sm:p-8 shadow-[0_0_90px_rgba(190,18,60,0.38)] text-center space-y-6 relative overflow-hidden">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_15%,rgba(244,63,94,0.18),transparent_36%)] pointer-events-none" />
            <div className="relative z-10 space-y-4">
              <p className="text-[10px] font-black uppercase tracking-[0.25em] text-rose-800">Pokémon rời đội hình</p>
              <h3 className="text-3xl sm:text-4xl font-royal text-rose-950 uppercase">Pokémon đã rời đội hình</h3>

              <div className="bg-white/90 rounded-[28px] border border-rose-200 p-5 shadow-inner">
                <img
                  referrerPolicy="no-referrer"
                  src={getPokemonArtworkUrl(pokemonReleaseEvent.releasedPet)}
	                  onError={event => handlePokemonArtworkError(event, pokemonReleaseEvent.releasedPet)}
                  className={`w-36 h-36 object-contain mx-auto drop-shadow-xl grayscale-[20%] ${pokemonReleaseEvent.releasedPet.isShiny ? 'rounded-3xl bg-amber-100 ring-4 ring-amber-300' : ''}`}
                  alt={getPokemonDisplayName(pokemonReleaseEvent.releasedPet)}
                />
                <p className="text-lg font-black text-rose-950">
                  {pokemonReleaseEvent.releasedPet.isShiny ? '✨ ' : ''}{getPokemonDisplayName(pokemonReleaseEvent.releasedPet)} của {pokemonReleaseEvent.studentName} đã cạn HP và rời đội hình.
                </p>
                {pokemonReleaseEvent.cause && (
                  <p className="mt-2 text-xs font-bold text-rose-700">{pokemonReleaseEvent.cause}</p>
                )}
              </div>

              {pokemonReleaseEvent.remainingPets.length > 0 ? (
                <div className="space-y-3">
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-rose-800">Chọn Pokémon đồng hành mới</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                    {pokemonReleaseEvent.remainingPets.map(pet => (
                      <button
                        key={pet.instanceId || `${pet.dexId}-${pet.name}-${pet.baseDexId || pet.dexId}`}
                        onClick={() => handleSelectReplacementPokemon(pet)}
                        className="bg-white hover:bg-rose-50 border-2 border-rose-200 hover:border-rose-600 rounded-3xl p-3 transition-all shadow-sm"
                      >
                        <img
                          referrerPolicy="no-referrer"
                          src={getPokemonArtworkUrl(pet)}
	                          onError={event => handlePokemonArtworkError(event, pet)}
                          className="w-20 h-20 object-contain mx-auto"
                          alt={getPokemonDisplayName(pet)}
                        />
                        <p className="text-xs font-black text-emerald-950 truncate">{pet.isShiny ? '✨ ' : ''}{getPokemonDisplayName(pet)}</p>
                        <div className="mt-1 grid grid-cols-3 gap-1 text-[9px] font-black text-rose-800">
                          <span className="rounded-lg bg-rose-50 px-1 py-0.5">Lv.{pet.level || 1}</span>
                          <span className="rounded-lg bg-emerald-50 px-1 py-0.5 text-emerald-700">HP {pet.hp ?? 100}</span>
                          <span className="rounded-lg bg-pink-50 px-1 py-0.5 text-pink-700">B{pet.bond || 0}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <p className="text-sm font-bold text-rose-900">Bạn không còn Pokémon nào trong bộ sưu tập.</p>
                  {releaseEggShortfall > 0 && (
                    <p className="rounded-2xl bg-white/85 p-3 text-xs font-black text-rose-700 border border-rose-200">
                      Cần thêm {releaseEggShortfall} Hào Quang để mua trứng.
                    </p>
                  )}
                  <button
                    disabled={!releaseStudent || releaseEggShortfall > 0}
                    onClick={() => {
                      if (!releaseStudent) return;
                      const bought = handleBuyNewEgg(releaseStudent.id);
                      if (bought) showNextPokemonReleaseEvent();
                    }}
                    className="bg-rose-700 hover:bg-rose-800 disabled:bg-gray-300 disabled:text-gray-500 text-white px-8 py-3.5 rounded-2xl font-black uppercase tracking-wider shadow-lg transition-all"
                  >
                    Mua trứng Pokémon mới — 10 Hào Quang
                  </button>
                  <div>
                    <button
                      onClick={handleOpenEggAfterRelease}
                      className="text-xs font-black uppercase tracking-wider text-rose-700 hover:text-rose-950"
                    >
                      Mở hồ sơ ấp trứng
                    </button>
                  </div>
                  <button
                    onClick={showNextPokemonReleaseEvent}
                    className="text-xs font-bold uppercase tracking-wider text-gray-500 hover:text-gray-800"
                  >
                    Tiếp tục học không có Pokémon
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: USER PROFILE / AUTH / LOGOUT */}
      {showUserModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md">
          <div className="bg-white w-full max-w-md rounded-[40px] shadow-2xl overflow-hidden animate-in zoom-in duration-300 border-4 border-[#D4AF37]">
            <div className="bg-red-800 p-6 text-center text-white relative">
              <button onClick={() => setShowUserModal(false)} className="absolute top-4 right-5 text-2xl text-white/70 hover:text-white transition-colors">&times;</button>
              
              {user ? (
                <>
                  <div className="relative inline-block mb-3 mt-1">
                    <img 
                      src={editingPhotoURL || 'https://api.dicebear.com/7.x/bottts/svg'} 
                      className="w-20 h-20 rounded-full border-4 border-amber-400 shadow-xl object-cover mx-auto" 
                      referrerPolicy="no-referrer"
                      alt="Review Avatar"
                    />
                  </div>
                  <h2 className="text-xl font-royal font-bold uppercase tracking-wide">Tài khoản giáo viên</h2>
                  <p className="text-[10px] text-amber-300 font-mono mt-0.5 opacity-80">{user.email}</p>
                </>
              ) : (
                <div className="py-2">
                  <div className="w-12 h-12 bg-amber-400 rounded-full flex items-center justify-center text-2xl mx-auto mb-2 border-2 border-amber-200">
                    🏮
                  </div>
                  <h2 className="text-xl font-royal font-bold uppercase tracking-wide">Đăng nhập</h2>
                  <p className="text-[10px] text-amber-200 mt-0.5">Kết nối tài khoản để tự động sao lưu đám mây</p>
                </div>
              )}
            </div>
            
            <div className="p-6 space-y-5">
              {!user ? (
                <AuthLoginForm onSuccess={() => setShowUserModal(false)} />
              ) : (
                <>
                  {/* Change Display Name */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-wider text-stone-400 font-sans">Tôn Hiệu / Tên Hiển Thị</label>
                    <input 
                      type="text" 
                      className="w-full border p-2.5 rounded-2xl text-xs font-bold outline-none focus:ring-2 ring-red-800/20 font-sans" 
                      value={editingDisplayName} 
                      onChange={e => setEditingDisplayName(e.target.value)}
                      placeholder="Gõ tên hiển thị..."
                    />
                  </div>

                  {/* Change Photo URL */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-wider text-stone-400 font-sans">Ảnh Đại Diện (URL)</label>
                    <input 
                      type="text" 
                      className="w-full border p-2.5 rounded-2xl text-xs font-medium outline-none focus:ring-2 ring-red-800/20 font-sans" 
                      value={editingPhotoURL} 
                      onChange={e => setEditingPhotoURL(e.target.value)}
                      placeholder="Dán link ảnh bảo ảnh..."
                    />
                  </div>

                  {/* Quick Avatars Picker */}
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-black uppercase tracking-wider text-stone-400 block font-sans text-center">Thần Tướng Gợi Ý</label>
                    <div className="flex gap-2 justify-center">
                      {[
                        "https://api.dicebear.com/7.x/adventurer/svg?seed=Lucky",
                        "https://api.dicebear.com/7.x/adventurer/svg?seed=Aneka",
                        "https://api.dicebear.com/7.x/bottts/svg?seed=Sparks",
                        "https://api.dicebear.com/7.x/lorelei/svg?seed=Willow"
                      ].map((url, i) => (
                        <button 
                          key={i} 
                          onClick={() => setEditingPhotoURL(url)} 
                          className={`w-9 h-9 rounded-full overflow-hidden border-2 transition-all p-0.5 bg-gray-50 hover:scale-110 active:scale-95 ${editingPhotoURL === url ? 'border-red-800 scale-110 shadow-md' : 'border-gray-200'}`}
                        >
                          <img src={url} className="w-full h-full object-cover rounded-full" alt="option" referrerPolicy="no-referrer" />
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Cloud Sync Status Info */}
                  <div className="bg-amber-50 p-3 rounded-2xl border border-amber-200 text-left text-[11px] font-sans text-amber-900 space-y-1">
                    <div className="font-bold flex items-center justify-between text-amber-950">
                      <span>⚡ Trạng thái Auto Sync:</span>
                      <span className="text-[9px] bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full font-mono font-bold">ĐÃ KÍCH HOẠT</span>
                    </div>
                    <p className="leading-snug text-[10px] text-amber-800">
                      Tự động sao lưu sau 1.5s khi có thay đổi mới. Dữ liệu cũ không đổi sẽ được giữ nguyên (Differential Sync).
                    </p>
                  </div>

                  <div className="pt-2 space-y-2.5 font-sans">
                    <button 
                      onClick={async () => {
                        if (!editingDisplayName.trim()) {
                          alert("Vui lòng nhập tên hiển thị.");
                          return;
                        }
                        setProfileSaving(true);
                        try {
                          await updateUserProfile(editingDisplayName, editingPhotoURL);
                        alert("Đã lưu thông tin tài khoản thành công!");
                          setShowUserModal(false);
                        } catch (err) {
                          alert("Có lỗi xảy ra: " + (err instanceof Error ? err.message : String(err)));
                        } finally {
                          setProfileSaving(false);
                        }
                      }}
                      disabled={profileSaving}
                      className="w-full bg-red-800 text-white py-3 rounded-xl font-bold uppercase tracking-wider hover:bg-red-900 shadow-lg text-xs transition-all disabled:opacity-50"
                    >
                      {profileSaving ? "Đang Ghi Sách..." : "Lưu Thay Đổi"}
                    </button>

                    {!confirmLogout ? (
                      <button 
                        onClick={() => setConfirmLogout(true)}
                        className="w-full bg-[#fcf8e3] hover:bg-amber-100/50 text-amber-800 border border-amber-300 py-2.5 rounded-xl font-bold uppercase text-[9px] tracking-widest transition-all text-center leading-normal"
                      >
                        Đăng xuất
                      </button>
                    ) : (
                      <div className="flex gap-2 w-full animate-in fade-in duration-200">
                        <button 
                          onClick={async () => {
                            await logout();
                            setShowUserModal(false);
                            setConfirmLogout(false);
                            // Clear states
                            setStudents([]);
                            setRanksMale(DEFAULT_RANKS_MALE);
                            setRanksFemale(DEFAULT_RANKS_FEMALE);
                            setSkills(DEFAULT_SKILLS);
                            setInitialCloudLoadComplete(false);
                          }}
                          className="flex-1 bg-red-800 text-white py-2.5 rounded-xl font-bold uppercase text-[9px] tracking-widest hover:bg-red-900 transition-all text-center"
                        >
                          Xác nhận đăng xuất
                        </button>
                        <button 
                          onClick={() => setConfirmLogout(false)}
                          className="flex-1 bg-stone-100 text-stone-600 border border-stone-200 py-2.5 rounded-xl font-bold uppercase text-[9px] tracking-widest hover:bg-stone-200 transition-all text-center"
                        >
                          Quay Lại
                        </button>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
