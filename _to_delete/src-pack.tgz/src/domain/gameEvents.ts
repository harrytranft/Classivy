import { HistoryItem, PokemonPet, PokemonReleaseEvent, Student, StudentPokemonProgress } from '../types';
import {
  addPokemonXp,
  clamp,
  getDefaultPokemonProgress,
  getPokemonDisplayName,
  normalizePokemonPet,
  stableHash,
  updatePetInCollection
} from './pokemonProgression';
import { resolvePassiveEffect } from './pokemonPassives';

export type GameEventType =
  | 'SOLO_RESULT'
  | 'BATTLE_RESULT'
  | 'AURA_ADJUSTMENT'
  | 'HOMEWORK_COMPLETE'
  | 'HOMEWORK_MISSING'
  | 'EGG_HATCHED'
  | 'POKEMON_ACQUIRED'
  | 'BOSS_ROUND_SUCCESS'
  | 'BOSS_ROUND_FAILURE'
  | 'BOSS_DEFEATED'
  | 'BOSS_TOP_CONTRIBUTOR_REWARD';

export type GameEventSource =
  | 'solo'
  | 'battle'
  | 'manual'
  | 'skill'
  | 'lucky-wheel'
  | 'homework'
  | 'boss'
  | 'system';

export interface GameEvent {
  type: GameEventType;
  source: GameEventSource;
  studentId: string;
  auraDelta?: number;
  battleOutcome?: 'win' | 'loss' | 'draw';
  battleScore?: number;
  lessonKey?: string;
  timestamp: number;
}

export interface PokemonUiEvent {
  type: 'xp' | 'level-up' | 'evolution' | 'streak' | 'passive' | 'charge-ready' | 'bond' | 'hp' | 'random-drop' | 'mastery';
  message: string;
}

export interface GameEventResult {
  student: Student;
  uiEvents: PokemonUiEvent[];
  releaseEvent?: PokemonReleaseEvent | null;
}

export interface PokemonHpDeltaResult {
  student: Student;
  releaseEvent: PokemonReleaseEvent | null;
}

const appendAdventureJournalEntry = (
  student: Student,
  entry: NonNullable<Student['adventureJournal']>[number],
): Student => ({
  ...student,
  adventureJournal: [entry, ...(student.adventureJournal || [])].slice(0, 80)
});

export const releasePokemonFromStudent = (
  student: Student,
  releasedPet: PokemonPet,
  reason: string,
  cause?: string,
  timestamp = Date.now()
): { student: Student; event: PokemonReleaseEvent } => {
  const currentPets = student.pets && student.pets.length > 0 ? student.pets : (student.pet ? [student.pet] : []);
  const remainingPets = currentPets.filter(pet => pet.instanceId && releasedPet.instanceId
    ? pet.instanceId !== releasedPet.instanceId
    : !(pet.dexId === releasedPet.dexId && pet.name === releasedPet.name && (pet.baseDexId || pet.dexId) === (releasedPet.baseDexId || releasedPet.dexId))
  );
  const historyItem: HistoryItem = {
    id: `${timestamp}${Math.random()}`,
    amount: 0,
    reason,
    timestamp
  };
  const nextStudent: Student = {
    ...student,
    pet: undefined,
    pets: remainingPets,
    history: [historyItem, ...student.history].slice(0, 50),
    adventureJournal: [{
      id: `${timestamp}${Math.random()}`,
      timestamp,
      type: 'pokemon-lost' as const,
      text: `${getPokemonDisplayName(releasedPet)} was lost after reaching 0 HP.`,
      petInstanceId: releasedPet.instanceId
    }, ...(student.adventureJournal || [])].slice(0, 80)
  };

  return {
    student: nextStudent,
    event: {
      studentId: student.id,
      studentName: student.name,
      releasedPet,
      remainingPets,
      cause
    }
  };
};

export const applyPetHpDeltaToStudent = (
  student: Student,
  hpDelta: number,
  historyReason: string,
  timestamp = Date.now()
): PokemonHpDeltaResult => {
  if (!student.pet || hpDelta === 0) return { student, releaseEvent: null };

  const updatedPet: PokemonPet = {
    ...normalizePokemonPet(student.pet),
    hp: clamp((student.pet.hp ?? 100) + hpDelta, 0, 100)
  };

  if ((updatedPet.hp ?? 0) <= 0) {
    const release = releasePokemonFromStudent(
      { ...student, pet: updatedPet, pets: updatePetInCollection(student, updatedPet) },
      updatedPet,
      `🌲 ${getPokemonDisplayName(updatedPet)} đã được thả về rừng vì hết HP. ${historyReason}`,
      historyReason,
      timestamp
    );
    return { student: release.student, releaseEvent: release.event };
  }

  return {
    student: {
      ...student,
      pet: updatedPet,
      pets: updatePetInCollection(student, updatedPet)
    },
    releaseEvent: null
  };
};

const getAnswerStreakBonusXp = (streak: number): number => {
  if (streak === 3) return 5;
  if (streak === 5) return 10;
  if (streak === 10) return 20;
  if (streak > 10 && streak % 5 === 0) return 10;
  return 0;
};

const getBattleWinStreakBonusXp = (streak: number): number => {
  if (streak === 2) return 5;
  if (streak === 3) return 10;
  if (streak === 5) return 20;
  return 0;
};

const getHomeworkStreakBonusXp = (streak: number): number => {
  if (streak === 3) return 10;
  if (streak === 5) return 20;
  return 0;
};

type InstantDropType = 'rare-candy' | 'oran-berry' | 'friendship-ribbon' | 'energy-spark';

const INSTANT_DROPS: Array<{ type: InstantDropType; label: string; icon: string }> = [
  { type: 'rare-candy', label: 'Rare Candy', icon: '🍬' },
  { type: 'oran-berry', label: 'Oran Berry', icon: '🍓' },
  { type: 'friendship-ribbon', label: 'Friendship Ribbon', icon: '💖' },
  { type: 'energy-spark', label: 'Energy Spark', icon: '⚡' }
];

const applyProgressToPet = (
  student: Student,
  pet: PokemonPet,
  xpGain: number,
  bondGain: number,
  chargeGain: number,
  bonusHp: number,
  uiEvents: PokemonUiEvent[]
): Student => {
  let nextPet = normalizePokemonPet(pet);
  let nextStudent = student;
  const timestamp = Date.now();
  const finalXpGain = Math.max(0, Math.floor(xpGain));

  if (finalXpGain > 0) {
    const xpResult = addPokemonXp(nextPet, finalXpGain);
    nextPet = xpResult.pet;
    uiEvents.push({
      type: 'xp',
      message: `${getPokemonDisplayName(nextPet)} +${finalXpGain} XP`
    });
    if (xpResult.levelUps > 0) {
      uiEvents.push({
        type: 'level-up',
        message: `${getPokemonDisplayName(nextPet)} len Lv.${nextPet.level}`
      });
    }
    if (xpResult.evolved) {
      nextPet = {
        ...nextPet,
        bond: clamp((nextPet.bond || 0) + 3, 0, 100)
      };
      uiEvents.push({
        type: 'evolution',
        message: `${xpResult.previousSpeciesName} tien hoa thanh ${nextPet.speciesName || nextPet.name}`
      });
      nextStudent = appendAdventureJournalEntry(nextStudent, {
        id: `${timestamp}${Math.random()}`,
        timestamp,
        type: 'pokemon-evolved',
        text: `${xpResult.previousSpeciesName} evolved into ${nextPet.speciesName || nextPet.name}.`,
        petInstanceId: nextPet.instanceId
      });
    }
    if (xpResult.masteryStarsGained > 0) {
      uiEvents.push({
        type: 'mastery',
        message: `${getPokemonDisplayName(nextPet)} Mastery ${'⭐'.repeat(nextPet.masteryStars || 0)}`
      });
      nextStudent = appendAdventureJournalEntry(nextStudent, {
        id: `${timestamp}${Math.random()}`,
        timestamp,
        type: 'mastery',
        text: `${getPokemonDisplayName(nextPet)} reached Mastery ${nextPet.masteryStars || 0} stars.`,
        petInstanceId: nextPet.instanceId,
        metadata: { masteryStars: nextPet.masteryStars || 0 }
      });
    }
  }

  const synchronizeBonus = nextPet.passiveId === 'synchronize' && uiEvents.some(event => event.type === 'level-up') ? 2 : 0;
  const previousBond = nextPet.bond || 0;
  const nextBond = clamp((nextPet.bond || 0) + bondGain + synchronizeBonus, 0, 100);
  const nextCharge = clamp((nextPet.charge || 0) + chargeGain, 0, 5);
  const nextHp = clamp((nextPet.hp ?? 100) + bonusHp, 0, 100);

  nextPet = {
    ...nextPet,
    bond: nextBond,
    charge: nextCharge,
    hp: nextHp
  };

  if (bondGain + synchronizeBonus > 0) {
    uiEvents.push({
      type: 'bond',
      message: `${getPokemonDisplayName(nextPet)} +${bondGain + synchronizeBonus} Bond`
    });
  }
  if (previousBond < 100 && nextBond >= 100) {
    nextStudent = appendAdventureJournalEntry(nextStudent, {
      id: `${timestamp}${Math.random()}`,
      timestamp,
      type: 'bond-max',
      text: `${getPokemonDisplayName(nextPet)} reached Bond 100.`,
      petInstanceId: nextPet.instanceId
    });
  }

  return {
    ...nextStudent,
    pet: nextPet,
    pets: updatePetInCollection(nextStudent, nextPet)
  };
};

const shouldRollInstantDrop = (event: GameEvent, trigger: Parameters<typeof resolvePassiveEffect>[0]['trigger'] | null, score: number): boolean => {
  return (trigger === 'solo-positive' && (event.auraDelta || 0) > 0)
    || (event.type === 'BATTLE_RESULT' && event.source === 'battle' && score > 0);
};

const getSupportPet = (student: Student, activePet: PokemonPet): PokemonPet | undefined => {
  if (!student.supportPetInstanceId) return undefined;
  const support = (student.pets || []).find(pet => pet.instanceId === student.supportPetInstanceId);
  if (!support || support.instanceId === activePet.instanceId) return undefined;
  return normalizePokemonPet(support);
};

const applyInstantDrop = (
  student: Student,
  event: GameEvent,
  trigger: Parameters<typeof resolvePassiveEffect>[0]['trigger'] | null,
  score: number,
  uiEvents: PokemonUiEvent[]
): Student => {
  if (!student.pet || !shouldRollInstantDrop(event, trigger, score)) return student;

  const pet = normalizePokemonPet(student.pet);
  const baseChancePercent = (pet.passiveId === 'mischief' ? 12 : 6) + (pet.natureId === 'lucky' ? 2 : 0);
  const rollSeed = `${event.studentId}:${event.type}:${event.source}:${event.timestamp}:${event.auraDelta || 0}:${event.battleOutcome || ''}:${score}:${pet.instanceId || ''}`;
  const roll = stableHash(`drop-roll:${rollSeed}`) % 100;
  if (roll >= baseChancePercent) return student;

  const drop = INSTANT_DROPS[stableHash(`drop-type:${rollSeed}`) % INSTANT_DROPS.length];
  uiEvents.push({
    type: 'random-drop',
    message: `RARE DROP! ${drop.icon} ${drop.label}`
  });

  switch (drop.type) {
    case 'rare-candy':
      return applyProgressToPet(student, pet, 15, 0, 0, 0, uiEvents);
    case 'oran-berry':
      uiEvents.push({ type: 'hp', message: `${getPokemonDisplayName(pet)} +10 HP` });
      return applyProgressToPet(student, pet, 0, 0, 0, 10, uiEvents);
    case 'friendship-ribbon':
      return applyProgressToPet(student, pet, 0, 3, 0, 0, uiEvents);
    case 'energy-spark':
      uiEvents.push({ type: 'charge-ready', message: `${getPokemonDisplayName(pet)} +1 Charge` });
      return applyProgressToPet(student, pet, 0, 0, 1, 0, uiEvents);
    default:
      return student;
  }
};

export const applyGameEventToStudent = (student: Student, event: GameEvent): GameEventResult => {
  const progress: StudentPokemonProgress = {
    ...getDefaultPokemonProgress(),
    ...(student.pokemonProgress || {})
  };
  const uiEvents: PokemonUiEvent[] = [];

  let nextProgress = { ...progress };
  let baseXp = 0;
  let baseBond = 0;
  let baseCharge = 0;
  let trigger: Parameters<typeof resolvePassiveEffect>[0]['trigger'] | null = null;
  let bonusXp = 0;

  if (event.type === 'SOLO_RESULT' && event.source === 'solo') {
    const aura = event.auraDelta || 0;
    if (aura > 0) {
      nextProgress.answerStreak = progress.answerStreak + 1;
      nextProgress.bestAnswerStreak = Math.max(progress.bestAnswerStreak, nextProgress.answerStreak);
      nextProgress.positiveSoloCount = (progress.positiveSoloCount || 0) + 1;
      baseXp = Math.min(25, Math.max(0, aura) * 5);
      baseBond = 1;
      baseCharge = 1;
      trigger = 'solo-positive';
      bonusXp += getAnswerStreakBonusXp(nextProgress.answerStreak);
      if (bonusXp > 0) {
        uiEvents.push({
          type: 'streak',
          message: `Answer Streak x${nextProgress.answerStreak} +${bonusXp} XP`
        });
      }
    } else {
      nextProgress.answerStreak = 0;
    }
  }

  if (event.type === 'BATTLE_RESULT' && event.source === 'battle') {
    const score = event.battleScore || 0;
    if (event.battleOutcome === 'win') {
      nextProgress.battleWinStreak = progress.battleWinStreak + 1;
      nextProgress.bestBattleWinStreak = Math.max(progress.bestBattleWinStreak, nextProgress.battleWinStreak);
      nextProgress.battleWins = (progress.battleWins || 0) + 1;
      baseXp = 20;
      baseBond = 2;
      baseCharge = 2;
      trigger = 'battle-win';
      bonusXp += getBattleWinStreakBonusXp(nextProgress.battleWinStreak);
      if (bonusXp > 0) {
        uiEvents.push({
          type: 'streak',
          message: `Battle Win Streak x${nextProgress.battleWinStreak} +${bonusXp} XP`
        });
      }
    } else if (event.battleOutcome === 'loss') {
      nextProgress.battleWinStreak = 0;
      if (score > 0) {
        baseXp = 10;
        baseBond = 1;
        baseCharge = 1;
      }
      trigger = 'battle-loss';
    } else {
      nextProgress.battleWinStreak = 0;
      if (score > 0) {
        baseXp = 12;
        baseBond = 1;
        baseCharge = 1;
      }
      trigger = 'battle-draw';
    }
  }

  if (event.type === 'HOMEWORK_COMPLETE' && event.source === 'homework') {
    nextProgress.homeworkStreak = progress.homeworkStreak + 1;
    nextProgress.bestHomeworkStreak = Math.max(progress.bestHomeworkStreak, nextProgress.homeworkStreak);
    nextProgress.lastHomeworkLessonKey = event.lessonKey || progress.lastHomeworkLessonKey;
    baseXp = 15;
    baseBond = 2;
    trigger = 'homework-complete';
    bonusXp += getHomeworkStreakBonusXp(nextProgress.homeworkStreak);
    if (bonusXp > 0) {
      uiEvents.push({
        type: 'streak',
        message: `Homework Streak x${nextProgress.homeworkStreak} +${bonusXp} XP`
      });
    }
  }

  if (event.type === 'HOMEWORK_MISSING' && event.source === 'homework') {
    nextProgress.homeworkStreak = 0;
    nextProgress.lastHomeworkLessonKey = event.lessonKey || progress.lastHomeworkLessonKey;
  }

  let nextStudent: Student = {
    ...student,
    pokemonProgress: nextProgress
  };

  if (!student.pet || !trigger || baseXp + bonusXp + baseBond + baseCharge <= 0) {
    return { student: nextStudent, uiEvents };
  }

  const petBeforeEvent = normalizePokemonPet(student.pet);
  if (petBeforeEvent.natureId === 'brave' && event.type === 'BATTLE_RESULT' && baseXp > 0) {
    baseXp = Math.ceil(baseXp * 1.1);
  }
  if (petBeforeEvent.natureId === 'hardworking' && event.type === 'HOMEWORK_COMPLETE' && baseXp > 0) {
    baseXp = Math.ceil(baseXp * 1.15);
  }
  if (petBeforeEvent.natureId === 'loyal' && baseBond > 0) {
    baseBond = Math.ceil(baseBond * 1.2);
  }
  const supportPet = getSupportPet(student, petBeforeEvent);
  if (supportPet && baseXp > 0) {
    const homeworkBoost = supportPet.baseDexId === 7 && event.type === 'HOMEWORK_COMPLETE' ? 0.1 : 0.05;
    baseXp += Math.max(1, Math.floor(baseXp * homeworkBoost));
    uiEvents.push({ type: 'passive', message: `${getPokemonDisplayName(supportPet)} Support +XP` });
  }
  if (supportPet?.baseDexId === 133 && baseBond > 0) {
    baseBond += 1;
    uiEvents.push({ type: 'bond', message: `${getPokemonDisplayName(supportPet)} Support +1 Bond` });
  }

  let chargeReadyBonus = 0;
  let chargeGain = baseCharge;
  if (trigger === 'solo-positive' && (petBeforeEvent.charge || 0) >= 5 && baseXp + bonusXp > 0) {
    chargeReadyBonus = Math.ceil((baseXp + bonusXp) * 0.5);
    chargeGain = -(petBeforeEvent.charge || 0);
    uiEvents.push({
      type: 'charge-ready',
      message: `POWER READY +${chargeReadyBonus} XP`
    });
  }
  if (petBeforeEvent.natureId === 'energetic' && trigger === 'solo-positive') {
    const energeticRollSeed = `${event.studentId}:${event.timestamp}:${event.auraDelta || 0}:${petBeforeEvent.instanceId || ''}`;
    if (stableHash(`energetic:${energeticRollSeed}`) % 100 < 20) {
      chargeGain += 1;
      uiEvents.push({ type: 'charge-ready', message: `Energetic Nature +1 Charge` });
    }
  }
  if (supportPet?.baseDexId === 25 && trigger === 'solo-positive') {
    const supportRollSeed = `${event.studentId}:${event.timestamp}:${event.auraDelta || 0}:${supportPet.instanceId || ''}`;
    if (stableHash(`pikachu-support:${supportRollSeed}`) % 100 < 10) {
      chargeGain += 1;
      uiEvents.push({ type: 'charge-ready', message: `${getPokemonDisplayName(supportPet)} Support +1 Charge` });
    }
  }

  const passive = resolvePassiveEffect({
    student,
    pet: petBeforeEvent,
    trigger,
    baseXp,
    baseBond,
    baseCharge,
    nextAnswerStreak: nextProgress.answerStreak,
    nextPositiveSoloCount: nextProgress.positiveSoloCount || 0,
    battleScore: event.battleScore
  });

  if (passive.reaction) {
    uiEvents.push({ type: 'passive', message: passive.reaction });
  }

  nextStudent = applyProgressToPet(
    nextStudent,
    petBeforeEvent,
    baseXp + bonusXp + chargeReadyBonus + (passive.bonusXp || 0),
    baseBond + (passive.bonusBond || 0),
    chargeGain + (passive.bonusCharge || 0),
    petBeforeEvent.natureId === 'calm' && (passive.bonusHp || 0) > 0
      ? (passive.bonusHp || 0) + Math.max(1, Math.floor((passive.bonusHp || 0) * 0.1))
      : passive.bonusHp || 0,
    uiEvents
  );

  const eventScore = event.type === 'BATTLE_RESULT' ? (event.battleScore || 0) : (event.auraDelta || 0);
  nextStudent = applyInstantDrop(nextStudent, event, trigger, eventScore, uiEvents);

  return { student: nextStudent, uiEvents };
};
