
import { LuckyWheelReward, LudoTileSpec, Skill } from '../types';

// Khoá localStorage. Trước Phase 2 dùng tiền tố `imperial_*`; dữ liệu cũ được chép sang một lần
// khi mở app (`domain/storageMigration.ts`), khoá cũ được giữ nguyên để có thể hoàn tác.
export const STORAGE_KEY = 'classivy_school_data_v6';
export const SKILLS_KEY = 'classivy_skills_v6';
export const PET_SKILLS_KEY = 'classivy_pet_skills_v1';
export const LUCKY_WHEEL_REWARDS_KEY = 'classivy_lucky_wheel_rewards_v1';
export const BOSS_STATES_KEY = 'classivy_boss_states_by_class_v1';
export const BOSS_ENCOUNTER_FREQUENCY_KEY = 'classivy_boss_encounter_frequency_v1';
export const POS_SOUND_KEY = 'classivy_sound_pos';
export const NEG_SOUND_KEY = 'classivy_sound_neg';
export const TIMER_SOUND_KEY = 'classivy_sound_tim';
export const WHEEL_SPIN_SOUND_KEY = 'classivy_sound_wheel_spin';
export const WHEEL_FINISH_SOUND_KEY = 'classivy_sound_wheel_finish';

/** Khoá mới -> khoá cũ (Imperial School). Chỉ dùng cho đoạn chuyển dữ liệu một lần. */
export const LEGACY_STORAGE_KEYS: Record<string, string> = {
  [STORAGE_KEY]: 'imperial_school_data_v6',
  [SKILLS_KEY]: 'imperial_skills_v6',
  [PET_SKILLS_KEY]: 'imperial_pet_skills_v1',
  [LUCKY_WHEEL_REWARDS_KEY]: 'imperial_lucky_wheel_rewards_v1',
  [BOSS_STATES_KEY]: 'imperial_boss_states_by_class_v1',
  [BOSS_ENCOUNTER_FREQUENCY_KEY]: 'imperial_boss_encounter_frequency_v1',
  [POS_SOUND_KEY]: 'imperial_sound_pos',
  [NEG_SOUND_KEY]: 'imperial_sound_neg',
  [TIMER_SOUND_KEY]: 'imperial_sound_tim',
  [WHEEL_SPIN_SOUND_KEY]: 'imperial_sound_wheel_spin',
  [WHEEL_FINISH_SOUND_KEY]: 'imperial_sound_wheel_finish'
};
export const STORAGE_MIGRATION_MARKER_KEY = 'classivy_storage_migrated_v1';

export const DEFAULT_SKILLS: Skill[] = [
  // Positive
  { id: 'p1', name: 'Trả lời đúng', icon: '✅', points: 2, type: 'positive' },
  { id: 'p2', name: '+1', icon: '👍', points: 1, type: 'positive' },
  { id: 'p3', name: '+2', icon: '🔄', points: 2, type: 'positive' },
  { id: 'p4', name: '+3', icon: '🥳', points: 3, type: 'positive' },
  { id: 'p5', name: '+4', icon: '🖐️', points: 4, type: 'positive' },
  { id: 'p6', name: '+5', icon: '🎨', points: 5, type: 'positive' },
  { id: 'p7', name: 'Học tốt', icon: '🏅', points: 5, type: 'positive' },
  { id: 'p8', name: 'Giải thích được', icon: '🛡️', points: 3, type: 'positive' },
  { id: 'p9', name: 'Tập trung vào bài', icon: '📖', points: 3, type: 'positive' },
  { id: 'p10', name: 'Đi học đúng giờ', icon: '🔍', points: 3, type: 'positive' },
  { id: 'p11', name: 'Quay video sớm nhất', icon: '💎', points: 5, type: 'positive' },
  { id: 'p12', name: 'Trực nhật', icon: '⭐', points: 3, type: 'positive' },
  { id: 'p13', name: 'Đội thắng', icon: '👑', points: 5, type: 'positive' },
  { id: 'p14', name: 'Hoàn thành Quizlet', icon: '✈️', points: 5, type: 'positive' },
  { id: 'p15', name: 'Hoàn thành BTVN', icon: '📔', points: 5, type: 'positive' },
  { id: 'p16', name: 'Thuyết trình hay', icon: '🎓', points: 5, type: 'positive' },
  // Negative
  { id: 'n1', name: 'Không trả lời được', icon: '❓', points: -2, type: 'negative' },
  { id: 'n2', name: '-1', icon: '🔔', points: -1, type: 'negative' },
  { id: 'n3', name: '-2', icon: '🔔', points: -2, type: 'negative' },
  { id: 'n4', name: '-3', icon: '🔔', points: -3, type: 'negative' },
  { id: 'n5', name: '-4', icon: '🔔', points: -4, type: 'negative' },
  { id: 'n6', name: '-5', icon: '🔔', points: -5, type: 'negative' },
  { id: 'n7', name: 'Không giải thích được', icon: '🧪', points: -3, type: 'negative' },
  { id: 'n8', name: 'Không tập trung', icon: '🌲', points: -3, type: 'negative' },
  { id: 'n9', name: 'Nói chuyện', icon: '🗣️', points: -3, type: 'negative' },
  { id: 'n10', name: 'Không quay video', icon: '🎤', points: -5, type: 'negative' },
  { id: 'n11', name: 'Chưa làm Quizlet', icon: '✈️', points: -5, type: 'negative' },
  { id: 'n12', name: 'Làm việc riêng', icon: '🪐', points: -3, type: 'negative' },
  { id: 'n13', name: 'Chuẩn bị bài chưa tốt', icon: '♻️', points: -3, type: 'negative' },
  { id: 'n14', name: 'Cãi nhau', icon: '🎒', points: -5, type: 'negative' },
  { id: 'n15', name: 'Không tham gia games', icon: '🐲', points: -5, type: 'negative' },
  { id: 'n16', name: 'Nghịch đồ dạy học', icon: '👎', points: -5, type: 'negative' },
  { id: 'n17', name: 'Ngồi không đẹp', icon: '🍦', points: -4, type: 'negative' },
  { id: 'n18', name: 'Nói bậy', icon: '🗑️', points: -5, type: 'negative' },
  { id: 'n19', name: 'Đi học muộn', icon: '💬', points: -3, type: 'negative' },
  { id: 'n20', name: 'Không mang sách vở', icon: '✈️', points: -4, type: 'negative' },
];

export const DEFAULT_LUCKY_WHEEL_REWARDS: LuckyWheelReward[] = [
  ...Array.from({ length: 10 }, (_, idx) => ({
    id: `points_plus_${idx + 1}`,
    label: `Cộng ${idx + 1} điểm`,
    icon: '✨',
    type: 'points' as const,
    amount: idx + 1,
    color: idx % 2 === 0 ? '#16a34a' : '#22c55e'
  })),
  ...Array.from({ length: 10 }, (_, idx) => ({
    id: `points_minus_${idx + 1}`,
    label: `Trừ ${idx + 1} điểm`,
    icon: '⚡',
    type: 'points' as const,
    amount: -(idx + 1),
    color: idx % 2 === 0 ? '#dc2626' : '#f97316'
  })),
  { id: 'pokemon_gift_1', label: 'Tặng Pokemon', icon: '🎁', type: 'pokemon', color: '#f59e0b' },
  { id: 'pokemon_gift_2', label: 'Tặng Pokemon hiếm', icon: '🥚', type: 'pokemon', color: '#d97706' },
  { id: 'pokemon_gift_3', label: 'Tặng Pokemon mới', icon: '🌟', type: 'pokemon', color: '#fbbf24' },
  { id: 'skill_gift_1', label: 'Tặng skill Pokemon', icon: '📜', type: 'skill', color: '#7c3aed' },
  { id: 'skill_gift_2', label: 'Tặng bí kíp Pet', icon: '🔮', type: 'skill', color: '#9333ea' },
  { id: 'skill_gift_3', label: 'Tặng tuyệt chiêu', icon: '💫', type: 'skill', color: '#a855f7' },
  { id: 'hp_plus_5', label: 'Cộng 5 HP', icon: '❤️', type: 'hp', amount: 5, color: '#059669' },
  { id: 'hp_plus_10', label: 'Cộng 10 HP', icon: '💚', type: 'hp', amount: 10, color: '#10b981' },
  { id: 'hp_plus_15', label: 'Cộng 15 HP', icon: '💖', type: 'hp', amount: 15, color: '#34d399' },
  { id: 'hp_plus_20', label: 'Cộng 20 HP', icon: '💎', type: 'hp', amount: 20, color: '#2dd4bf' },
  { id: 'hp_minus_5', label: 'Trừ 5 HP', icon: '💔', type: 'hp', amount: -5, color: '#be123c' },
  { id: 'hp_minus_10', label: 'Trừ 10 HP', icon: '🩹', type: 'hp', amount: -10, color: '#e11d48' },
  { id: 'hp_minus_15', label: 'Trừ 15 HP', icon: '🔥', type: 'hp', amount: -15, color: '#ea580c' },
  { id: 'hp_minus_20', label: 'Trừ 20 HP', icon: '🌩️', type: 'hp', amount: -20, color: '#b91c1c' },
  { id: 'ludo_rolls_1', label: 'Lắc Cá Ngựa 1 lần', icon: '🎲', type: 'ludo_rolls', amount: 1, color: '#2563eb' },
  { id: 'ludo_rolls_2', label: 'Lắc Cá Ngựa 2 lần', icon: '🎲', type: 'ludo_rolls', amount: 2, color: '#0ea5e9' },
  { id: 'ludo_rolls_3', label: 'Lắc Cá Ngựa 3 lần', icon: '🎲', type: 'ludo_rolls', amount: 3, color: '#0891b2' },
  { id: 'ludo_rolls_4', label: 'Lắc Cá Ngựa 4 lần', icon: '🎲', type: 'ludo_rolls', amount: 4, color: '#7c3aed' },
  { id: 'ludo_rolls_5', label: 'Lắc Cá Ngựa 5 lần', icon: '🎲', type: 'ludo_rolls', amount: 5, color: '#c026d3' }
];

const DEFAULT_LUDO_TILE_LIST: LudoTileSpec[] = [
  { tileIndex: 1, title: '🚀 Turbo Start', desc: 'Xuất phát như tên lửa! Tiến thêm 3 bước.', icon: '🚀', type: 'portal', value: 3 },
  { tileIndex: 2, title: '🍀 Cỏ May Mắn', desc: 'Nhặt cỏ may mắn, nhận +2 điểm Hào Quang.', icon: '🍀', type: 'treasure', value: 2 },
  { tileIndex: 3, title: '🌀 Cổng Gió', desc: 'Cơn gió kéo trainer tiến thêm 4 bước.', icon: '🌀', type: 'portal', value: 4 },
  { tileIndex: 4, title: '🪨 Đá Chặn Đường', desc: 'Vấp đá, bị lùi 2 bước.', icon: '🪨', type: 'curse', value: -2 },
  { tileIndex: 5, title: '⚡ Đệm Sấm', desc: 'Bật lên cực nhanh, tiến thêm 3 bước.', icon: '⚡', type: 'portal', value: 3 },
  { tileIndex: 6, title: '💎 Rương Nhỏ', desc: 'Mở rương nhỏ, nhận +3 điểm Hào Quang.', icon: '💎', type: 'treasure', value: 3 },
  { tileIndex: 8, title: '👹 Quái Vật Cổng Trường', desc: 'Bị chặn lại! Lượt sau phải tung đúng 6 mới thoát.', icon: '👹', type: 'monster' },
  { tileIndex: 9, title: '🍌 Vỏ Chuối', desc: 'Trượt chân, bị lùi 3 bước.', icon: '🍌', type: 'curse', value: -3 },
  { tileIndex: 10, title: '🌟 Sao Tốc Độ', desc: 'Sao sáng dẫn đường, tiến thêm 2 bước.', icon: '🌟', type: 'portal', value: 2 },
  { tileIndex: 11, title: '🎁 Túi Quà', desc: 'Nhận quà giữa đường, +4 điểm Hào Quang.', icon: '🎁', type: 'treasure', value: 4 },
  { tileIndex: 12, title: '🌪️ Gió Ngược', desc: 'Gió ngược đẩy lùi 3 bước.', icon: '🌪️', type: 'curse', value: -3 },
  { tileIndex: 13, title: '🛡️ Lá Chắn Trainer', desc: 'Tinh thần vững vàng, nhận +3 điểm Hào Quang.', icon: '🛡️', type: 'treasure', value: 3 },
  { tileIndex: 14, title: '🧭 Đường Tắt', desc: 'Tìm thấy đường tắt, tiến thêm 4 bước.', icon: '🧭', type: 'portal', value: 4 },
  { tileIndex: 16, title: '🕳️ Hố Bất Ngờ', desc: 'Rơi xuống hố, bị lùi 4 bước.', icon: '🕳️', type: 'curse', value: -4 },
  { tileIndex: 17, title: '💫 Dải Sao', desc: 'Lướt theo dải sao, tiến thêm 3 bước.', icon: '💫', type: 'portal', value: 3 },
  { tileIndex: 18, title: '🏅 Huy Hiệu Trainer', desc: 'Nhận huy hiệu, +5 điểm Hào Quang.', icon: '🏅', type: 'treasure', value: 5 },
  { tileIndex: 19, title: '🧊 Băng Trơn', desc: 'Trượt dài, bị lùi 4 bước.', icon: '🧊', type: 'curse', value: -4 },
  { tileIndex: 20, title: '👹 Quái Vật Sân Tập', desc: 'Bị quái vật giữ chân! Cần tung đúng 6 để đi tiếp.', icon: '👹', type: 'monster' },
  { tileIndex: 21, title: '🚲 Xe Đạp Nhanh', desc: 'Đạp xe bứt tốc, tiến thêm 5 bước.', icon: '🚲', type: 'portal', value: 5 },
  { tileIndex: 22, title: '📦 Hộp Bí Ẩn', desc: 'Mở hộp bí ẩn, nhận +4 điểm Hào Quang.', icon: '📦', type: 'treasure', value: 4 },
  { tileIndex: 24, title: '🎯 Đường Chuẩn', desc: 'Đi đúng đường đua, tiến thêm 3 bước.', icon: '🎯', type: 'portal', value: 3 },
  { tileIndex: 25, title: '💣 Bom Khói', desc: 'Bom khói nổ tung, bị lùi 5 bước.', icon: '💣', type: 'curse', value: -5 },
  { tileIndex: 26, title: '💰 Kho Báu', desc: 'Nhặt được kho báu, +6 điểm Hào Quang.', icon: '💰', type: 'treasure', value: 6 },
  { tileIndex: 27, title: '🌀 Cổng Thần Tốc', desc: 'Cổng không gian đưa bạn tiến thêm 4 bước.', icon: '🌀', type: 'portal', value: 4 },
  { tileIndex: 28, title: '🧲 Nam Châm Ngược', desc: 'Bị kéo lùi 5 bước.', icon: '🧲', type: 'curse', value: -5 },
  { tileIndex: 30, title: '⚔️ Sàn Thách Đấu', desc: 'Tinh thần battle bùng lên, +6 điểm Hào Quang.', icon: '⚔️', type: 'treasure', value: 6 },
  { tileIndex: 31, title: '🌋 Dốc Núi Lửa', desc: 'Trượt khỏi dốc nóng, bị lùi 6 bước.', icon: '🌋', type: 'curse', value: -6 },
  { tileIndex: 32, title: '👹 Quái Vật Bóng Đêm', desc: 'Quái vật bóng đêm khóa đường! Cần tung đúng 6 để thoát.', icon: '👹', type: 'monster' },
  { tileIndex: 33, title: '🚀 Bệ Phóng Cuối', desc: 'Bệ phóng mạnh mẽ, tiến thêm 4 bước.', icon: '🚀', type: 'portal', value: 4 },
  { tileIndex: 34, title: '🪙 Đồng Vàng', desc: 'Nhặt được đồng vàng hiếm, +7 điểm Hào Quang.', icon: '🪙', type: 'treasure', value: 7 },
  { tileIndex: 36, title: '🌪️ Bão Cuối Đường', desc: 'Bão lớn thổi ngược, bị lùi 6 bước.', icon: '🌪️', type: 'curse', value: -6 },
  { tileIndex: 37, title: '🕸️ Lưới Nhện', desc: 'Dính lưới, lượt sau phải tung đúng 6 mới thoát.', icon: '🕸️', type: 'monster' },
  { tileIndex: 38, title: '🏆 Cúp Áp Lực', desc: 'Càng gần đích càng run, nhưng vẫn nhận +5 điểm Hào Quang.', icon: '🏆', type: 'treasure', value: 5 },
  { tileIndex: 39, title: '🧨 Bãi Mìn', desc: 'Dẫm trúng bãi mìn, bị lùi 8 bước.', icon: '🧨', type: 'curse', value: -8 },
  { tileIndex: 40, title: '🔁 Lạc Vòng', desc: 'Đi nhầm đường, quay về vạch xuất phát.', icon: '🔁', type: 'restart' },
  { tileIndex: 41, title: '🌀 Cổng Rủi Ro', desc: 'Cổng đẩy lên 3 bước, nhưng coi chừng bẫy phía trước.', icon: '🌀', type: 'portal', value: 3 },
  { tileIndex: 42, title: '🪤 Bẫy Sập', desc: 'Bẫy sập kéo lùi 9 bước.', icon: '🪤', type: 'curse', value: -9 },
  { tileIndex: 44, title: '👹 Trùm Giữ Cổng', desc: 'Boss giữ cổng đích! Cần tung đúng 6 để vượt qua.', icon: '👹', type: 'monster' },
  { tileIndex: 45, title: '⛈️ Sét Đánh Lùi', desc: 'Sét đánh ngay trước đích, bị lùi 10 bước.', icon: '⛈️', type: 'curse', value: -10 },
  { tileIndex: 46, title: '🔁 Vòng Xoáy Định Mệnh', desc: 'Bị cuốn về vạch xuất phát.', icon: '🔁', type: 'restart' },
  { tileIndex: 48, title: '💥 Cửa Ải Cuối', desc: 'Cửa ải cuối cực khó, bị lùi 12 bước.', icon: '💥', type: 'curse', value: -12 }
];

export const DEFAULT_LUDO_TILES: Record<number, LudoTileSpec> = Object.fromEntries(
  DEFAULT_LUDO_TILE_LIST.map(tile => [tile.tileIndex, tile])
);

export const LUDO_FINISH_TILE = 49;

export const DEFAULT_WHEEL_SPIN_SOUND_URL = 'https://actions.google.com/sounds/v1/transportation/airport_departure_chime.ogg';
